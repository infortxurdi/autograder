package arrayList;

public class ConfigGrader {

    // true  -> Ejecuta todas las pruebas (1 a 20)
    // false -> Ejecuta solo el ejercicio indicado en EXERCISE_NUMBER
    public static final boolean RUN_ALL = true;

    // Número del ejercicio a probar cuando RUN_ALL = false (del 1 al 20)
    // BLOQUE A (String):
    //  1: anadirSinRepetir                5: contarLetraInicial
    //  2: eliminarLongitudMenor           6: reemplazarPalabra
    //  3: buscarPalabraMasLarga           7: unirSinRepetir
    //  4: convertirAMayusculas
    //
    // BLOQUE B (Integer y Double):
    //  8: sumarPares                      12: segundoMayor
    //  9: eliminarTodosLosValores         13: aplicarDescuento
    // 10: superanLaMedia                  14: filtrarRango
    // 11: insertarOrdenado
    //
    // BLOQUE C (Clases propias: Alumno y Producto):
    // 15: obtenerNombresAprobados         18: valorTotalInventario
    // 16: mejorAlumno                     19: comprarProducto
    // 17: subirNotaATodos                 20: productosBajoStock
    public static final int EXERCISE_NUMBER = 1;
}
