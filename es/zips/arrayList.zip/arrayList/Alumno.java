package arrayList;

/**
 * Clase que almacena los datos de un alumno.
 * Cada alumno tiene nombre, edad y nota media.
 */
public class Alumno {

    // TODO: Definir los atributos privados (nombre, edad, nota)

    /**
     * Crea un nuevo objeto Alumno.
     *
     * @param nombre nombre del alumno.
     * @param edad   edad del alumno.
     * @param nota   nota del alumno (entre 0.0 y 10.0).
     */
    public Alumno(String nombre, int edad, double nota) {
        // TODO: Inicializar los atributos
    }

    /**
     * Devuelve el nombre del alumno.
     *
     * @return nombre del alumno.
     */
    public String getNombre() {
        // TODO: Devolver nombre
        return null;
    }

    /**
     * Devuelve la edad del alumno.
     *
     * @return edad del alumno.
     */
    public int getEdad() {
        // TODO: Devolver edad
        return 0;
    }

    /**
     * Devuelve la nota del alumno.
     *
     * @return nota del alumno.
     */
    public double getNota() {
        // TODO: Devolver nota
        return 0.0;
    }

    /**
     * Actualiza la nota del alumno.
     *
     * @param nota nueva nota.
     */
    public void setNota(double nota) {
        // TODO: Actualizar nota
    }

    /**
     * Indica si el alumno ha aprobado la asignatura (nota >= 5.0).
     *
     * @return true si la nota es mayor o igual que 5.0; false en caso contrario.
     */
    public boolean estaAprobado() {
        // TODO: Comprobar si nota >= 5.0
        return false;
    }
}
