package arrayList;

/**
 * Clase que almacena los datos de un producto de una tienda.
 * Cada producto tiene nombre, precio y cantidad en stock.
 */
public class Producto {

    // TODO: Definir los atributos privados (nombre, precio, stock)

    /**
     * Crea un nuevo objeto Producto.
     *
     * @param nombre nombre del producto.
     * @param precio precio por unidad.
     * @param stock  cantidad de unidades disponibles en el almacén.
     */
    public Producto(String nombre, double precio, int stock) {
        // TODO: Inicializar los atributos
    }

    /**
     * Devuelve el nombre del producto.
     *
     * @return nombre del producto.
     */
    public String getNombre() {
        // TODO: Devolver nombre
        return null;
    }

    /**
     * Devuelve el precio del producto.
     *
     * @return precio del producto.
     */
    public double getPrecio() {
        // TODO: Devolver precio
        return 0.0;
    }

    /**
     * Actualiza el precio del producto.
     *
     * @param precio nuevo precio.
     */
    public void setPrecio(double precio) {
        // TODO: Actualizar precio
    }

    /**
     * Devuelve el stock actual del producto.
     *
     * @return cantidad de stock.
     */
    public int getStock() {
        // TODO: Devolver stock
        return 0;
    }

    /**
     * Actualiza el stock del producto.
     *
     * @param stock nueva cantidad de stock.
     */
    public void setStock(int stock) {
        // TODO: Actualizar stock
    }

    /**
     * Calcula el valor económico total del stock de ese producto (precio * stock).
     *
     * @return valor total.
     */
    public double valorTotal() {
        // TODO: Calcular precio * stock
        return 0.0;
    }
}
