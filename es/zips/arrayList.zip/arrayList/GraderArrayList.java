package arrayList;

import java.util.ArrayList;
import java.util.Arrays;

public class GraderArrayList {

    // Códigos de color ANSI para mostrar en consola
    private static final String RESET = "\u001B[0m";
    private static final String RED = "\u001B[31m";
    private static final String GREEN = "\u001B[32m";
    private static final String YELLOW = "\u001B[33m";
    private static final String CYAN = "\u001B[36m";
    private static final String BOLD = "\u001B[1m";

    private static int totalTests = 0;
    private static int passedTests = 0;

    public static void main(String[] args) {
        System.out.println(CYAN + "==================================================");
        System.out.println("  EVALUADOR AUTOMÁTICO DE EJERCICIOS ARRAYLIST    ");
        System.out.println("==================================================" + RESET + "\n");

        // BLOQUE A: LISTAS DE STRING
        if (shouldRun(1)) testAnadirSinRepetir();
        if (shouldRun(2)) testEliminarLongitudMenor();
        if (shouldRun(3)) testBuscarPalabraMasLarga();
        if (shouldRun(4)) testConvertirAMayusculas();
        if (shouldRun(5)) testContarLetraInicial();
        if (shouldRun(6)) testReemplazarPalabra();
        if (shouldRun(7)) testUnirSinRepetir();

        // BLOQUE B: LISTAS NUMÉRICAS (Integer y Double)
        if (shouldRun(8)) testSumarPares();
        if (shouldRun(9)) testEliminarTodosLosValores();
        if (shouldRun(10)) testSuperanLaMedia();
        if (shouldRun(11)) testInsertarOrdenado();
        if (shouldRun(12)) testSegundoMayor();
        if (shouldRun(13)) testAplicarDescuento();
        if (shouldRun(14)) testFiltrarRango();

        // BLOQUE C: LISTAS DE CLASES PROPIAS (Alumno y Producto)
        if (shouldRun(15)) testObtenerNombresAprobados();
        if (shouldRun(16)) testMejorAlumno();
        if (shouldRun(17)) testSubirNotaATodos();
        if (shouldRun(18)) testValorTotalInventario();
        if (shouldRun(19)) testComprarProducto();
        if (shouldRun(20)) testProductosBajoStock();

        // Resumen final
        double porcentaje = totalTests > 0 ? ((double) passedTests / totalTests) * 100 : 0.0;

        System.out.println("\n" + CYAN + "==================================================" + RESET);
        System.out.printf(BOLD + " RESULTADO FINAL: %d / %d pruebas superadas (%%%.1f)\n" + RESET,
                passedTests, totalTests, porcentaje);
        System.out.println(CYAN + "==================================================" + RESET);

        if (totalTests > 0 && passedTests == totalTests) {
            System.out.println(GREEN + "🎉 ¡Excelente trabajo! Todos los métodos de ArrayList funcionan correctamente." + RESET);
        } else if (totalTests > 0) {
            System.out.println(YELLOW + "⚠️ Revisa los ejercicios marcados como [ERROR] e inténtalo de nuevo." + RESET);
        } else {
            System.out.println(YELLOW + "⚠️ No se ha ejecutado ninguna prueba. Revisa la configuración." + RESET);
        }
    }

    private static boolean shouldRun(int exerciseNumber) {
        return ConfigGrader.RUN_ALL || ConfigGrader.EXERCISE_NUMBER == exerciseNumber;
    }

    private static void test(String nombrePrueba, boolean resultado, String esperado, String obtenido) {
        totalTests++;
        if (resultado) {
            passedTests++;
            System.out.printf("  " + GREEN + "[OK]" + RESET + " %s\n", nombrePrueba);
        } else {
            System.out.printf("  " + RED + "[ERROR]" + RESET + " %s | Esperado: '%s' -> Obtenido: '%s'\n",
                    nombrePrueba, esperado, obtenido);
        }
    }

    @SafeVarargs
    private static <T> ArrayList<T> lista(T... elementos) {
        return new ArrayList<>(Arrays.asList(elementos));
    }

    // =============================================================
    // TESTS BLOQUE A (String)
    // =============================================================

    private static void testAnadirSinRepetir() {
        System.out.println(BOLD + "--- Ejercicio 1: anadirSinRepetir ---" + RESET);
        ArrayList<String> l1 = lista("Ana", "Jon");
        boolean r1 = Ejercicios.anadirSinRepetir(l1, "Ane");
        test("Añadir elemento nuevo ('Ane')", r1 && l1.equals(lista("Ana", "Jon", "Ane")),
                "true -> [Ana, Jon, Ane]", r1 + " -> " + l1);

        ArrayList<String> l2 = lista("Ana", "Jon");
        boolean r2 = Ejercicios.anadirSinRepetir(l2, "Jon");
        test("No añadir repetido ('Jon')", !r2 && l2.equals(lista("Ana", "Jon")),
                "false -> [Ana, Jon]", r2 + " -> " + l2);

        boolean r3 = Ejercicios.anadirSinRepetir(null, "Ane");
        test("Cuando la lista es null", !r3, "false", String.valueOf(r3));
    }

    private static void testEliminarLongitudMenor() {
        System.out.println("\n" + BOLD + "--- Ejercicio 2: eliminarLongitudMenor ---" + RESET);
        ArrayList<String> l1 = lista("Hola", "Yo", "Tu", "Español", "Si");
        int r1 = Ejercicios.eliminarLongitudMenor(l1, 3);
        test("Eliminar longitud < 3 con elementos consecutivos", r1 == 3 && l1.equals(lista("Hola", "Español")),
                "3 -> [Hola, Español]", r1 + " -> " + l1);

        ArrayList<String> l2 = lista("Java", "Python");
        int r2 = Ejercicios.eliminarLongitudMenor(l2, 3);
        test("No eliminar ninguno", r2 == 0 && l2.equals(lista("Java", "Python")),
                "0 -> [Java, Python]", r2 + " -> " + l2);

        int r3 = Ejercicios.eliminarLongitudMenor(null, 3);
        test("Cuando es null", r3 == 0, "0", String.valueOf(r3));
    }

    private static void testBuscarPalabraMasLarga() {
        System.out.println("\n" + BOLD + "--- Ejercicio 3: buscarPalabraMasLarga ---" + RESET);
        String r1 = Ejercicios.buscarPalabraMasLarga(lista("gato", "perro", "pez"));
        test("Palabra más larga ['gato', 'perro', 'pez']", "perro".equals(r1), "perro", String.valueOf(r1));

        String r2 = Ejercicios.buscarPalabraMasLarga(lista("sol", "casa", "mesa"));
        test("En caso de empate la primera ['sol', 'casa', 'mesa']", "casa".equals(r2), "casa", String.valueOf(r2));

        String r3 = Ejercicios.buscarPalabraMasLarga(new ArrayList<>());
        test("Lista vacía", r3 == null, "null", String.valueOf(r3));

        String r4 = Ejercicios.buscarPalabraMasLarga(null);
        test("Cuando es null", r4 == null, "null", String.valueOf(r4));
    }

    private static void testConvertirAMayusculas() {
        System.out.println("\n" + BOLD + "--- Ejercicio 4: convertirAMayusculas ---" + RESET);
        ArrayList<String> original = lista("hola", "Mundo");
        ArrayList<String> r1 = Ejercicios.convertirAMayusculas(original);
        test("Convertir a mayúsculas y mantener la original",
                r1 != null && r1.equals(lista("HOLA", "MUNDO")) && original.equals(lista("hola", "Mundo")),
                "[HOLA, MUNDO]", String.valueOf(r1));

        ArrayList<String> r2 = Ejercicios.convertirAMayusculas(null);
        test("Cuando es null", r2 != null && r2.isEmpty(), "[]", String.valueOf(r2));
    }

    private static void testContarLetraInicial() {
        System.out.println("\n" + BOLD + "--- Ejercicio 5: contarLetraInicial ---" + RESET);
        int r1 = Ejercicios.contarLetraInicial(lista("Ana", "alberto", "Juan", "Alicia"), 'a');
        test("Letra inicial 'a' (mayúscula/minúscula)", r1 == 3, "3", String.valueOf(r1));

        int r2 = Ejercicios.contarLetraInicial(lista("Juan", "Miguel"), 'a');
        test("No coincide ninguna", r2 == 0, "0", String.valueOf(r2));

        int r3 = Ejercicios.contarLetraInicial(null, 'a');
        test("Cuando es null", r3 == 0, "0", String.valueOf(r3));
    }

    private static void testReemplazarPalabra() {
        System.out.println("\n" + BOLD + "--- Ejercicio 6: reemplazarPalabra ---" + RESET);
        ArrayList<String> l1 = lista("rojo", "azul", "rojo");
        int r1 = Ejercicios.reemplazarPalabra(l1, "rojo", "amarillo");
        test("Reemplazar 'rojo' -> 'amarillo'", r1 == 2 && l1.equals(lista("amarillo", "azul", "amarillo")),
                "2 -> [amarillo, azul, amarillo]", r1 + " -> " + l1);

        int r2 = Ejercicios.reemplazarPalabra(null, "a", "b");
        test("Cuando es null", r2 == 0, "0", String.valueOf(r2));
    }

    private static void testUnirSinRepetir() {
        System.out.println("\n" + BOLD + "--- Ejercicio 7: unirSinRepetir ---" + RESET);
        ArrayList<String> r1 = Ejercicios.unirSinRepetir(lista("A", "B", "A"), lista("B", "C", "D"));
        test("Unir ['A','B','A'] y ['B','C','D']",
                r1 != null && r1.equals(lista("A", "B", "C", "D")), "[A, B, C, D]", String.valueOf(r1));

        ArrayList<String> r2 = Ejercicios.unirSinRepetir(null, lista("X", "X"));
        test("Cuando la primera es null", r2 != null && r2.equals(lista("X")), "[X]", String.valueOf(r2));

        ArrayList<String> r3 = Ejercicios.unirSinRepetir(null, null);
        test("Cuando ambas son null", r3 != null && r3.isEmpty(), "[]", String.valueOf(r3));
    }

    // =============================================================
    // TESTS BLOQUE B (Integer y Double)
    // =============================================================

    private static void testSumarPares() {
        System.out.println("\n" + BOLD + "--- Ejercicio 8: sumarPares ---" + RESET);
        int r1 = Ejercicios.sumarPares(lista(1, 2, 3, 4, 6));
        test("Suma [1, 2, 3, 4, 6]", r1 == 12, "12", String.valueOf(r1));

        int r2 = Ejercicios.sumarPares(lista(1, 3, 5));
        test("Sin pares [1, 3, 5]", r2 == 0, "0", String.valueOf(r2));

        int r3 = Ejercicios.sumarPares(null);
        test("Cuando es null", r3 == 0, "0", String.valueOf(r3));
    }

    private static void testEliminarTodosLosValores() {
        System.out.println("\n" + BOLD + "--- Ejercicio 9: eliminarTodosLosValores ---" + RESET);
        ArrayList<Integer> l1 = lista(2, 5, 2, 8, 2);
        boolean r1 = Ejercicios.eliminarTodosLosValores(l1, 2);
        test("Eliminar todos los 2 [2, 5, 2, 8, 2]", r1 && l1.equals(lista(5, 8)),
                "true -> [5, 8]", r1 + " -> " + l1);

        ArrayList<Integer> l2 = lista(1, 3, 5);
        boolean r2 = Ejercicios.eliminarTodosLosValores(l2, 2);
        test("Cuando el valor no está", !r2 && l2.equals(lista(1, 3, 5)),
                "false -> [1, 3, 5]", r2 + " -> " + l2);

        boolean r3 = Ejercicios.eliminarTodosLosValores(null, 2);
        test("Cuando es null", !r3, "false", String.valueOf(r3));
    }

    private static void testSuperanLaMedia() {
        System.out.println("\n" + BOLD + "--- Ejercicio 10: superanLaMedia ---" + RESET);
        ArrayList<Double> r1 = Ejercicios.superanLaMedia(lista(4.0, 6.0, 8.0));
        test("Superan la media (6.0) [4.0, 6.0, 8.0]",
                r1 != null && r1.equals(lista(8.0)), "[8.0]", String.valueOf(r1));

        ArrayList<Double> r2 = Ejercicios.superanLaMedia(lista(5.0, 5.0));
        test("Cuando todos son iguales [5.0, 5.0]", r2 != null && r2.isEmpty(), "[]", String.valueOf(r2));

        ArrayList<Double> r3 = Ejercicios.superanLaMedia(null);
        test("Cuando es null", r3 != null && r3.isEmpty(), "[]", String.valueOf(r3));
    }

    private static void testInsertarOrdenado() {
        System.out.println("\n" + BOLD + "--- Ejercicio 11: insertarOrdenado ---" + RESET);
        ArrayList<Integer> l1 = lista(10, 20, 40, 50);
        Ejercicios.insertarOrdenado(l1, 30);
        test("Insertar en medio (30)", l1.equals(lista(10, 20, 30, 40, 50)), "[10, 20, 30, 40, 50]", String.valueOf(l1));

        ArrayList<Integer> l2 = lista(10, 20);
        Ejercicios.insertarOrdenado(l2, 5);
        test("Insertar al principio (5)", l2.equals(lista(5, 10, 20)), "[5, 10, 20]", String.valueOf(l2));

        ArrayList<Integer> l3 = lista(10, 20);
        Ejercicios.insertarOrdenado(l3, 99);
        test("Insertar al final (99)", l3.equals(lista(10, 20, 99)), "[10, 20, 99]", String.valueOf(l3));
    }

    private static void testSegundoMayor() {
        System.out.println("\n" + BOLD + "--- Ejercicio 12: segundoMayor ---" + RESET);
        int r1 = Ejercicios.segundoMayor(lista(10, 5, 20, 8));
        test("Segundo mayor [10, 5, 20, 8]", r1 == 10, "10", String.valueOf(r1));

        int r2 = Ejercicios.segundoMayor(lista(20, 20, 15, 10));
        test("Mayor repetido [20, 20, 15, 10]", r2 == 15, "15", String.valueOf(r2));

        int r3 = Ejercicios.segundoMayor(lista(5, 5, 5));
        test("Un único valor distinto [5, 5, 5]", r3 == Integer.MIN_VALUE,
                String.valueOf(Integer.MIN_VALUE), String.valueOf(r3));

        int r4 = Ejercicios.segundoMayor(null);
        test("Cuando es null", r4 == Integer.MIN_VALUE, String.valueOf(Integer.MIN_VALUE), String.valueOf(r4));
    }

    private static void testAplicarDescuento() {
        System.out.println("\n" + BOLD + "--- Ejercicio 13: aplicarDescuento ---" + RESET);
        ArrayList<Double> l1 = lista(100.0, 50.0);
        Ejercicios.aplicarDescuento(l1, 20.0);
        boolean ok1 = l1.size() == 2 && Math.abs(l1.get(0) - 80.0) < 0.001 && Math.abs(l1.get(1) - 40.0) < 0.001;
        test("Descuento del 20% [100.0, 50.0]", ok1, "[80.0, 40.0]", String.valueOf(l1));

        ArrayList<Double> l2 = lista(100.0);
        Ejercicios.aplicarDescuento(l2, -5.0);
        test("Porcentaje no válido (-5.0)", Math.abs(l2.get(0) - 100.0) < 0.001, "[100.0]", String.valueOf(l2));
    }

    private static void testFiltrarRango() {
        System.out.println("\n" + BOLD + "--- Ejercicio 14: filtrarRango ---" + RESET);
        ArrayList<Integer> r1 = Ejercicios.filtrarRango(lista(5, 10, 15, 20, 25), 10, 20);
        test("Filtrar rango [10, 20]", r1 != null && r1.equals(lista(10, 15, 20)),
                "[10, 15, 20]", String.valueOf(r1));

        ArrayList<Integer> r2 = Ejercicios.filtrarRango(null, 10, 20);
        test("Cuando es null", r2 != null && r2.isEmpty(), "[]", String.valueOf(r2));
    }

    // =============================================================
    // TESTS BLOQUE C (Clases propias: Alumno y Producto)
    // =============================================================

    private static void testObtenerNombresAprobados() {
        System.out.println("\n" + BOLD + "--- Ejercicio 15: obtenerNombresAprobados (Alumno) ---" + RESET);
        ArrayList<Alumno> alumnos = lista(
                new Alumno("Ane", 19, 8.5),
                new Alumno("Mikel", 20, 4.2),
                new Alumno("Sara", 19, 5.0)
        );
        ArrayList<String> r1 = Ejercicios.obtenerNombresAprobados(alumnos);
        test("Nombres de aprobados (Ane 8.5, Mikel 4.2, Sara 5.0)",
                r1 != null && r1.equals(lista("Ane", "Sara")), "[Ane, Sara]", String.valueOf(r1));

        ArrayList<String> r2 = Ejercicios.obtenerNombresAprobados(null);
        test("Cuando es null", r2 != null && r2.isEmpty(), "[]", String.valueOf(r2));
    }

    private static void testMejorAlumno() {
        System.out.println("\n" + BOLD + "--- Ejercicio 16: mejorAlumno (Alumno) ---" + RESET);
        Alumno a1 = new Alumno("Ane", 19, 7.5);
        Alumno a2 = new Alumno("Mikel", 20, 9.2);
        Alumno a3 = new Alumno("Sara", 19, 9.2);
        Alumno r1 = Ejercicios.mejorAlumno(lista(a1, a2, a3));
        test("Mejor alumno (en empate el primero: Mikel)", r1 == a2,
                "Mikel (9.2)", r1 != null ? r1.getNombre() + " (" + r1.getNota() + ")" : "null");

        Alumno r2 = Ejercicios.mejorAlumno(null);
        test("Cuando es null", r2 == null, "null", String.valueOf(r2));
    }

    private static void testSubirNotaATodos() {
        System.out.println("\n" + BOLD + "--- Ejercicio 17: subirNotaATodos (Alumno) ---" + RESET);
        Alumno a1 = new Alumno("Ane", 19, 8.0);
        Alumno a2 = new Alumno("Mikel", 20, 9.5);
        Ejercicios.subirNotaATodos(lista(a1, a2), 1.0);
        boolean ok = Math.abs(a1.getNota() - 9.0) < 0.001 && Math.abs(a2.getNota() - 10.0) < 0.001;
        test("Subir +1.0 (con límite 10.0)", ok, "Ane: 9.0, Mikel: 10.0",
                "Ane: " + a1.getNota() + ", Mikel: " + a2.getNota());
    }

    private static void testValorTotalInventario() {
        System.out.println("\n" + BOLD + "--- Ejercicio 18: valorTotalInventario (Producto) ---" + RESET);
        ArrayList<Producto> productos = lista(
                new Producto("Teclado", 25.0, 4),
                new Producto("Ratón", 15.0, 2)
        );
        double r1 = Ejercicios.valorTotalInventario(productos);
        test("Valor total (25*4 + 15*2)", Math.abs(r1 - 130.0) < 0.001, "130.0", String.valueOf(r1));

        double r2 = Ejercicios.valorTotalInventario(null);
        test("Cuando es null", Math.abs(r2 - 0.0) < 0.001, "0.0", String.valueOf(r2));
    }

    private static void testComprarProducto() {
        System.out.println("\n" + BOLD + "--- Ejercicio 19: comprarProducto (Producto) ---" + RESET);
        Producto p1 = new Producto("Teclado", 25.0, 5);
        ArrayList<Producto> tienda = lista(p1);

        boolean r1 = Ejercicios.comprarProducto(tienda, "teclado", 3);
        test("Compra correcta ('teclado', 3 unidades)", r1 && p1.getStock() == 2,
                "true (stock: 2)", r1 + " (stock: " + p1.getStock() + ")");

        boolean r2 = Ejercicios.comprarProducto(tienda, "teclado", 4);
        test("Sin stock suficiente (pide 4, hay 2)", !r2 && p1.getStock() == 2,
                "false (stock: 2)", r2 + " (stock: " + p1.getStock() + ")");

        boolean r3 = Ejercicios.comprarProducto(tienda, "Monitor", 1);
        test("Producto inexistente", !r3, "false", String.valueOf(r3));
    }

    private static void testProductosBajoStock() {
        System.out.println("\n" + BOLD + "--- Ejercicio 20: productosBajoStock (Producto) ---" + RESET);
        Producto p1 = new Producto("A", 10.0, 2);
        Producto p2 = new Producto("B", 10.0, 5);
        Producto p3 = new Producto("C", 10.0, 1);

        ArrayList<Producto> r1 = Ejercicios.productosBajoStock(lista(p1, p2, p3), 5);
        test("Productos con stock < 5", r1 != null && r1.equals(lista(p1, p3)),
                "[A, C]", r1 != null ? r1.size() + " productos" : "null");

        ArrayList<Producto> r2 = Ejercicios.productosBajoStock(null, 5);
        test("Cuando es null", r2 != null && r2.isEmpty(), "[]", String.valueOf(r2));
    }
}
