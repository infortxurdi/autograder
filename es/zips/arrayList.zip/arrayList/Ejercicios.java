package arrayList;

import java.util.ArrayList;

public class Ejercicios {

    // =============================================================
    // BLOQUE A: LISTAS DE STRING (ArrayList<String>)
    // =============================================================

    /**
     * Ejercicio 1: anadirSinRepetir
     *
     * Añade un elemento al final de la lista siempre que no exista previamente en ella.
     *
     * @param lista    ArrayList de cadenas de texto.
     * @param elemento texto que se desea añadir.
     * @return true si el elemento se ha añadido; false si ya existía o algún parámetro es null.
     *
     * Ejemplos:
     * - anadirSinRepetir(["Ana", "Jon"], "Ane") -> true (lista: ["Ana", "Jon", "Ane"])
     * - anadirSinRepetir(["Ana", "Jon"], "Jon") -> false (lista: ["Ana", "Jon"])
     * - anadirSinRepetir(null, "Ane") -> false
     */
    public static boolean anadirSinRepetir(ArrayList<String> lista, String elemento) {
        // TODO: Comprobar si el elemento existe y añadirlo si no está
        return false;
    }

    /**
     * Ejercicio 2: eliminarLongitudMenor
     *
     * Elimina de la lista todas las palabras que tengan menos caracteres que la longitud mínima
     * (< longitudMinima).
     *
     * @param palabras       ArrayList de String a analizar y modificar.
     * @param longitudMinima longitud mínima necesaria para conservar una palabra.
     * @return Número de palabras eliminadas. 0 si la lista es null.
     *
     * Ejemplos:
     * - eliminarLongitudMenor(["Hola", "Yo", "Tu", "Español", "Si"], 3) -> 3 (lista: ["Hola", "Español"])
     * - eliminarLongitudMenor(["Java", "Python"], 3) -> 0
     * - eliminarLongitudMenor(null, 3) -> 0
     */
    public static int eliminarLongitudMenor(ArrayList<String> palabras, int longitudMinima) {
        // TODO: ¡Cuidado con los índices al eliminar elementos!
        return 0;
    }

    /**
     * Ejercicio 3: buscarPalabraMasLarga
     *
     * Encuentra la palabra más larga de la lista. En caso de empate, devuelve la primera que aparece.
     *
     * @param palabras ArrayList de String.
     * @return La palabra más larga. null si la lista es null o está vacía.
     *
     * Ejemplos:
     * - buscarPalabraMasLarga(["gato", "perro", "pez"]) -> "perro"
     * - buscarPalabraMasLarga(["sol", "casa", "mesa"]) -> "casa"
     * - buscarPalabraMasLarga([]) -> null
     * - buscarPalabraMasLarga(null) -> null
     */
    public static String buscarPalabraMasLarga(ArrayList<String> palabras) {
        // TODO: Buscar la cadena con mayor longitud
        return null;
    }

    /**
     * Ejercicio 4: convertirAMayusculas
     *
     * Devuelve un NUEVO ArrayList con todas las palabras de la lista original convertidas a mayúsculas.
     * La lista original no debe modificarse.
     *
     * @param palabras ArrayList de String original.
     * @return Nuevo ArrayList con las palabras en mayúsculas. Lista vacía si la original es null.
     *
     * Ejemplos:
     * - convertirAMayusculas(["hola", "Mundo"]) -> ["HOLA", "MUNDO"]
     * - convertirAMayusculas(null) -> []
     */
    public static ArrayList<String> convertirAMayusculas(ArrayList<String> palabras) {
        // TODO: Crear un nuevo ArrayList y añadir los elementos usando toUpperCase()
        return new ArrayList<>();
    }

    /**
     * Ejercicio 5: contarLetraInicial
     *
     * Cuenta cuántas palabras empiezan por la letra indicada (sin distinguir mayúsculas y minúsculas).
     *
     * @param palabras ArrayList de String.
     * @param letra    carácter inicial que se desea buscar.
     * @return Número de palabras que empiezan por esa letra. 0 si la lista es null o está vacía.
     *
     * Ejemplos:
     * - contarLetraInicial(["Ana", "alberto", "Juan", "Alicia"], 'a') -> 3
     * - contarLetraInicial(["Juan", "Miguel"], 'a') -> 0
     * - contarLetraInicial(null, 'a') -> 0
     */
    public static int contarLetraInicial(ArrayList<String> palabras, char letra) {
        // TODO: Comparar el primer carácter pasado a minúscula
        return 0;
    }

    /**
     * Ejercicio 6: reemplazarPalabra
     *
     * Reemplaza todas las apariciones de la palabra 'antigua' por 'nueva' dentro de la propia lista.
     *
     * @param palabras ArrayList de String que se desea modificar.
     * @param antigua  palabra que se quiere reemplazar.
     * @param nueva    palabra nueva que se quiere poner.
     * @return Número de reemplazos realizados. 0 si algún parámetro es null.
     *
     * Ejemplos:
     * - reemplazarPalabra(["rojo", "azul", "rojo"], "rojo", "amarillo") -> 2 (lista: ["amarillo", "azul", "amarillo"])
     * - reemplazarPalabra(["azul"], "rojo", "amarillo") -> 0
     * - reemplazarPalabra(null, "a", "b") -> 0
     */
    public static int reemplazarPalabra(ArrayList<String> palabras, String antigua, String nueva) {
        // TODO: Utilizar el método set(i, nueva)
        return 0;
    }

    /**
     * Ejercicio 7: unirSinRepetir
     *
     * Une todos los elementos de dos listas en un NUEVO ArrayList, sin duplicados
     * y manteniendo el orden de aparición.
     *
     * @param l1 primer ArrayList de String.
     * @param l2 segundo ArrayList de String.
     * @return Nuevo ArrayList con la unión de ambas listas (sin repetidos).
     *
     * Ejemplos:
     * - unirSinRepetir(["A", "B", "A"], ["B", "C", "D"]) -> ["A", "B", "C", "D"]
     * - unirSinRepetir(null, ["X", "X"]) -> ["X"]
     * - unirSinRepetir(null, null) -> []
     */
    public static ArrayList<String> unirSinRepetir(ArrayList<String> l1, ArrayList<String> l2) {
        // TODO: Añadir los elementos de ambas listas sin repetir
        return new ArrayList<>();
    }

    // =============================================================
    // BLOQUE B: LISTAS NUMÉRICAS (Integer y Double)
    // =============================================================

    /**
     * Ejercicio 8: sumarPares
     *
     * Calcula la suma de todos los números pares de la lista.
     *
     * @param numeros ArrayList de Integer.
     * @return Suma de los números pares. 0 si la lista es null o está vacía.
     *
     * Ejemplos:
     * - sumarPares([1, 2, 3, 4, 6]) -> 12
     * - sumarPares([1, 3, 5]) -> 0
     * - sumarPares(null) -> 0
     */
    public static int sumarPares(ArrayList<Integer> numeros) {
        // TODO: Sumar los números que cumplan % 2 == 0
        return 0;
    }

    /**
     * Ejercicio 9: eliminarTodosLosValores
     *
     * Elimina de la lista todas las apariciones del número indicado.
     *
     * @param numeros ArrayList de Integer.
     * @param valor   número entero que se desea eliminar.
     * @return true si se ha eliminado al menos un elemento; false en caso contrario o si la lista es null.
     *
     * Ejemplos:
     * - eliminarTodosLosValores([2, 5, 2, 8, 2], 2) -> true (lista: [5, 8])
     * - eliminarTodosLosValores([1, 3, 5], 2) -> false
     * - eliminarTodosLosValores(null, 2) -> false
     */
    public static boolean eliminarTodosLosValores(ArrayList<Integer> numeros, int valor) {
        // TODO: ¡Cuidado al distinguir entre remove(int) y remove(Object)!
        return false;
    }

    /**
     * Ejercicio 10: superanLaMedia
     *
     * Calcula la media aritmética de las notas de la lista y devuelve un NUEVO ArrayList
     * con las notas estrictamente mayores (> media) que dicha media.
     *
     * @param notas ArrayList de notas de tipo Double.
     * @return Nuevo ArrayList con las notas que superan la media. Lista vacía si es null o está vacía.
     *
     * Ejemplos:
     * - superanLaMedia([4.0, 6.0, 8.0]) -> [8.0]  (media: 6.0)
     * - superanLaMedia([5.0, 5.0]) -> []
     * - superanLaMedia(null) -> []
     */
    public static ArrayList<Double> superanLaMedia(ArrayList<Double> notas) {
        // TODO: Calcular primero la media y después filtrar
        return new ArrayList<>();
    }

    /**
     * Ejercicio 11: insertarOrdenado
     *
     * Inserta un nuevo número en una lista ordenada de forma ascendente en la posición
     * correspondiente, para que la lista siga estando ordenada.
     *
     * @param listaOrdenada ArrayList de Integer ordenado ascendentemente.
     * @param nuevo         número que se desea insertar.
     *
     * Ejemplos:
     * - insertarOrdenado([10, 20, 40, 50], 30) -> lista: [10, 20, 30, 40, 50]
     * - insertarOrdenado([10, 20], 5) -> lista: [5, 10, 20]
     * - insertarOrdenado([], 7) -> lista: [7]
     */
    public static void insertarOrdenado(ArrayList<Integer> listaOrdenada, int nuevo) {
        // TODO: Buscar la posición adecuada y usar add(indice, nuevo)
    }

    /**
     * Ejercicio 12: segundoMayor
     *
     * Encuentra el segundo valor más grande (distinto) de la lista.
     *
     * @param numeros ArrayList de Integer.
     * @return El segundo número más grande. Integer.MIN_VALUE si es null o tiene menos de 2 valores distintos.
     *
     * Ejemplos:
     * - segundoMayor([10, 5, 20, 8]) -> 10
     * - segundoMayor([20, 20, 15, 10]) -> 15
     * - segundoMayor([5, 5, 5]) -> Integer.MIN_VALUE
     * - segundoMayor(null) -> Integer.MIN_VALUE
     */
    public static int segundoMayor(ArrayList<Integer> numeros) {
        // TODO: Encontrar el valor mayor y el segundo mayor
        return Integer.MIN_VALUE;
    }

    /**
     * Ejercicio 13: aplicarDescuento
     *
     * Aplica un porcentaje de descuento a todos los precios de la lista dentro de la propia lista.
     * Si el porcentaje es menor que 0 o mayor que 100, no realiza ningún cambio.
     *
     * @param precios    ArrayList de precios de tipo Double.
     * @param porcentaje porcentaje de descuento (entre 0.0 y 100.0).
     *
     * Ejemplos:
     * - aplicarDescuento([100.0, 50.0], 20.0) -> lista: [80.0, 40.0]
     * - aplicarDescuento([100.0], -5.0) -> lista: [100.0]
     */
    public static void aplicarDescuento(ArrayList<Double> precios, double porcentaje) {
        // TODO: Actualizar cada precio con el método set()
    }

    /**
     * Ejercicio 14: filtrarRango
     *
     * Devuelve un NUEVO ArrayList con los números que se encuentran en el intervalo [min, max] (ambos incluidos).
     *
     * @param numeros ArrayList de Integer original.
     * @param min     valor mínimo (incluido).
     * @param max     valor máximo (incluido).
     * @return Nuevo ArrayList con los números dentro del rango. Lista vacía si es null.
     *
     * Ejemplos:
     * - filtrarRango([5, 10, 15, 20, 25], 10, 20) -> [10, 15, 20]
     * - filtrarRango(null, 10, 20) -> []
     */
    public static ArrayList<Integer> filtrarRango(ArrayList<Integer> numeros, int min, int max) {
        // TODO: Filtrar los elementos que cumplan min <= x && x <= max
        return new ArrayList<>();
    }

    // =============================================================
    // BLOQUE C: LISTAS DE CLASES PROPIAS (Alumno y Producto)
    // =============================================================

    /**
     * Ejercicio 15: obtenerNombresAprobados
     *
     * Devuelve un NUEVO ArrayList<String> con los nombres de los alumnos que han aprobado
     * la asignatura (nota >= 5.0).
     *
     * @param alumnos ArrayList de objetos Alumno.
     * @return ArrayList con los nombres de los alumnos aprobados. Lista vacía si es null.
     *
     * Ejemplos:
     * - obtenerNombresAprobados([Alumno("Ane",19,8.5), Alumno("Mikel",20,4.2), Alumno("Sara",19,5.0)]) -> ["Ane", "Sara"]
     * - obtenerNombresAprobados(null) -> []
     */
    public static ArrayList<String> obtenerNombresAprobados(ArrayList<Alumno> alumnos) {
        // TODO: Usar alumno.estaAprobado() y alumno.getNombre()
        return new ArrayList<>();
    }

    /**
     * Ejercicio 16: mejorAlumno
     *
     * Devuelve el Alumno con la nota más alta. En caso de empate, el primero que aparece.
     *
     * @param alumnos ArrayList de objetos Alumno.
     * @return Objeto Alumno con la nota más alta. null si la lista es null o está vacía.
     *
     * Ejemplos:
     * - mejorAlumno([Alumno("Ane",19,7.5), Alumno("Mikel",20,9.2), Alumno("Sara",19,9.2)]) -> Mikel
     * - mejorAlumno([]) -> null
     * - mejorAlumno(null) -> null
     */
    public static Alumno mejorAlumno(ArrayList<Alumno> alumnos) {
        // TODO: Buscar el objeto Alumno con la nota más alta
        return null;
    }

    /**
     * Ejercicio 17: subirNotaATodos
     *
     * Suma los puntos indicados a la nota de todos los alumnos de la lista, sin superar el límite de 10.0.
     * Si los puntos son <= 0 o la lista es null, no hace nada.
     *
     * @param alumnos ArrayList de objetos Alumno.
     * @param puntos  cantidad de puntos a sumar (> 0).
     *
     * Ejemplos:
     * - subirNotaATodos([Alumno("Ane",19,8.0), Alumno("Mikel",20,9.5)], 1.0) -> Ane: 9.0, Mikel: 10.0
     */
    public static void subirNotaATodos(ArrayList<Alumno> alumnos, double puntos) {
        // TODO: Actualizar cada nota usando setNota() (máximo 10.0)
    }

    /**
     * Ejercicio 18: valorTotalInventario
     *
     * Calcula el valor económico total de todos los productos del almacén (suma de precio * stock de cada producto).
     *
     * @param productos ArrayList de objetos Producto.
     * @return Valor total del inventario. 0.0 si la lista es null o está vacía.
     *
     * Ejemplos:
     * - valorTotalInventario([Producto("Teclado",25.0,4), Producto("Ratón",15.0,2)]) -> 130.0
     * - valorTotalInventario(null) -> 0.0
     */
    public static double valorTotalInventario(ArrayList<Producto> productos) {
        // TODO: Sumar el valorTotal() de cada producto
        return 0.0;
    }

    /**
     * Ejercicio 19: comprarProducto
     *
     * Busca un producto por su nombre (sin distinguir mayúsculas/minúsculas). Si el producto existe
     * y tiene stock suficiente (stock >= cantidad y cantidad > 0), reduce el stock y devuelve true.
     *
     * @param productos ArrayList de objetos Producto.
     * @param nombre    nombre del producto que se desea comprar.
     * @param cantidad  número de unidades que se desean comprar.
     * @return true si la compra se ha realizado; false si el producto no existe, no hay stock suficiente o los datos son incorrectos.
     *
     * Ejemplos:
     * - comprarProducto([Producto("Teclado",25.0,5)], "teclado", 3) -> true (nuevo stock: 2)
     * - comprarProducto([Producto("Teclado",25.0,2)], "teclado", 4) -> false (el stock sigue siendo 2)
     */
    public static boolean comprarProducto(ArrayList<Producto> productos, String nombre, int cantidad) {
        // TODO: Buscar el producto, comprobar el stock y actualizarlo mediante setStock()
        return false;
    }

    /**
     * Ejercicio 20: productosBajoStock
     *
     * Devuelve un NUEVO ArrayList<Producto> con los productos que tienen un stock inferior al límite indicado (< limite).
     *
     * @param productos ArrayList de objetos Producto.
     * @param limite    umbral mínimo de stock.
     * @return Nuevo ArrayList con los productos con bajo stock. Lista vacía si la lista es null.
     *
     * Ejemplos:
     * - productosBajoStock([Producto("A",10,2), Producto("B",10,5), Producto("C",10,1)], 5) -> [A, C]
     * - productosBajoStock(null, 5) -> []
     */
    public static ArrayList<Producto> productosBajoStock(ArrayList<Producto> productos, int limite) {
        // TODO: Filtrar los productos que cumplan getStock() < limite
        return new ArrayList<>();
    }
}
