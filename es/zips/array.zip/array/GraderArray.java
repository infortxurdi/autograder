package array;

import java.util.Arrays;

public class GraderArray {

    // Códigos de colores ANSI para mostrar en la consola
    private static final String RESET = "\u001B[0m";
    private static final String RED = "\u001B[31m";
    private static final String GREEN = "\u001B[32m";
    private static final String YELLOW = "\u001B[33m";
    private static final String CYAN = "\u001B[36m";
    private static final String BOLD = "\u001B[1m";

    private static int totalPruebas = 0;
    private static int pruebasSuperadas = 0;

    public static void main(String[] args) {
        System.out.println(CYAN + "==================================================");
        System.out.println("   EVALUADOR AUTOMÁTICO DE EJERCICIOS DE ARRAYS   ");
        System.out.println("==================================================" + RESET + "\n");

        // BLOQUE A: FOR INDIZADO Y OPERACIONES SENCILLAS
        if (debeEjecutar(1)) probarSumarElementos();
        if (debeEjecutar(2)) probarCalcularPromedio();
        if (debeEjecutar(3)) probarEncontrarMaximo();
        if (debeEjecutar(4)) probarEncontrarMinimo();
        if (debeEjecutar(5)) probarContarNegativos();
        if (debeEjecutar(6)) probarContarPositivos();
        if (debeEjecutar(7)) probarRestarElementos();
        if (debeEjecutar(8)) probarSumarIndicesPares();
        if (debeEjecutar(9)) probarConvertirNegativosIndicesImpares();
        if (debeEjecutar(10)) probarObtenerTamano();
        if (debeEjecutar(11)) probarExisteElemento();
        if (debeEjecutar(12)) probarContarPares();
        if (debeEjecutar(13)) probarInvertirArray();
        if (debeEjecutar(14)) probarAnadirElemento();
        if (debeEjecutar(15)) probarEliminarElementoEnIndice();

        // BLOQUE B: BUCLE WHILE
        if (debeEjecutar(16)) probarObtenerIndicePrimerNegativo();
        if (debeEjecutar(17)) probarSumarHastaLimite();
        if (debeEjecutar(18)) probarEstaOrdenado();
        if (debeEjecutar(19)) probarEsPalindromo();
        if (debeEjecutar(20)) probarDistanciaEntreDosOcurrencias();

        // Resumen final
        double porcentaje = totalPruebas > 0 ? ((double) pruebasSuperadas / totalPruebas) * 100 : 0.0;

        System.out.println("\n" + CYAN + "==================================================" + RESET);
        System.out.printf(BOLD + " RESULTADO FINAL: %d / %d pruebas superadas (%%%.1f)\n" + RESET,
                pruebasSuperadas, totalPruebas, porcentaje);

        System.out.println(CYAN + "==================================================" + RESET);

        if (totalPruebas > 0 && pruebasSuperadas == totalPruebas) {
            System.out.println(GREEN + "🎉 ¡Excelente trabajo! Todos los métodos de arrays funcionan correctamente." + RESET);
        } else if (totalPruebas > 0) {
            System.out.println(YELLOW + "⚠️ Revisa los ejercicios marcados como [ERROR] e inténtalo de nuevo." + RESET);
        } else {
            System.out.println(YELLOW + "⚠️ No se ejecutó ninguna prueba. Revisa la configuración." + RESET);
        }
    }

    private static boolean debeEjecutar(int numeroEjercicio) {
        return ConfigGrader.RUN_ALL || ConfigGrader.EXERCISE_NUMBER == numeroEjercicio;
    }

    private static void probar(String nombrePrueba, boolean resultado, String esperado, String obtenido) {
        totalPruebas++;
        if (resultado) {
            pruebasSuperadas++;
            System.out.printf("  " + GREEN + "[OK]" + RESET + " %s\n", nombrePrueba);
        } else {
            System.out.printf("  " + RED + "[ERROR]" + RESET + " %s | Esperado: '%s' -> Obtenido: '%s'\n", nombrePrueba, esperado, obtenido);
        }
    }

    // --- PRUEBA 1: sumarElementos ---
    private static void probarSumarElementos() {
        System.out.println(BOLD + "--- Ejercicio 1: sumarElementos ---" + RESET);
        int r1 = Ejercicios.sumarElementos(new int[]{1, 2, 3, 4, 5});
        probar("Suma {1, 2, 3, 4, 5}", r1 == 15, "15", String.valueOf(r1));

        int r2 = Ejercicios.sumarElementos(new int[]{-2, 5, -3});
        probar("Suma {-2, 5, -3}", r2 == 0, "0", String.valueOf(r2));

        int r3 = Ejercicios.sumarElementos(new int[]{});
        probar("Suma con array vacío", r3 == 0, "0", String.valueOf(r3));

        int r4 = Ejercicios.sumarElementos(null);
        probar("Suma cuando es null", r4 == 0, "0", String.valueOf(r4));
    }

    // --- PRUEBA 2: calcularPromedio ---
    private static void probarCalcularPromedio() {
        System.out.println("\n" + BOLD + "--- Ejercicio 2: calcularPromedio ---" + RESET);
        double r1 = Ejercicios.calcularPromedio(new double[]{5.0, 7.0, 9.0});
        probar("Promedio {5.0, 7.0, 9.0}", Math.abs(r1 - 7.0) < 0.001, "7.0", String.valueOf(r1));

        double r2 = Ejercicios.calcularPromedio(new double[]{10.0});
        probar("Promedio {10.0}", Math.abs(r2 - 10.0) < 0.001, "10.0", String.valueOf(r2));

        double r3 = Ejercicios.calcularPromedio(new double[]{});
        probar("Promedio con array vacío", Math.abs(r3 - (-1.0)) < 0.001, "-1.0", String.valueOf(r3));

        double r4 = Ejercicios.calcularPromedio(null);
        probar("Promedio cuando es null", Math.abs(r4 - (-1.0)) < 0.001, "-1.0", String.valueOf(r4));
    }

    // --- PRUEBA 3: encontrarMaximo ---
    private static void probarEncontrarMaximo() {
        System.out.println("\n" + BOLD + "--- Ejercicio 3: encontrarMaximo ---" + RESET);
        int r1 = Ejercicios.encontrarMaximo(new int[]{3, 8, 2, 11, 4});
        probar("Máximo {3, 8, 2, 11, 4}", r1 == 11, "11", String.valueOf(r1));

        int r2 = Ejercicios.encontrarMaximo(new int[]{-10, -5, -20});
        probar("Máximo {-10, -5, -20}", r2 == -5, "-5", String.valueOf(r2));

        int r3 = Ejercicios.encontrarMaximo(new int[]{});
        probar("Máximo con array vacío", r3 == Integer.MIN_VALUE, String.valueOf(Integer.MIN_VALUE), String.valueOf(r3));

        int r4 = Ejercicios.encontrarMaximo(null);
        probar("Máximo cuando es null", r4 == Integer.MIN_VALUE, String.valueOf(Integer.MIN_VALUE), String.valueOf(r4));
    }

    // --- PRUEBA 4: encontrarMinimo ---
    private static void probarEncontrarMinimo() {
        System.out.println("\n" + BOLD + "--- Ejercicio 4: encontrarMinimo ---" + RESET);
        int r1 = Ejercicios.encontrarMinimo(new int[]{3, 8, 2, 11, 4});
        probar("Mínimo {3, 8, 2, 11, 4}", r1 == 2, "2", String.valueOf(r1));

        int r2 = Ejercicios.encontrarMinimo(new int[]{-10, -5, -20});
        probar("Mínimo {-10, -5, -20}", r2 == -20, "-20", String.valueOf(r2));

        int r3 = Ejercicios.encontrarMinimo(new int[]{});
        probar("Mínimo con array vacío", r3 == Integer.MAX_VALUE, String.valueOf(Integer.MAX_VALUE), String.valueOf(r3));

        int r4 = Ejercicios.encontrarMinimo(null);
        probar("Mínimo cuando es null", r4 == Integer.MAX_VALUE, String.valueOf(Integer.MAX_VALUE), String.valueOf(r4));
    }

    // --- PRUEBA 5: contarNegativos ---
    private static void probarContarNegativos() {
        System.out.println("\n" + BOLD + "--- Ejercicio 5: contarNegativos ---" + RESET);
        int r1 = Ejercicios.contarNegativos(new int[]{1, -2, 3, -4, -5});
        probar("Negativos {1, -2, 3, -4, -5}", r1 == 3, "3", String.valueOf(r1));

        int r2 = Ejercicios.contarNegativos(new int[]{1, 2, 3});
        probar("Cuando no hay negativos {1, 2, 3}", r2 == 0, "0", String.valueOf(r2));

        int r3 = Ejercicios.contarNegativos(null);
        probar("Negativos cuando es null", r3 == 0, "0", String.valueOf(r3));
    }

    // --- PRUEBA 6: contarPositivos ---
    private static void probarContarPositivos() {
        System.out.println("\n" + BOLD + "--- Ejercicio 6: contarPositivos ---" + RESET);
        int r1 = Ejercicios.contarPositivos(new int[]{1, -2, 3, 0, 5});
        probar("Positivos (>0) {1, -2, 3, 0, 5}", r1 == 3, "3", String.valueOf(r1));

        int r2 = Ejercicios.contarPositivos(new int[]{-1, -2, 0});
        probar("Cuando no hay positivos {-1, -2, 0}", r2 == 0, "0", String.valueOf(r2));

        int r3 = Ejercicios.contarPositivos(null);
        probar("Positivos cuando es null", r3 == 0, "0", String.valueOf(r3));
    }

    // --- PRUEBA 7: restarElementos ---
    private static void probarRestarElementos() {
        System.out.println("\n" + BOLD + "--- Ejercicio 7: restarElementos ---" + RESET);
        int r1 = Ejercicios.restarElementos(new int[]{10, 2, 3});
        probar("Resta (10 - 2 - 3)", r1 == 5, "5", String.valueOf(r1));

        int r2 = Ejercicios.restarElementos(new int[]{7});
        probar("Un solo elemento {7}", r2 == 7, "7", String.valueOf(r2));

        int r3 = Ejercicios.restarElementos(new int[]{});
        probar("Array vacío", r3 == 0, "0", String.valueOf(r3));

        int r4 = Ejercicios.restarElementos(null);
        probar("Array cuando es null", r4 == 0, "0", String.valueOf(r4));
    }

    // --- PRUEBA 8: sumarIndicesPares ---
    private static void probarSumarIndicesPares() {
        System.out.println("\n" + BOLD + "--- Ejercicio 8: sumarIndicesPares ---" + RESET);
        int r1 = Ejercicios.sumarIndicesPares(new int[]{10, 20, 30, 40, 50});
        probar("Suma (índices 0,2,4 -> 10+30+50)", r1 == 90, "90", String.valueOf(r1));

        int r2 = Ejercicios.sumarIndicesPares(new int[]{5});
        probar("Un solo elemento {5}", r2 == 5, "5", String.valueOf(r2));

        int r3 = Ejercicios.sumarIndicesPares(null);
        probar("Cuando es null", r3 == 0, "0", String.valueOf(r3));
    }

    // --- PRUEBA 9: convertirNegativosIndicesImpares ---
    private static void probarConvertirNegativosIndicesImpares() {
        System.out.println("\n" + BOLD + "--- Ejercicio 9: convertirNegativosIndicesImpares ---" + RESET);
        int[] r1 = Ejercicios.convertirNegativosIndicesImpares(new int[]{5, 4, 3, 2});
        probar("Índices impares negativos {5, 4, 3, 2}", Arrays.equals(r1, new int[]{5, -4, 3, -2}), "[5, -4, 3, -2]", Arrays.toString(r1));

        int[] r2 = Ejercicios.convertirNegativosIndicesImpares(new int[]{5, -4, 3, -2});
        probar("Ya son negativos {5, -4, 3, -2}", Arrays.equals(r2, new int[]{5, -4, 3, -2}), "[5, -4, 3, -2]", Arrays.toString(r2));

        int[] r3 = Ejercicios.convertirNegativosIndicesImpares(null);
        probar("Cuando es null", r3 != null && r3.length == 0, "[]", Arrays.toString(r3));
    }

    // --- PRUEBA 10: obtenerTamano ---
    private static void probarObtenerTamano() {
        System.out.println("\n" + BOLD + "--- Ejercicio 10: obtenerTamano ---" + RESET);
        int r1 = Ejercicios.obtenerTamano(new int[]{1, 2, 3, 4});
        probar("Tamaño {1, 2, 3, 4}", r1 == 4, "4", String.valueOf(r1));

        int r2 = Ejercicios.obtenerTamano(new int[]{});
        probar("Tamaño con array vacío", r2 == 0, "0", String.valueOf(r2));

        int r3 = Ejercicios.obtenerTamano(null);
        probar("Tamaño cuando es null", r3 == 0, "0", String.valueOf(r3));
    }

    // --- PRUEBA 11: existeElemento ---
    private static void probarExisteElemento() {
        System.out.println("\n" + BOLD + "--- Ejercicio 11: existeElemento ---" + RESET);
        String[] datos = {"Java", "Python", "C++"};
        boolean r1 = Ejercicios.existeElemento(datos, "Python");
        probar("Existe 'Python'", r1 == true, "true", String.valueOf(r1));

        boolean r2 = Ejercicios.existeElemento(datos, "PHP");
        probar("No existe 'PHP'", r2 == false, "false", String.valueOf(r2));

        boolean r3 = Ejercicios.existeElemento(null, "Java");
        probar("Array cuando es null", r3 == false, "false", String.valueOf(r3));
    }

    // --- PRUEBA 12: contarPares ---
    private static void probarContarPares() {
        System.out.println("\n" + BOLD + "--- Ejercicio 12: contarPares ---" + RESET);
        int r1 = Ejercicios.contarPares(new int[]{1, 2, 3, 4, 6, 7});
        probar("Pares {1, 2, 3, 4, 6, 7}", r1 == 3, "3", String.valueOf(r1));

        int r2 = Ejercicios.contarPares(new int[]{1, 3, 5});
        probar("Cuando no hay pares", r2 == 0, "0", String.valueOf(r2));

        int r3 = Ejercicios.contarPares(null);
        probar("Cuando es null", r3 == 0, "0", String.valueOf(r3));
    }

    // --- PRUEBA 13: invertirArray ---
    private static void probarInvertirArray() {
        System.out.println("\n" + BOLD + "--- Ejercicio 13: invertirArray ---" + RESET);
        int[] r1 = Ejercicios.invertirArray(new int[]{1, 2, 3, 4});
        probar("Invertir {1, 2, 3, 4}", Arrays.equals(r1, new int[]{4, 3, 2, 1}), "[4, 3, 2, 1]", Arrays.toString(r1));

        int[] r2 = Ejercicios.invertirArray(new int[]{7});
        probar("Un solo elemento {7}", Arrays.equals(r2, new int[]{7}), "[7]", Arrays.toString(r2));

        int[] r3 = Ejercicios.invertirArray(null);
        probar("Cuando es null", r3 != null && r3.length == 0, "[]", Arrays.toString(r3));
    }

    // --- PRUEBA 14: anadirElemento ---
    private static void probarAnadirElemento() {
        System.out.println("\n" + BOLD + "--- Ejercicio 14: anadirElemento ---" + RESET);
        int[] r1 = Ejercicios.anadirElemento(new int[]{1, 2}, 3);
        probar("Añadir 3 al array {1, 2}", Arrays.equals(r1, new int[]{1, 2, 3}), "[1, 2, 3]", Arrays.toString(r1));

        int[] r2 = Ejercicios.anadirElemento(new int[]{}, 5);
        probar("Añadir 5 a un array vacío", Arrays.equals(r2, new int[]{5}), "[5]", Arrays.toString(r2));

        int[] r3 = Ejercicios.anadirElemento(null, 5);
        probar("Añadir 5 a un array null", Arrays.equals(r3, new int[]{5}), "[5]", Arrays.toString(r3));
    }

    // --- PRUEBA 15: eliminarElementoEnIndice ---
    private static void probarEliminarElementoEnIndice() {
        System.out.println("\n" + BOLD + "--- Ejercicio 15: eliminarElementoEnIndice ---" + RESET);
        int[] r1 = Ejercicios.eliminarElementoEnIndice(new int[]{10, 20, 30, 40}, 1);
        probar("Eliminar índice 1 (20)", Arrays.equals(r1, new int[]{10, 30, 40}), "[10, 30, 40]", Arrays.toString(r1));

        int[] r2 = Ejercicios.eliminarElementoEnIndice(new int[]{10, 20}, 5);
        probar("Índice fuera de rango (5)", Arrays.equals(r2, new int[]{10, 20}), "[10, 20]", Arrays.toString(r2));

        int[] r3 = Ejercicios.eliminarElementoEnIndice(null, 0);
        probar("Cuando es null", r3 != null && r3.length == 0, "[]", Arrays.toString(r3));
    }

    // --- PRUEBA 16: obtenerIndicePrimerNegativo ---
    private static void probarObtenerIndicePrimerNegativo() {
        System.out.println("\n" + BOLD + "--- Ejercicio 16: obtenerIndicePrimerNegativo (while) ---" + RESET);
        int r1 = Ejercicios.obtenerIndicePrimerNegativo(new int[]{5, 8, -3, 10, -2});
        probar("Primer negativo {5, 8, -3, 10, -2}", r1 == 2, "2", String.valueOf(r1));

        int r2 = Ejercicios.obtenerIndicePrimerNegativo(new int[]{1, 2, 3});
        probar("Sin negativos {1, 2, 3}", r2 == -1, "-1", String.valueOf(r2));

        int r3 = Ejercicios.obtenerIndicePrimerNegativo(null);
        probar("Cuando es null", r3 == -1, "-1", String.valueOf(r3));
    }

    // --- PRUEBA 17: sumarHastaLimite ---
    private static void probarSumarHastaLimite() {
        System.out.println("\n" + BOLD + "--- Ejercicio 17: sumarHastaLimite (while) ---" + RESET);
        int r1 = Ejercicios.sumarHastaLimite(new int[]{10, 20, 15, 30}, 40);
        probar("Suma {10, 20, 15, 30} límite 40", r1 == 35, "35", String.valueOf(r1));

        int r2 = Ejercicios.sumarHastaLimite(new int[]{50, 10}, 40);
        probar("Cuando el primero supera el límite", r2 == 0, "0", String.valueOf(r2));

        int r3 = Ejercicios.sumarHastaLimite(null, 40);
        probar("Cuando es null", r3 == 0, "0", String.valueOf(r3));
    }

    // --- PRUEBA 18: estaOrdenado ---
    private static void probarEstaOrdenado() {
        System.out.println("\n" + BOLD + "--- Ejercicio 18: estaOrdenado (while) ---" + RESET);
        boolean r1 = Ejercicios.estaOrdenado(new int[]{1, 3, 5, 7, 9});
        probar("Ordenado {1, 3, 5, 7, 9}", r1 == true, "true", String.valueOf(r1));

        boolean r2 = Ejercicios.estaOrdenado(new int[]{1, 5, 3, 7});
        probar("Desordenado {1, 5, 3, 7}", r2 == false, "false", String.valueOf(r2));

        boolean r3 = Ejercicios.estaOrdenado(new int[]{4});
        probar("Un solo elemento {4}", r3 == true, "true", String.valueOf(r3));

        boolean r4 = Ejercicios.estaOrdenado(null);
        probar("Cuando es null", r4 == false, "false", String.valueOf(r4));
    }

    // --- PRUEBA 19: esPalindromo ---
    private static void probarEsPalindromo() {
        System.out.println("\n" + BOLD + "--- Ejercicio 19: esPalindromo (while) ---" + RESET);
        boolean r1 = Ejercicios.esPalindromo(new int[]{1, 2, 3, 2, 1});
        probar("Palíndromo {1, 2, 3, 2, 1}", r1 == true, "true", String.valueOf(r1));

        boolean r2 = Ejercicios.esPalindromo(new int[]{1, 2, 2, 1});
        probar("Palíndromo {1, 2, 2, 1}", r2 == true, "true", String.valueOf(r2));

        boolean r3 = Ejercicios.esPalindromo(new int[]{1, 2, 3, 4});
        probar("No es palíndromo {1, 2, 3, 4}", r3 == false, "false", String.valueOf(r3));

        boolean r4 = Ejercicios.esPalindromo(null);
        probar("Cuando es null", r4 == false, "false", String.valueOf(r4));
    }

    // --- PRUEBA 20: distanciaEntreDosOcurrencias ---
    private static void probarDistanciaEntreDosOcurrencias() {
        System.out.println("\n" + BOLD + "--- Ejercicio 20: distanciaEntreDosOcurrencias (while) ---" + RESET);
        int r1 = Ejercicios.distanciaEntreDosOcurrencias(new int[]{4, 7, 2, 7, 9, 7}, 7);
        probar("Distancia {4, 7, 2, 7, 9, 7} (objetivo 7)", r1 == 2, "2", String.valueOf(r1));

        int r2 = Ejercicios.distanciaEntreDosOcurrencias(new int[]{1, 5, 3}, 5);
        probar("Una sola ocurrencia {1, 5, 3} (objetivo 5)", r2 == -1, "-1", String.valueOf(r2));

        int r3 = Ejercicios.distanciaEntreDosOcurrencias(new int[]{3, 3}, 3);
        probar("Consecutivos {3, 3} (objetivo 3)", r3 == 1, "1", String.valueOf(r3));

        int r4 = Ejercicios.distanciaEntreDosOcurrencias(null, 7);
        probar("Cuando es null", r4 == -1, "-1", String.valueOf(r4));
    }
}
