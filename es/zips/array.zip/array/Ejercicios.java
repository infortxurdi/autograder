package array;

public class Ejercicios {

    // =============================================================
    // BLOQUE A: FOR INDIZADO (for (int i = 0; i < array.length; i++))
    // =============================================================

    /**
     * Ejercicio 1: sumarElementos
     *
     * Calcula la suma de todos los elementos de un array de enteros.
     *
     * @param numeros array de enteros a analizar.
     * @return Suma total de todos los elementos. 0 si el array es nulo o está vacío.
     *
     * Ejemplos:
     * - sumarElementos(new int[]{1, 2, 3, 4, 5}) -> 15
     * - sumarElementos(new int[]{-2, 5, -3}) -> 0
     * - sumarElementos(new int[]{}) -> 0
     * - sumarElementos(null) -> 0
     */
    public static int sumarElementos(int[] numeros) {
        // TODO: Implementar usando un bucle 'for' indizado
        return 0;
    }

    /**
     * Ejercicio 2: calcularPromedio
     *
     * Calcula el promedio de las calificaciones (double).
     *
     * @param notas array de double que contiene las calificaciones.
     * @return Promedio aritmético de las notas. -1.0 si el array es nulo o está vacío.
     *
     * Ejemplos:
     * - calcularPromedio(new double[]{5.0, 7.0, 9.0}) -> 7.0
     * - calcularPromedio(new double[]{10.0}) -> 10.0
     * - calcularPromedio(new double[]{}) -> -1.0
     * - calcularPromedio(null) -> -1.0
     */
    public static double calcularPromedio(double[] notas) {
        // TODO: Implementar usando un bucle 'for' indizado
        return -1.0;
    }

    /**
     * Ejercicio 3: encontrarMaximo
     *
     * Encuentra el valor máximo de un array.
     *
     * @param numeros array de enteros.
     * @return El valor máximo del array. Integer.MIN_VALUE si el array es nulo o está vacío.
     *
     * Ejemplos:
     * - encontrarMaximo(new int[]{3, 8, 2, 11, 4}) -> 11
     * - encontrarMaximo(new int[]{-10, -5, -20}) -> -5
     * - encontrarMaximo(new int[]{}) -> Integer.MIN_VALUE (-2147483648)
     * - encontrarMaximo(null) -> Integer.MIN_VALUE (-2147483648)
     */
    public static int encontrarMaximo(int[] numeros) {
        // TODO: Implementar usando un bucle 'for' indizado
        return Integer.MIN_VALUE;
    }

    /**
     * Ejercicio 4: encontrarMinimo
     *
     * Encuentra el valor mínimo de un array.
     *
     * @param numeros array de enteros.
     * @return El valor mínimo del array. Integer.MAX_VALUE si el array es nulo o está vacío.
     *
     * Ejemplos:
     * - encontrarMinimo(new int[]{3, 8, 2, 11, 4}) -> 2
     * - encontrarMinimo(new int[]{-10, -5, -20}) -> -20
     * - encontrarMinimo(new int[]{}) -> Integer.MAX_VALUE (2147483647)
     * - encontrarMinimo(null) -> Integer.MAX_VALUE (2147483647)
     */
    public static int encontrarMinimo(int[] numeros) {
        // TODO: Implementar usando un bucle 'for' indizado
        return Integer.MAX_VALUE;
    }

    /**
     * Ejercicio 5: contarNegativos
     *
     * Cuenta cuántos números negativos (< 0) hay en el array.
     *
     * @param numeros array de enteros.
     * @return Cantidad de números negativos. 0 si el array es nulo/vacío o no hay negativos.
     *
     * Ejemplos:
     * - contarNegativos(new int[]{1, -2, 3, -4, -5}) -> 3
     * - contarNegativos(new int[]{1, 2, 3}) -> 0
     * - contarNegativos(null) -> 0
     */
    public static int contarNegativos(int[] numeros) {
        // TODO: Implementar usando un bucle 'for' indizado
        return 0;
    }

    /**
     * Ejercicio 6: contarPositivos
     *
     * Cuenta cuántos números positivos (> 0) hay en el array (el 0 no es positivo).
     *
     * @param numeros array de enteros.
     * @return Cantidad de números positivos. 0 si el array es nulo/vacío o no hay positivos.
     *
     * Ejemplos:
     * - contarPositivos(new int[]{1, -2, 3, 0, 5}) -> 3
     * - contarPositivos(new int[]{-1, -2, 0}) -> 0
     * - contarPositivos(null) -> 0
     */
    public static int contarPositivos(int[] numeros) {
        // TODO: Implementar usando un bucle 'for' indizado
        return 0;
    }

    /**
     * Ejercicio 7: restarElementos
     *
     * Resta secuencialmente al primer elemento todos los demás elementos del array.
     *
     * @param numeros array de enteros.
     * @return Resultado de la resta. 0 si el array es nulo o está vacío.
     *
     * Ejemplos:
     * - restarElementos(new int[]{10, 2, 3}) -> 5  (10 - 2 - 3)
     * - restarElementos(new int[]{7}) -> 7
     * - restarElementos(new int[]{}) -> 0
     * - restarElementos(null) -> 0
     */
    public static int restarElementos(int[] numeros) {
        // TODO: Implementar usando un bucle 'for' indizado
        return 0;
    }

    /**
     * Ejercicio 8: sumarIndicesPares
     *
     * Suma únicamente los números situados en índices pares (0, 2, 4...).
     *
     * @param numeros array de enteros.
     * @return Suma de los valores en índices pares. 0 si el array es nulo o está vacío.
     *
     * Ejemplos:
     * - sumarIndicesPares(new int[]{10, 20, 30, 40, 50}) -> 90  (índices 0, 2, 4 -> 10 + 30 + 50)
     * - sumarIndicesPares(new int[]{5}) -> 5                    (índice 0 -> 5)
     * - sumarIndicesPares(null) -> 0
     */
    public static int sumarIndicesPares(int[] numeros) {
        // TODO: Implementar usando un bucle 'for' indizado
        return 0;
    }

    /**
     * Ejercicio 9: convertirNegativosIndicesImpares
     *
     * Devuelve un nuevo array con todos los valores de los índices impares (1, 3, 5...) convertidos en números negativos.
     *
     * @param numeros array original de enteros.
     * @return Nuevo array con los valores modificados. new int[0] si el array es nulo.
     *
     * Ejemplos:
     * - convertirNegativosIndicesImpares(new int[]{5, 4, 3, 2}) -> {5, -4, 3, -2}
     * - convertirNegativosIndicesImpares(new int[]{5, -4, 3, -2}) -> {5, -4, 3, -2}
     * - convertirNegativosIndicesImpares(null) -> {}
     */
    public static int[] convertirNegativosIndicesImpares(int[] numeros) {
        // TODO: Implementar usando un bucle 'for' indizado
        return new int[0];
    }

    /**
     * Ejercicio 10: obtenerTamano
     *
     * Devuelve el tamaño (número de elementos) del array.
     *
     * @param numeros array de enteros.
     * @return Longitud del array. 0 si el array es nulo.
     *
     * Ejemplos:
     * - obtenerTamano(new int[]{1, 2, 3, 4}) -> 4
     * - obtenerTamano(new int[]{}) -> 0
     * - obtenerTamano(null) -> 0
     */
    public static int obtenerTamano(int[] numeros) {
        // TODO: Implementar obteniendo el tamaño
        return 0;
    }

    /**
     * Ejercicio 11: existeElemento
     *
     * Busca si un texto determinado se encuentra dentro del array.
     *
     * @param palabras array de cadenas (String).
     * @param buscado texto que se desea buscar.
     * @return true si el texto está en el array; false en caso contrario o si los valores son nulos.
     *
     * Ejemplos:
     * - existeElemento(new String[]{"Java", "Python", "C++"}, "Python") -> true
     * - existeElemento(new String[]{"Java", "Python", "C++"}, "PHP") -> false
     * - existeElemento(null, "Java") -> false
     */
    public static boolean existeElemento(String[] palabras, String buscado) {
        // TODO: Implementar usando un bucle 'for' indizado
        return false;
    }

    /**
     * Ejercicio 12: contarPares
     *
     * Cuenta cuántos números pares hay en un array.
     *
     * @param numeros array de enteros.
     * @return Cantidad de números pares. 0 si el array es nulo o no hay pares.
     *
     * Ejemplos:
     * - contarPares(new int[]{1, 2, 3, 4, 6, 7}) -> 3
     * - contarPares(new int[]{1, 3, 5}) -> 0
     * - contarPares(null) -> 0
     */
    public static int contarPares(int[] numeros) {
        // TODO: Implementar usando un bucle 'for' indizado
        return 0;
    }

    /**
     * Ejercicio 13: invertirArray
     *
     * Crea un nuevo array colocando los elementos del original en orden inverso.
     *
     * @param numeros array original de enteros.
     * @return Nuevo array con los elementos invertidos. new int[0] si el array es nulo.
     *
     * Ejemplos:
     * - invertirArray(new int[]{1, 2, 3, 4}) -> {4, 3, 2, 1}
     * - invertirArray(new int[]{7}) -> {7}
     * - invertirArray(null) -> {}
     */
    public static int[] invertirArray(int[] numeros) {
        // TODO: Implementar usando un bucle 'for' indizado
        return new int[0];
    }

    /**
     * Ejercicio 14: anadirElemento
     *
     * Crea un nuevo array añadiendo un nuevo valor al final del original.
     *
     * @param numeros array original.
     * @param nuevo nuevo valor entero a añadir.
     * @return Nuevo array con un elemento más. {nuevo} si el original es nulo.
     *
     * Ejemplos:
     * - anadirElemento(new int[]{1, 2}, 3) -> {1, 2, 3}
     * - anadirElemento(new int[]{}, 5) -> {5}
     * - anadirElemento(null, 5) -> {5}
     */
    public static int[] anadirElemento(int[] numeros, int nuevo) {
        // TODO: Implementar creando un nuevo array y haciendo copias
        return new int[0];
    }

    /**
     * Ejercicio 15: eliminarElementoEnIndice
     *
     * Crea un nuevo array eliminando el elemento situado en el índice indicado.
     *
     * @param numeros array original.
     * @param indice posición que se desea eliminar (empezando en 0).
     * @return Nuevo array con un elemento menos. Copia del original si el índice es incorrecto.
     *
     * Ejemplos:
     * - eliminarElementoEnIndice(new int[]{10, 20, 30, 40}, 1) -> {10, 30, 40}
     * - eliminarElementoEnIndice(new int[]{10, 20}, 5) -> {10, 20}
     * - eliminarElementoEnIndice(null, 0) -> {}
     */
    public static int[] eliminarElementoEnIndice(int[] numeros, int indice) {
        // TODO: Implementar creando un nuevo array dejando fuera el índice seleccionado
        return new int[0];
    }

    // =============================================================
    // BLOQUE B: BUCLE WHILE
    // =============================================================

    /**
     * Ejercicio 16: obtenerIndicePrimerNegativo
     *
     * Encuentra el índice del primer número negativo en el array usando 'while'.
     *
     * @param numeros array de enteros.
     * @return Índice del primer número negativo. -1 si no hay negativos o si el array es nulo.
     *
     * Ejemplos:
     * - obtenerIndicePrimerNegativo(new int[]{5, 8, -3, 10, -2}) -> 2
     * - obtenerIndicePrimerNegativo(new int[]{1, 2, 3}) -> -1
     * - obtenerIndicePrimerNegativo(null) -> -1
     */
    public static int obtenerIndicePrimerNegativo(int[] numeros) {
        // TODO: Implementar usando un bucle 'while'
        return -1;
    }

    /**
     * Ejercicio 17: sumarHastaLimite
     *
     * Suma los números desde el primer elemento hasta alcanzar un límite (sin superarlo) usando 'while'.
     *
     * @param numeros array de enteros.
     * @param limite valor máximo que no puede superar la suma.
     * @return Suma máxima obtenida. 0 si el primer elemento es > limite o si el array es nulo.
     *
     * Ejemplos:
     * - sumarHastaLimite(new int[]{10, 20, 15, 30}, 40) -> 35  (10 + 20 <= 40; como 10 + 20 + 15 > 40 se detiene)
     * - sumarHastaLimite(new int[]{50, 10}, 40) -> 0          (como 50 > 40 no puede sumar ninguno)
     * - sumarHastaLimite(null, 40) -> 0
     */
    public static int sumarHastaLimite(int[] numeros, int limite) {
        // TODO: Implementar usando un bucle 'while'
        return 0;
    }

    /**
     * Ejercicio 18: estaOrdenado
     *
     * Comprueba si un array está ordenado en orden ascendente usando 'while'.
     *
     * @param numeros array de enteros a analizar.
     * @return true si está ordenado ascendentemente o tiene 0-1 elementos; false si está desordenado o es nulo.
     *
     * Ejemplos:
     * - estaOrdenado(new int[]{1, 3, 5, 7, 9}) -> true
     * - estaOrdenado(new int[]{1, 5, 3, 7}) -> false
     * - estaOrdenado(new int[]{4}) -> true
     * - estaOrdenado(null) -> false
     */
    public static boolean estaOrdenado(int[] numeros) {
        // TODO: Implementar usando un bucle 'while'
        return false;
    }

    /**
     * Ejercicio 19: esPalindromo
     *
     * Analiza si un array es un palíndromo usando 'while'.
     *
     * @param numeros array de enteros.
     * @return true si es palíndromo; false si no lo es o si es nulo.
     *
     * Ejemplos:
     * - esPalindromo(new int[]{1, 2, 3, 2, 1}) -> true
     * - esPalindromo(new int[]{1, 2, 2, 1}) -> true
     * - esPalindromo(new int[]{1, 2, 3, 4}) -> false
     * - esPalindromo(null) -> false
     */
    public static boolean esPalindromo(int[] numeros) {
        // TODO: Implementar usando un bucle 'while' combinando dos punteros
        return false;
    }

    /**
     * Ejercicio 20: distanciaEntreDosOcurrencias
     *
     * Calcula la distancia (diferencia de índices) entre las dos primeras ocurrencias del valor objetivo usando 'while'.
     *
     * @param numeros array a analizar.
     * @param objetivo valor que se desea buscar.
     * @return Distancia entre las dos ocurrencias (indice2 - indice1). -1 si no aparece al menos dos veces.
     *
     * Ejemplos:
     * - distanciaEntreDosOcurrencias(new int[]{4, 7, 2, 7, 9, 7}, 7) -> 2  (aparece en índices 1 y 3 -> 3 - 1 = 2)
     * - distanciaEntreDosOcurrencias(new int[]{1, 5, 3}, 5) -> -1           (solo aparece una vez)
     * - distanciaEntreDosOcurrencias(new int[]{3, 3}, 3) -> 1              (aparece en índices 0 y 1 -> 1 - 0 = 1)
     * - distanciaEntreDosOcurrencias(null, 7) -> -1
     */
    public static int distanciaEntreDosOcurrencias(int[] numeros, int objetivo) {
        // TODO: Implementar usando un bucle 'while'
        return -1;
    }
}
