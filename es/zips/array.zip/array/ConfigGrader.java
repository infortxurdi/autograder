package array;

public class ConfigGrader {

    // true  -> Ejecuta todas las pruebas (1 a 20)
    // false -> Ejecuta solo el ejercicio indicado en EXERCISE_NUMBER
    public static final boolean RUN_ALL = false;

    // Número del ejercicio a probar cuando RUN_ALL = false (del 1 al 20)
    //  1: sumarElementos                  11: existeElemento
    //  2: calcularPromedio                12: contarPares
    //  3: encontrarMaximo                 13: invertirArray
    //  4: encontrarMinimo                 14: anadirElemento
    //  5: contarNegativos                 15: eliminarElementoEnIndice
    //  6: contarPositivos                 16: obtenerIndicePrimerNegativo
    //  7: restarElementos                 17: sumarHastaLimite
    //  8: sumarIndicesPares               18: estaOrdenado
    //  9: convertirNegativosIndicesImpares19: esPalindromo
    // 10: obtenerTamano                   20: distanciaEntreDosOcurrencias
    public static final int EXERCISE_NUMBER = 1;
}
