package estructurasControl;

public class Ejercicios {

    // =============================================================
    // BLOQUE A: IF / ELSE
    // =============================================================

    /**
     * Ejercicio 1: esParString
     *
     * Determina si un número es par o impar mediante un texto.
     *
     * @param numero número entero a analizar.
     * @return Resultados posibles:
     *         - "Par" (cuando el número es par)
     *         - "Impar" (cuando el número es impar)
     */
    public static String esParString(int numero) {
        // TODO: Implementar lógica usando if / else
        return "";
    }

    /**
     * Ejercicio 2: esParBoolean
     *
     * Comprueba si un número es par o no mediante un valor booleano.
     *
     * @param numero número entero a analizar.
     * @return Resultados posibles:
     *         - true (si el número es par)
     *         - false (si el número es impar)
     */
    public static boolean esParBoolean(int numero) {
        // TODO: Implementar lógica usando if / else
        return false;
    }

    /**
     * Ejercicio 3: determinarSigno
     *
     * Determina si un número es positivo, negativo o cero.
     *
     * @param numero número entero a analizar.
     * @return Resultados posibles:
     *         - "Positivo" (cuando el número > 0)
     *         - "Negativo" (cuando el número < 0)
     *         - "Cero" (cuando el número == 0)
     */
    public static String determinarSigno(int numero) {
        // TODO: Implementar lógica usando if / else / else if
        return "";
    }

    /**
     * Ejercicio 4: clasificarNota
     *
     * Devuelve el texto de calificación según una nota numérica.
     *
     * @param nota nota del estudiante (de tipo double).
     * @return Resultados posibles:
     *         - "Sobresaliente" (cuando nota >= 9.0)
     *         - "Notable" (cuando nota >= 7.0 y < 9.0)
     *         - "Suficiente" (cuando nota >= 5.0 y < 7.0)
     *         - "Insuficiente" (cuando nota >= 0.0 y < 5.0)
     *         - "Nota no válida" (cuando nota < 0.0 o nota > 10.0)
     */
    public static String clasificarNota(double nota) {
        // TODO: Implementar lógica usando if / else / else if
        return "";
    }

    /**
     * Ejercicio 5: determinarMayor
     *
     * Devuelve cuál es el mayor de dos números.
     *
     * @param a primer número entero.
     * @param b segundo número entero.
     * @return El mayor de los dos números (si son iguales, cualquiera de ellos).
     */
    public static int determinarMayor(int a, int b) {
        // TODO: Implementar lógica usando if / else
        return 0;
    }

    /**
     * Ejercicio 6: clasificarCategoriaEdad
     *
     * Determina la categoría de una persona según su edad.
     *
     * @param edad edad de la persona en años.
     * @return Resultados posibles:
     *         - "Menor de edad" (cuando edad < 18)
     *         - "Adulto" (cuando edad >= 18 y < 65)
     *         - "Persona mayor" (cuando edad >= 65)
     *         - "Edad no válida" (cuando edad < 0)
     */
    public static String clasificarCategoriaEdad(int edad) {
        // TODO: Implementar lógica usando if / else / else if
        return "";
    }

    /**
     * Ejercicio 7: calcularDescuento
     *
     * Calcula el precio final aplicando el descuento correspondiente.
     * Los menores de edad (20%) y los socios adultos (10%) tienen descuento.
     *
     * @param precio precio original.
     * @param esSocio si la persona es socia o no.
     * @param edad edad de la persona en años.
     * @return Resultados posibles:
     *         - Nuevo precio tras aplicar el descuento (de tipo double).
     */
    public static double calcularDescuento(double precio, boolean esSocio, int edad) {
        // TODO: Implementar lógica de descuentos combinando if / else
        return 0.0;
    }

    /**
     * Ejercicio 8: esAnoBisiesto
     *
     * Comprueba si un año es bisiesto o no.
     * (Un año es bisiesto si es divisible por 4 y no por 100, o si es divisible por 400).
     *
     * @param ano año a analizar.
     * @return Resultados posibles:
     *         - true (si el año es bisiesto)
     *         - false (si el año no es bisiesto)
     */
    public static boolean esAnoBisiesto(int ano) {
        // TODO: Implementar lógica usando if / else
        return false;
    }

    // =============================================================
    // BLOQUE B: SWITCH / CASE
    // =============================================================

    /**
     * Ejercicio 9: obtenerNombreDia
     *
     * Recibiendo el número del día de la semana (del 1 al 7), devuelve su nombre en texto.
     *
     * @param dia número del día (1-7).
     * @return Resultados posibles:
     *         - "Lunes" (cuando es 1)
     *         - "Martes" (cuando es 2)
     *         - "Miércoles" (cuando es 3)
     *         - "Jueves" (cuando es 4)
     *         - "Viernes" (cuando es 5)
     *         - "Sábado" (cuando es 6)
     *         - "Domingo" (cuando es 7)
     *         - "Día no válido" (para el resto de números)
     */
    public static String obtenerNombreDia(int dia) {
        // TODO: Implementar usando switch / case
        return "";
    }

    /**
     * Ejercicio 10: esFinDeSemana
     *
     * Determina si es día laborable o fin de semana según el número de día.
     *
     * @param dia número del día (1-7).
     * @return Resultados posibles:
     *         - "Laborable" (cuando es del 1 al 5)
     *         - "Fin de semana" (cuando es 6 o 7)
     *         - "Día no válido" (para el resto de números)
     */
    public static String esFinDeSemana(int dia) {
        // TODO: Implementar usando switch / case
        return "";
    }

    /**
     * Ejercicio 11: realizarOperacion
     *
     * Realiza una operación matemática entre dos números según el operador proporcionado.
     *
     * @param a primer número.
     * @param b segundo número.
     * @param operador símbolo de la operación ('+', '-', '*', '/').
     * @return Resultado entero de la operación (o 0 si se divide por cero o el operador es incorrecto).
     */
    public static int realizarOperacion(int a, int b, char operador) {
        // TODO: Implementar usando switch / case
        return 0;
    }

    /**
     * Ejercicio 12: obtenerEstacion
     *
     * Devuelve la estación del año correspondiente según el número de mes (1-12).
     *
     * @param mes número del mes (1-12).
     * @return Resultados posibles:
     *         - "Invierno" (cuando es 12, 1, 2)
     *         - "Primavera" (cuando es 3, 4, 5)
     *         - "Verano" (cuando es 6, 7, 8)
     *         - "Otoño" (cuando es 9, 10, 11)
     *         - "Mes no válido" (para el resto de números)
     */
    public static String obtenerEstacion(int mes) {
        // TODO: Implementar usando switch / case con casos agrupados
        return "";
    }

    /**
     * Ejercicio 13: diasDelMes
     *
     * Devuelve el número de días que tiene un mes (asumiendo que el año no es bisiesto).
     *
     * @param mes número del mes (1-12).
     * @return Resultados posibles:
     *         - 31 (en los meses 1, 3, 5, 7, 8, 10, 12)
     *         - 30 (en los meses 4, 6, 9, 11)
     *         - 28 (en el mes 2)
     *         - -1 (si el mes no está en el rango 1-12)
     */
    public static int diasDelMes(int mes) {
        // TODO: Implementar usando switch / case con casos agrupados
        return -1;
    }
}
