package estructurasControl;

public class GraderEstructurasControl {

    // Códigos de colores ANSI para mostrar en la consola
    private static final String RESET = "\u001B[0m";
    private static final String RED = "\u001B[31m";
    private static final String GREEN = "\u001B[32m";
    private static final String YELLOW = "\u001B[33m";
    private static final String CYAN = "\u001B[36m";
    private static final String BOLD = "\u001B[1m";

    private static int totalPruebas = 0;
    private static int pruebasSuperadas = 0;

    public static void main(String[] args) {
        System.out.println(CYAN + "==================================================");
        System.out.println("   EVALUADOR AUTOMÁTICO DE ESTRUCTURAS DE CONTROL ");
        System.out.println("==================================================" + RESET + "\n");

        // Evaluaciones del Bloque A (IF / ELSE)
        if (debeEjecutar(1)) probarEsParString();
        if (debeEjecutar(2)) probarEsParBoolean();
        if (debeEjecutar(3)) probarDeterminarSigno();
        if (debeEjecutar(4)) probarClasificarNota();
        if (debeEjecutar(5)) probarDeterminarMayor();
        if (debeEjecutar(6)) probarClasificarCategoriaEdad();
        if (debeEjecutar(7)) probarCalcularDescuento();
        if (debeEjecutar(8)) probarEsAnoBisiesto();

        // Evaluaciones del Bloque B (SWITCH / CASE)
        if (debeEjecutar(9)) probarObtenerNombreDia();
        if (debeEjecutar(10)) probarEsFinDeSemana();
        if (debeEjecutar(11)) probarRealizarOperacion();
        if (debeEjecutar(12)) probarObtenerEstacion();
        if (debeEjecutar(13)) probarDiasDelMes();

        // Resumen final
        double porcentaje = totalPruebas > 0 ? ((double) pruebasSuperadas / totalPruebas) * 100 : 0.0;

        System.out.println("\n" + CYAN + "==================================================" + RESET);
        System.out.printf(BOLD + " RESULTADO FINAL: %d / %d pruebas superadas (%%%.1f)\n" + RESET,
                pruebasSuperadas, totalPruebas, porcentaje);

        System.out.println(CYAN + "==================================================" + RESET);

        if (totalPruebas > 0 && pruebasSuperadas == totalPruebas) {
            System.out.println(GREEN + "🎉 ¡Excelente trabajo! Todos los métodos funcionan correctamente." + RESET);
        } else if (totalPruebas > 0) {
            System.out.println(YELLOW + "⚠️ Revisa los ejercicios marcados como [ERROR] e inténtalo de nuevo." + RESET);
        } else {
            System.out.println(YELLOW + "⚠️ No se ejecutó ninguna prueba. Revisa la configuración." + RESET);
        }
    }

    private static boolean debeEjecutar(int numeroEjercicio) {
        return GraderConfig.RUN_ALL || GraderConfig.EXERCISE_NUMBER == numeroEjercicio;
    }

    private static void probar(String nombrePrueba, boolean resultado, String esperado, String obtenido) {
        totalPruebas++;
        if (resultado) {
            pruebasSuperadas++;
            System.out.printf("  " + GREEN + "[OK]" + RESET + " %s\n", nombrePrueba);
        } else {
            System.out.printf("  " + RED + "[ERROR]" + RESET + " %s | Esperado: '%s' -> Obtenido: '%s'\n", nombrePrueba, esperado, obtenido);
        }
    }

    // --- PRUEBA 1: esParString ---
    private static void probarEsParString() {
        System.out.println(BOLD + "--- Ejercicio 1: esParString ---" + RESET);
        String r1 = Ejercicios.esParString(4);
        probar("Paridad (4)", "Par".equalsIgnoreCase(r1), "Par", r1);

        String r2 = Ejercicios.esParString(7);
        probar("Paridad (7)", "Impar".equalsIgnoreCase(r2), "Impar", r2);

        String r3 = Ejercicios.esParString(0);
        probar("Paridad (0)", "Par".equalsIgnoreCase(r3), "Par", r3);
    }

    // --- PRUEBA 2: esParBoolean ---
    private static void probarEsParBoolean() {
        System.out.println("\n" + BOLD + "--- Ejercicio 2: esParBoolean ---" + RESET);
        boolean r1 = Ejercicios.esParBoolean(4);
        probar("Es par (4)", r1 == true, "true", String.valueOf(r1));

        boolean r2 = Ejercicios.esParBoolean(7);
        probar("Es par (7)", r2 == false, "false", String.valueOf(r2));

        boolean r3 = Ejercicios.esParBoolean(0);
        probar("Es par (0)", r3 == true, "true", String.valueOf(r3));
    }

    // --- PRUEBA 3: determinarSigno ---
    private static void probarDeterminarSigno() {
        System.out.println("\n" + BOLD + "--- Ejercicio 3: determinarSigno ---" + RESET);
        String r1 = Ejercicios.determinarSigno(15);
        probar("Signo (15)", "Positivo".equalsIgnoreCase(r1), "Positivo", r1);

        String r2 = Ejercicios.determinarSigno(-8);
        probar("Signo (-8)", "Negativo".equalsIgnoreCase(r2), "Negativo", r2);

        String r3 = Ejercicios.determinarSigno(0);
        probar("Signo (0)", "Cero".equalsIgnoreCase(r3), "Cero", r3);
    }

    // --- PRUEBA 4: clasificarNota ---
    private static void probarClasificarNota() {
        System.out.println("\n" + BOLD + "--- Ejercicio 4: clasificarNota ---" + RESET);
        String r1 = Ejercicios.clasificarNota(9.5);
        probar("Nota 9.5", "Sobresaliente".equalsIgnoreCase(r1), "Sobresaliente", r1);

        String r2 = Ejercicios.clasificarNota(7.5);
        probar("Nota 7.5", "Notable".equalsIgnoreCase(r2), "Notable", r2);

        String r3 = Ejercicios.clasificarNota(5.0);
        probar("Nota 5.0", "Suficiente".equalsIgnoreCase(r3), "Suficiente", r3);

        String r4 = Ejercicios.clasificarNota(3.2);
        probar("Nota 3.2", "Insuficiente".equalsIgnoreCase(r4), "Insuficiente", r4);

        String r5 = Ejercicios.clasificarNota(-1.0);
        probar("Nota no válida (-1.0)", "Nota no válida".equalsIgnoreCase(r5), "Nota no válida", r5);
    }

    // --- PRUEBA 5: determinarMayor ---
    private static void probarDeterminarMayor() {
        System.out.println("\n" + BOLD + "--- Ejercicio 5: determinarMayor ---" + RESET);
        int r1 = Ejercicios.determinarMayor(10, 5);
        probar("Mayor (10, 5)", r1 == 10, "10", String.valueOf(r1));

        int r2 = Ejercicios.determinarMayor(-3, 7);
        probar("Mayor (-3, 7)", r2 == 7, "7", String.valueOf(r2));

        int r3 = Ejercicios.determinarMayor(4, 4);
        probar("Mayor (4, 4)", r3 == 4, "4", String.valueOf(r3));
    }

    // --- PRUEBA 6: clasificarCategoriaEdad ---
    private static void probarClasificarCategoriaEdad() {
        System.out.println("\n" + BOLD + "--- Ejercicio 6: clasificarCategoriaEdad ---" + RESET);
        String r1 = Ejercicios.clasificarCategoriaEdad(12);
        probar("Edad 12", "Menor de edad".equalsIgnoreCase(r1), "Menor de edad", r1);

        String r2 = Ejercicios.clasificarCategoriaEdad(25);
        probar("Edad 25", "Adulto".equalsIgnoreCase(r2), "Adulto", r2);

        String r3 = Ejercicios.clasificarCategoriaEdad(70);
        probar("Edad 70", "Persona mayor".equalsIgnoreCase(r3), "Persona mayor", r3);

        String r4 = Ejercicios.clasificarCategoriaEdad(-5);
        probar("Edad no válida (-5)", "Edad no válida".equalsIgnoreCase(r4), "Edad no válida", r4);
    }

    // --- PRUEBA 7: calcularDescuento ---
    private static void probarCalcularDescuento() {
        System.out.println("\n" + BOLD + "--- Ejercicio 7: calcularDescuento ---" + RESET);
        double r1 = Ejercicios.calcularDescuento(100.0, false, 15);
        probar("Descuento menor de edad", Math.abs(r1 - 80.0) < 0.001, "80.0", String.valueOf(r1));

        double r2 = Ejercicios.calcularDescuento(100.0, true, 30);
        probar("Descuento adulto socio", Math.abs(r2 - 90.0) < 0.001, "90.0", String.valueOf(r2));

        double r3 = Ejercicios.calcularDescuento(100.0, false, 30);
        probar("Sin descuento (adulto no socio)", Math.abs(r3 - 100.0) < 0.001, "100.0", String.valueOf(r3));
    }

    // --- PRUEBA 8: esAnoBisiesto ---
    private static void probarEsAnoBisiesto() {
        System.out.println("\n" + BOLD + "--- Ejercicio 8: esAnoBisiesto ---" + RESET);
        boolean r1 = Ejercicios.esAnoBisiesto(2024);
        probar("Año 2024 (Bisiesto)", r1 == true, "true", String.valueOf(r1));

        boolean r2 = Ejercicios.esAnoBisiesto(1900);
        probar("Año 1900 (No bisiesto)", r2 == false, "false", String.valueOf(r2));

        boolean r3 = Ejercicios.esAnoBisiesto(2000);
        probar("Año 2000 (Bisiesto)", r3 == true, "true", String.valueOf(r3));

        boolean r4 = Ejercicios.esAnoBisiesto(2023);
        probar("Año 2023 (No bisiesto)", r4 == false, "false", String.valueOf(r4));
    }

    // --- PRUEBA 9: obtenerNombreDia ---
    private static void probarObtenerNombreDia() {
        System.out.println("\n" + BOLD + "--- Ejercicio 9: obtenerNombreDia ---" + RESET);
        String r1 = Ejercicios.obtenerNombreDia(1);
        probar("Día 1", "Lunes".equalsIgnoreCase(r1), "Lunes", r1);

        String r2 = Ejercicios.obtenerNombreDia(5);
        probar("Día 5", "Viernes".equalsIgnoreCase(r2), "Viernes", r2);

        String r3 = Ejercicios.obtenerNombreDia(9);
        probar("Día fuera de rango (9)", "Día no válido".equalsIgnoreCase(r3), "Día no válido", r3);
    }

    // --- PRUEBA 10: esFinDeSemana ---
    private static void probarEsFinDeSemana() {
        System.out.println("\n" + BOLD + "--- Ejercicio 10: esFinDeSemana ---" + RESET);
        String r1 = Ejercicios.esFinDeSemana(3);
        probar("Día 3 (Miércoles)", "Laborable".equalsIgnoreCase(r1), "Laborable", r1);

        String r2 = Ejercicios.esFinDeSemana(6);
        probar("Día 6 (Sábado)", "Fin de semana".equalsIgnoreCase(r2), "Fin de semana", r2);

        String r3 = Ejercicios.esFinDeSemana(0);
        probar("Día no válido (0)", "Día no válido".equalsIgnoreCase(r3), "Día no válido", r3);
    }

    // --- PRUEBA 11: realizarOperacion ---
    private static void probarRealizarOperacion() {
        System.out.println("\n" + BOLD + "--- Ejercicio 11: realizarOperacion ---" + RESET);
        int r1 = Ejercicios.realizarOperacion(10, 5, '+');
        probar("Suma (10 + 5)", r1 == 15, "15", String.valueOf(r1));

        int r2 = Ejercicios.realizarOperacion(10, 5, '-');
        probar("Resta (10 - 5)", r2 == 5, "5", String.valueOf(r2));

        int r3 = Ejercicios.realizarOperacion(10, 5, '*');
        probar("Multiplicación (10 * 5)", r3 == 50, "50", String.valueOf(r3));

        int r4 = Ejercicios.realizarOperacion(10, 2, '/');
        probar("División (10 / 2)", r4 == 5, "5", String.valueOf(r4));

        int r5 = Ejercicios.realizarOperacion(10, 0, '/');
        probar("División por cero (10 / 0)", r5 == 0, "0", String.valueOf(r5));
    }

    // --- PRUEBA 12: obtenerEstacion ---
    private static void probarObtenerEstacion() {
        System.out.println("\n" + BOLD + "--- Ejercicio 12: obtenerEstacion ---" + RESET);
        String r1 = Ejercicios.obtenerEstacion(1);
        probar("Mes 1 (Enero)", "Invierno".equalsIgnoreCase(r1), "Invierno", r1);

        String r2 = Ejercicios.obtenerEstacion(4);
        probar("Mes 4 (Abril)", "Primavera".equalsIgnoreCase(r2), "Primavera", r2);

        String r3 = Ejercicios.obtenerEstacion(7);
        probar("Mes 7 (Julio)", "Verano".equalsIgnoreCase(r3), "Verano", r3);

        String r4 = Ejercicios.obtenerEstacion(10);
        probar("Mes 10 (Octubre)", "Otoño".equalsIgnoreCase(r4), "Otoño", r4);

        String r5 = Ejercicios.obtenerEstacion(13);
        probar("Mes no válido (13)", "Mes no válido".equalsIgnoreCase(r5), "Mes no válido", r5);
    }

    // --- PRUEBA 13: diasDelMes ---
    private static void probarDiasDelMes() {
        System.out.println("\n" + BOLD + "--- Ejercicio 13: diasDelMes ---" + RESET);
        int r1 = Ejercicios.diasDelMes(1);
        probar("Mes 1 (31 días)", r1 == 31, "31", String.valueOf(r1));

        int r2 = Ejercicios.diasDelMes(2);
        probar("Mes 2 (28 días)", r2 == 28, "28", String.valueOf(r2));

        int r3 = Ejercicios.diasDelMes(4);
        probar("Mes 4 (30 días)", r3 == 30, "30", String.valueOf(r3));

        int r4 = Ejercicios.diasDelMes(15);
        probar("Mes no válido (15)", r4 == -1, "-1", String.valueOf(r4));
    }
}
