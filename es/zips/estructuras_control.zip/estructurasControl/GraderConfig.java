package estructurasControl;

public class GraderConfig {

    // true  -> Ejecuta todas las pruebas
    // false -> Ejecuta solo el ejercicio indicado en EXERCISE_NUMBER
    public static final boolean RUN_ALL = false;

    // Número del ejercicio a probar cuando RUN_ALL = false (del 1 al 13)
    // 1: esParString              8: esAnoBisiesto
    // 2: esParBoolean             9: obtenerNombreDia
    // 3: determinarSigno         10: esFinDeSemana
    // 4: clasificarNota          11: realizarOperacion
    // 5: determinarMayor         12: obtenerEstacion
    // 6: clasificarCategoriaEdad 13: diasDelMes
    // 7: calcularDescuento
    public static final int EXERCISE_NUMBER = 1;
}
