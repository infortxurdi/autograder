package arrayList;

public class ConfigGrader {

    // true  -> Ejecuta todas las pruebas (1 a 20)
    // false -> Ejecuta solo el ejercicio indicado en EXERCISE_NUMBER
    public static final boolean RUN_ALL = true;

    // Número del ejercicio a probar cuando RUN_ALL = false (del 1 al 20)
    // BLOQUE A (String):
    //  1: gehituErrepikatuGabe             5: zenbatuHasieraLetra
    //  2: ezabatuLuzeraTxikikoak           6: ordezkatuHitza
    //  3: bilatuHitzLuzeena                7: bateratuErrepikatuGabe
    //  4: bihurtuMaiuskulara
    //
    // BLOQUE B (Integer y Double):
    //  8: batuBikoitiak                   12: bigarrenHandiena
    //  9: ezabatuBalioGuztiak             13: aplikatuDeskontua
    // 10: batezBestekoaGainditzenDutenak  14: iragaziTartea
    // 11: txertatuOrdenatuta
    //
    // BLOQUE C (Clases propias: Ikaslea y Produktua):
    // 15: lortuGaindituenIzenak           18: inbentarioarenBalioTotala
    // 16: ikasleOnena                     19: erosiProduktua
    // 17: igoNotaGuztiei                  20: stockGutxikoProduktuak
    public static final int EXERCISE_NUMBER = 1;
}