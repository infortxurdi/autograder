package arrayList;

import java.util.ArrayList;

public class Ariketak {

    // =============================================================
    // A BLOKEA: STRING ZERRENDAK (ArrayList<String>)
    // =============================================================

    /**
     * 1. ariketa: gehituErrepikatuGabe
     *
     * Elementu bat zerrendaren amaieran gehitzen du, baldin eta aurretik zerrendan ez badago.
     *
     * @param zerrenda  testuen ArrayLista.
     * @param elementua gehitu nahi den testua.
     * @return true elementua gehitu bada; false lehendik bazegoen edo parametroren bat null bada.
     *
     * Adibideak:
     * - gehituErrepikatuGabe(["Ana", "Jon"], "Ane") -> true (zerrenda: ["Ana", "Jon", "Ane"])
     * - gehituErrepikatuGabe(["Ana", "Jon"], "Jon") -> false (zerrenda: ["Ana", "Jon"])
     * - gehituErrepikatuGabe(null, "Ane") -> false
     */
    public static boolean gehituErrepikatuGabe(ArrayList<String> zerrenda, String elementua) {
        // TODO: Egiaztatu elementua dagoen eta ez badago gehitu
        return false;
    }

    /**
     * 2. ariketa: ezabatuLuzeraTxikikoak
     *
     * Gutxieneko luzera baino karaktere gutxiago (< gutxienekoLuzera) dituzten hitz guztiak
     * zerrendatik ezabatzen ditu.
     *
     * @param hitzak          aztertu eta aldatu beharreko String ArrayLista.
     * @param gutxienekoLuzera hitzak mantentzeko behar duen gutxieneko luzera.
     * @return Ezabatutako hitzen kopurua. 0 zerrenda nulua bada.
     *
     * Adibideak:
     * - ezabatuLuzeraTxikikoak(["Kaixo", "Ni", "Zu", "Euskara", "Ba"], 3) -> 3 (zerrenda: ["Kaixo", "Euskara"])
     * - ezabatuLuzeraTxikikoak(["Java", "Python"], 3) -> 0
     * - ezabatuLuzeraTxikikoak(null, 3) -> 0
     */
    public static int ezabatuLuzeraTxikikoak(ArrayList<String> hitzak, int gutxienekoLuzera) {
        // TODO: Kontuz indizeekin elementuak ezabatzean!
        return 0;
    }

    /**
     * 3. ariketa: bilatuHitzLuzeena
     *
     * Zerrendako hitzik luzeena aurkitzen du. Berdinketa badago, lehenengo agertzen dena bueltatzen du.
     *
     * @param hitzak String ArrayLista.
     * @return Hitzik luzeena. null zerrenda nulua edo hutsik badago.
     *
     * Adibideak:
     * - bilatuHitzLuzeena(["katua", "txakurra", "arraina"]) -> "txakurra"
     * - bilatuHitzLuzeena(["bat", "hiru", "bost"]) -> "hiru"
     * - bilatuHitzLuzeena([]) -> null
     * - bilatuHitzLuzeena(null) -> null
     */
    public static String bilatuHitzLuzeena(ArrayList<String> hitzak) {
        // TODO: Bilatu luzera handiena duen katea
        return null;
    }

    /**
     * 4. ariketa: bihurtuMaiuskulara
     *
     * Jatorrizko zerrendako hitz guztiak maiuskulara bihurtuta dituen ArrayList BERRI bat bueltatzen du.
     * Jatorrizko zerrenda ez da aldatu behar.
     *
     * @param hitzak jatorrizko String ArrayLista.
     * @return Maiuskulaz dauden hitzen ArrayList berria. Zerrenda hutsa jatorrizkoa nulua bada.
     *
     * Adibideak:
     * - bihurtuMaiuskulara(["kaixo", "Mundu"]) -> ["KAIXO", "MUNDU"]
     * - bihurtuMaiuskulara(null) -> []
     */
    public static ArrayList<String> bihurtuMaiuskulara(ArrayList<String> hitzak) {
        // TODO: Sortu ArrayList berri bat eta gehitu elementuak toUpperCase() erabiliz
        return new ArrayList<>();
    }

    /**
     * 5. ariketa: zenbatuHasieraLetra
     *
     * Adierazitako letraz hasten diren zenbat hitz dauden zenbatzen du (maiuskulak eta minuskulak bereizi gabe).
     *
     * @param hitzak String ArrayLista.
     * @param letra  bilatu nahi den hasierako karakterea.
     * @return Letra horrekin hasten diren hitzen kopurua. 0 zerrenda nulua edo hutsik badago.
     *
     * Adibideak:
     * - zenbatuHasieraLetra(["Amaia", "ander", "Jon", "Aitor"], 'a') -> 3
     * - zenbatuHasieraLetra(["Jon", "Mikel"], 'a') -> 0
     * - zenbatuHasieraLetra(null, 'a') -> 0
     */
    public static int zenbatuHasieraLetra(ArrayList<String> hitzak, char letra) {
        // TODO: Konparatu lehenengo karakterea minuskulatara pasatuta
        return 0;
    }

    /**
     * 6. ariketa: ordezkatuHitza
     *
     * Zerrendan agertzen diren 'zaharra' hitz guztiak 'berria' hitzarekin ordezkatzen ditu zerrendan bertan.
     *
     * @param hitzak  aldatu nahi den String ArrayLista.
     * @param zaharra ordezkatu nahi den hitza.
     * @param berria  jarri nahi den hitz berria.
     * @return Egindako ordezkapen kopurua. 0 parametroren bat nulua bada.
     *
     * Adibideak:
     * - ordezkatuHitza(["gorria", "urdina", "gorria"], "gorria", "horia") -> 2 (zerrenda: ["horia", "urdina", "horia"])
     * - ordezkatuHitza(["urdina"], "gorria", "horia") -> 0
     * - ordezkatuHitza(null, "a", "b") -> 0
     */
    public static int ordezkatuHitza(ArrayList<String> hitzak, String zaharra, String berria) {
        // TODO: Erabili set(i, berria) metodoa
        return 0;
    }

    /**
     * 7. ariketa: bateratuErrepikatuGabe
     *
     * Bi zerrendetako elementu guztiak elkartzen ditu ArrayList BERRI batean, errepikapenik gabe
     * eta agerpen-ordena mantenduz.
     *
     * @param z1 lehenengo String ArrayLista.
     * @param z2 bigarren String ArrayLista.
     * @return Bi zerrenden batasuna duen ArrayList berria (errepikaturik gabe).
     *
     * Adibideak:
     * - bateratuErrepikatuGabe(["A", "B", "A"], ["B", "C", "D"]) -> ["A", "B", "C", "D"]
     * - bateratuErrepikatuGabe(null, ["X", "X"]) -> ["X"]
     * - bateratuErrepikatuGabe(null, null) -> []
     */
    public static ArrayList<String> bateratuErrepikatuGabe(ArrayList<String> z1, ArrayList<String> z2) {
        // TODO: Gehitu bi zerrendetako elementuak errepikatu gabe
        return new ArrayList<>();
    }

    // =============================================================
    // B BLOKEA: ZENBAKI ZERRENDAK (Integer eta Double)
    // =============================================================

    /**
     * 8. ariketa: batuBikoitiak
     *
     * Zerrendako zenbaki bikoiti guztien batura kalkulatzen du.
     *
     * @param zenbakiak Integer ArrayLista.
     * @return Zenbaki bikoitien batura. 0 zerrenda nulua edo hutsik badago.
     *
     * Adibideak:
     * - batuBikoitiak([1, 2, 3, 4, 6]) -> 12
     * - batuBikoitiak([1, 3, 5]) -> 0
     * - batuBikoitiak(null) -> 0
     */
    public static int batuBikoitiak(ArrayList<Integer> zenbakiak) {
        // TODO: Batu % 2 == 0 betetzen duten zenbakiak
        return 0;
    }

    /**
     * 9. ariketa: ezabatuBalioGuztiak
     *
     * Zerrendatik adierazitako zenbakiaren agerpen guztiak ezabatzen ditu.
     *
     * @param zenbakiak Integer ArrayLista.
     * @param balioa    ezabatu nahi den zenbaki osoa.
     * @return true gutxienez elementu bat ezabatu bada; false bestela edo zerrenda nulua bada.
     *
     * Adibideak:
     * - ezabatuBalioGuztiak([2, 5, 2, 8, 2], 2) -> true (zerrenda: [5, 8])
     * - ezabatuBalioGuztiak([1, 3, 5], 2) -> false
     * - ezabatuBalioGuztiak(null, 2) -> false
     */
    public static boolean ezabatuBalioGuztiak(ArrayList<Integer> zenbakiak, int balioa) {
        // TODO: Kontuz remove(int) eta remove(Object) bereiztean!
        return false;
    }

    /**
     * 10. ariketa: batezBestekoaGainditzenDutenak
     *
     * Zerrendako noten batez besteko aritmetikoa kalkulatzen du, eta batez besteko hori baino
     * hertsiki handiagoak (> batezBestekoa) diren notekin ArrayList BERRI bat bueltatzen du.
     *
     * @param notak Double motako noten ArrayLista.
     * @return Batez bestekoa gainditzen duten noten ArrayList berria. Zerrenda hutsa nulua edo hutsik badago.
     *
     * Adibideak:
     * - batezBestekoaGainditzenDutenak([4.0, 6.0, 8.0]) -> [8.0]  (batez bestekoa: 6.0)
     * - batezBestekoaGainditzenDutenak([5.0, 5.0]) -> []
     * - batezBestekoaGainditzenDutenak(null) -> []
     */
    public static ArrayList<Double> batezBestekoaGainditzenDutenak(ArrayList<Double> notak) {
        // TODO: Kalkulatu lehenik batez bestekoa eta gero iragazi
        return new ArrayList<>();
    }

    /**
     * 11. ariketa: txertatuOrdenatuta
     *
     * Goranzko ordenan ordenatuta dagoen zerrenda batean zenbaki berri bat txertatzen du
     * dagokion posizioan, zerrendak ordenatuta jarrai dezan.
     *
     * @param zerrendaOrdenatua goranzko ordenan dagoen Integer ArrayLista.
     * @param berria            txertatu nahi den zenbakia.
     *
     * Adibideak:
     * - txertatuOrdenatuta([10, 20, 40, 50], 30) -> zerrenda: [10, 20, 30, 40, 50]
     * - txertatuOrdenatuta([10, 20], 5) -> zerrenda: [5, 10, 20]
     * - txertatuOrdenatuta([], 7) -> zerrenda: [7]
     */
    public static void txertatuOrdenatuta(ArrayList<Integer> zerrendaOrdenatua, int berria) {
        // TODO: Bilatu posizio egokia eta erabili add(indizea, berria)
    }

    /**
     * 12. ariketa: bigarrenHandiena
     *
     * Zerrendako bigarren balio handiena (desberdina) aurkitzen du.
     *
     * @param zenbakiak Integer ArrayLista.
     * @return Bigarren zenbaki handiena. Integer.MIN_VALUE nulua bada edo 2 balio desberdin baino gutxiago baditu.
     *
     * Adibideak:
     * - bigarrenHandiena([10, 5, 20, 8]) -> 10
     * - bigarrenHandiena([20, 20, 15, 10]) -> 15
     * - bigarrenHandiena([5, 5, 5]) -> Integer.MIN_VALUE
     * - bigarrenHandiena(null) -> Integer.MIN_VALUE
     */
    public static int bigarrenHandiena(ArrayList<Integer> zenbakiak) {
        // TODO: Aurkitu balio handiena eta bigarren handiena
        return Integer.MIN_VALUE;
    }

    /**
     * 13. ariketa: aplikatuDeskontua
     *
     * Zerrendako prezio guztiei ehuneko deskontu bat aplikatzen die zerrendan bertan.
     * Ehunekoa 0 baino txikiagoa edo 100 baino handiagoa bada, ez du aldaketarik egiten.
     *
     * @param prezioak  Double motako prezioen ArrayLista.
     * @param ehunekoa deskontuaren ehunekoa (0.0 eta 100.0 artekoa).
     *
     * Adibideak:
     * - aplikatuDeskontua([100.0, 50.0], 20.0) -> zerrenda: [80.0, 40.0]
     * - aplikatuDeskontua([100.0], -5.0) -> zerrenda: [100.0]
     */
    public static void aplikatuDeskontua(ArrayList<Double> prezioak, double ehunekoa) {
        // TODO: Eguneratu prezio bakoitza set() metodoarekin
    }

    /**
     * 14. ariketa: iragaziTartea
     *
     * [min, max] tartean dauden zenbakiekin (biak barne) ArrayList BERRI bat bueltatzen du.
     *
     * @param zenbakiak jatorrizko Integer ArrayLista.
     * @param min       gutxieneko balioa (barne).
     * @param max       gehienezko balioa (barne).
     * @return Tartean dauden zenbakien ArrayList berria. Zerrenda hutsa nulua bada.
     *
     * Adibideak:
     * - iragaziTartea([5, 10, 15, 20, 25], 10, 20) -> [10, 15, 20]
     * - iragaziTartea(null, 10, 20) -> []
     */
    public static ArrayList<Integer> iragaziTartea(ArrayList<Integer> zenbakiak, int min, int max) {
        // TODO: Iragazi min <= x && x <= max betetzen dutenak
        return new ArrayList<>();
    }

    // =============================================================
    // C BLOKEA: KLASE PROPIOEN ZERRENDAK (Ikaslea eta Produktua)
    // =============================================================

    /**
     * 15. ariketa: lortuGaindituenIzenak
     *
     * Irakasgaia gainditu duten ikasleen (nota >= 5.0) izenekin ArrayList<String> BERRI bat bueltatzen du.
     *
     * @param ikasleak Ikaslea objektuen ArrayLista.
     * @return Gainditutako ikasleen izenen ArrayLista. Zerrenda hutsa nulua bada.
     *
     * Adibideak:
     * - lortuGaindituenIzenak([Ikaslea("Ane",19,8.5), Ikaslea("Mikel",20,4.2), Ikaslea("Sara",19,5.0)]) -> ["Ane", "Sara"]
     * - lortuGaindituenIzenak(null) -> []
     */
    public static ArrayList<String> lortuGaindituenIzenak(ArrayList<Ikaslea> ikasleak) {
        // TODO: Erabili ikaslea.gainditutaDago() eta ikaslea.getIzena()
        return new ArrayList<>();
    }

    /**
     * 16. ariketa: ikasleOnena
     *
     * Notarik altuena duen Ikaslea bueltatzen du. Berdinketa badago, lehenengo agertzen dena.
     *
     * @param ikasleak Ikaslea objektuen ArrayLista.
     * @return Notarik altuena duen Ikaslea objektua. null zerrenda nulua edo hutsik badago.
     *
     * Adibideak:
     * - ikasleOnena([Ikaslea("Ane",19,7.5), Ikaslea("Mikel",20,9.2), Ikaslea("Sara",19,9.2)]) -> Mikel
     * - ikasleOnena([]) -> null
     * - ikasleOnena(null) -> null
     */
    public static Ikaslea ikasleOnena(ArrayList<Ikaslea> ikasleak) {
        // TODO: Bilatu nota altuena duen Ikaslea objektua
        return null;
    }

    /**
     * 17. ariketa: igoNotaGuztiei
     *
     * Zerrendako ikasle guztiei adierazitako puntuak gehitzen dizkie notan, baina 10.0 muga gainditu gabe.
     * Puntuak <= 0 badira edo zerrenda nulua bada, ez du ezer egiten.
     *
     * @param ikasleak Ikaslea objektuen ArrayLista.
     * @param puntuak  gehitu nahi den puntu kopurua (> 0).
     *
     * Adibideak:
     * - igoNotaGuztiei([Ikaslea("Ane",19,8.0), Ikaslea("Mikel",20,9.5)], 1.0) -> Ane: 9.0, Mikel: 10.0
     */
    public static void igoNotaGuztiei(ArrayList<Ikaslea> ikasleak, double puntuak) {
        // TODO: Eguneratu nota bakoitza setNota() erabiliz (gehienez 10.0)
    }

    /**
     * 18. ariketa: inbentarioarenBalioTotala
     *
     * Biltegiko produktu guztien balio ekonomiko totala kalkulatzen du (produktu bakoitzaren prezioa * stock batura).
     *
     * @param produktuak Produktua objektuen ArrayLista.
     * @return Inbentario osoaren balioa. 0.0 zerrenda nulua edo hutsik badago.
     *
     * Adibideak:
     * - inbentarioarenBalioTotala([Produktua("Teklatua",25.0,4), Produktua("Sagua",15.0,2)]) -> 130.0
     * - inbentarioarenBalioTotala(null) -> 0.0
     */
    public static double inbentarioarenBalioTotala(ArrayList<Produktua> produktuak) {
        // TODO: Batu produktu bakoitzaren guztizkoBalioa()
        return 0.0;
    }

    /**
     * 19. ariketa: erosiProduktua
     *
     * Izenaren arabera produktua bilatzen du (maiuskulak/minuskulak bereizi gabe). Produktua existitzen bada
     * eta stock nahikoa badu (stock >= kantitatea eta kantitatea > 0), stocka murrizten du eta true bueltatzen du.
     *
     * @param produktuak Produktua objektuen ArrayLista.
     * @param izena      erosi nahi den produktuaren izena.
     * @param kantitatea erosi nahi den unitate kopurua.
     * @return true erosketa burutu bada; false produktua ez badago, stock nahikorik ez badago edo datuak okerrak badira.
     *
     * Adibideak:
     * - erosiProduktua([Produktua("Teklatua",25.0,5)], "teklatua", 3) -> true (stock berria: 2)
     * - erosiProduktua([Produktua("Teklatua",25.0,2)], "teklatua", 4) -> false (stocka 2 izaten jarraitzen du)
     */
    public static boolean erosiProduktua(ArrayList<Produktua> produktuak, String izena, int kantitatea) {
        // TODO: Bilatu produktua, egiaztatu stocka eta eguneratu setStock() bidez
        return false;
    }

    /**
     * 20. ariketa: stockGutxikoProduktuak
     *
     * Adierazitako muga baino stock gutxiago (< muga) duten produktuekin ArrayList<Produktua> BERRI bat bueltatzen du.
     *
     * @param produktuak Produktua objektuen ArrayLista.
     * @param muga       gutxieneko stock atalasea.
     * @return Stock gutxiko produktuen ArrayList berria. Zerrenda hutsa zerrenda nulua bada.
     *
     * Adibideak:
     * - stockGutxikoProduktuak([Produktua("A",10,2), Produktua("B",10,5), Produktua("C",10,1)], 5) -> [A, C]
     * - stockGutxikoProduktuak(null, 5) -> []
     */
    public static ArrayList<Produktua> stockGutxikoProduktuak(ArrayList<Produktua> produktuak, int muga) {
        // TODO: Iragazi getStock() < muga duten produktuak
        return new ArrayList<>();
    }
}