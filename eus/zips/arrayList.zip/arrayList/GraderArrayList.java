package arrayList;

import java.util.ArrayList;
import java.util.Arrays;

public class GraderArrayList {

    // ANSI kolore-kodeak kontsolan bistaratzeko
    private static final String RESET = "\u001B[0m";
    private static final String RED = "\u001B[31m";
    private static final String GREEN = "\u001B[32m";
    private static final String YELLOW = "\u001B[33m";
    private static final String CYAN = "\u001B[36m";
    private static final String BOLD = "\u001B[1m";

    private static int totalTests = 0;
    private static int passedTests = 0;

    public static void main(String[] args) {
        System.out.println(CYAN + "==================================================");
        System.out.println("  ARRAYLIST ARIKETEN EBALUATZAILE AUTOMATIKOA     ");
        System.out.println("==================================================" + RESET + "\n");

        // A BLOKEA: STRING ZERRENDAK
        if (shouldRun(1)) testGehituErrepikatuGabe();
        if (shouldRun(2)) testEzabatuLuzeraTxikikoak();
        if (shouldRun(3)) testBilatuHitzLuzeena();
        if (shouldRun(4)) testBihurtuMaiuskulara();
        if (shouldRun(5)) testZenbatuHasieraLetra();
        if (shouldRun(6)) testOrdezkatuHitza();
        if (shouldRun(7)) testBateratuErrepikatuGabe();

        // B BLOKEA: ZENBAKI ZERRENDAK (Integer eta Double)
        if (shouldRun(8)) testBatuBikoitiak();
        if (shouldRun(9)) testEzabatuBalioGuztiak();
        if (shouldRun(10)) testBatezBestekoaGainditzenDutenak();
        if (shouldRun(11)) testTxertatuOrdenatuta();
        if (shouldRun(12)) testBigarrenHandiena();
        if (shouldRun(13)) testAplikatuDeskontua();
        if (shouldRun(14)) testIragaziTartea();

        // C BLOKEA: KLASE PROPIOEN ZERRENDAK (Ikaslea eta Produktua)
        if (shouldRun(15)) testLortuGaindituenIzenak();
        if (shouldRun(16)) testIkasleOnena();
        if (shouldRun(17)) testIgoNotaGuztiei();
        if (shouldRun(18)) testInbentarioarenBalioTotala();
        if (shouldRun(19)) testErosiProduktua();
        if (shouldRun(20)) testStockGutxikoProduktuak();

        // Azken laburpena
        double porcentaje = totalTests > 0 ? ((double) passedTests / totalTests) * 100 : 0.0;

        System.out.println("\n" + CYAN + "==================================================" + RESET);
        System.out.printf(BOLD + " AZKEN EMAITZA: %d / %d proba gaindituta (%%%.1f)\n" + RESET,
                passedTests, totalTests, porcentaje);
        System.out.println(CYAN + "==================================================" + RESET);

        if (totalTests > 0 && passedTests == totalTests) {
            System.out.println(GREEN + "🎉 Lan bikaina! ArrayList metodo guztiek egoki funtzionatzen dute." + RESET);
        } else if (totalTests > 0) {
            System.out.println(YELLOW + "⚠️ Berrikusi [ERROREA] gisa markatutako ariketak eta saiatu berriro." + RESET);
        } else {
            System.out.println(YELLOW + "⚠️ Ez da probarik exekutatu. Konfigurazioa berrikusi." + RESET);
        }
    }

    private static boolean shouldRun(int exerciseNumber) {
        return ConfigGrader.RUN_ALL || ConfigGrader.EXERCISE_NUMBER == exerciseNumber;
    }

    private static void test(String probarenIzena, boolean resultado, String esperado, String obtenido) {
        totalTests++;
        if (resultado) {
            passedTests++;
            System.out.printf("  " + GREEN + "[OK]" + RESET + " %s\n", probarenIzena);
        } else {
            System.out.printf("  " + RED + "[ERROREA]" + RESET + " %s | Esperotakoa: '%s' -> Lortutakoa: '%s'\n",
                    probarenIzena, esperado, obtenido);
        }
    }

    @SafeVarargs
    private static <T> ArrayList<T> lista(T... elementuak) {
        return new ArrayList<>(Arrays.asList(elementuak));
    }

    // =============================================================
    // A BLOKEA TESTAK (String)
    // =============================================================

    private static void testGehituErrepikatuGabe() {
        System.out.println(BOLD + "--- 1. ariketa: gehituErrepikatuGabe ---" + RESET);
        ArrayList<String> l1 = lista("Ana", "Jon");
        boolean r1 = Ariketak.gehituErrepikatuGabe(l1, "Ane");
        test("Gehitu elementu berria ('Ane')", r1 && l1.equals(lista("Ana", "Jon", "Ane")),
                "true -> [Ana, Jon, Ane]", r1 + " -> " + l1);

        ArrayList<String> l2 = lista("Ana", "Jon");
        boolean r2 = Ariketak.gehituErrepikatuGabe(l2, "Jon");
        test("Ez gehitu errepikatua ('Jon')", !r2 && l2.equals(lista("Ana", "Jon")),
                "false -> [Ana, Jon]", r2 + " -> " + l2);

        boolean r3 = Ariketak.gehituErrepikatuGabe(null, "Ane");
        test("Zerrenda null denean", !r3, "false", String.valueOf(r3));
    }

    private static void testEzabatuLuzeraTxikikoak() {
        System.out.println("\n" + BOLD + "--- 2. ariketa: ezabatuLuzeraTxikikoak ---" + RESET);
        ArrayList<String> l1 = lista("Kaixo", "Ni", "Zu", "Euskara", "Ba");
        int r1 = Ariketak.ezabatuLuzeraTxikikoak(l1, 3);
        test("Ezabatu luzera < 3 jarraian dauden elementuekin", r1 == 3 && l1.equals(lista("Kaixo", "Euskara")),
                "3 -> [Kaixo, Euskara]", r1 + " -> " + l1);

        ArrayList<String> l2 = lista("Java", "Python");
        int r2 = Ariketak.ezabatuLuzeraTxikikoak(l2, 3);
        test("Bat ere ez ezabatu", r2 == 0 && l2.equals(lista("Java", "Python")),
                "0 -> [Java, Python]", r2 + " -> " + l2);

        int r3 = Ariketak.ezabatuLuzeraTxikikoak(null, 3);
        test("Null denean", r3 == 0, "0", String.valueOf(r3));
    }

    private static void testBilatuHitzLuzeena() {
        System.out.println("\n" + BOLD + "--- 3. ariketa: bilatuHitzLuzeena ---" + RESET);
        String r1 = Ariketak.bilatuHitzLuzeena(lista("katua", "txakurra", "arraina"));
        test("Hitz luzeena ['katua', 'txakurra', 'arraina']", "txakurra".equals(r1), "txakurra", String.valueOf(r1));

        String r2 = Ariketak.bilatuHitzLuzeena(lista("bat", "hiru", "bost"));
        test("Berdinketa kasuan lehenengoa ['bat', 'hiru', 'bost']", "hiru".equals(r2), "hiru", String.valueOf(r2));

        String r3 = Ariketak.bilatuHitzLuzeena(new ArrayList<>());
        test("Zerrenda hutsik", r3 == null, "null", String.valueOf(r3));

        String r4 = Ariketak.bilatuHitzLuzeena(null);
        test("Null denean", r4 == null, "null", String.valueOf(r4));
    }

    private static void testBihurtuMaiuskulara() {
        System.out.println("\n" + BOLD + "--- 4. ariketa: bihurtuMaiuskulara ---" + RESET);
        ArrayList<String> jatorrizkoa = lista("kaixo", "Mundu");
        ArrayList<String> r1 = Ariketak.bihurtuMaiuskulara(jatorrizkoa);
        test("Maiuskulara bihurtu eta jatorrizkoa mantendu",
                r1 != null && r1.equals(lista("KAIXO", "MUNDU")) && jatorrizkoa.equals(lista("kaixo", "Mundu")),
                "[KAIXO, MUNDU]", String.valueOf(r1));

        ArrayList<String> r2 = Ariketak.bihurtuMaiuskulara(null);
        test("Null denean", r2 != null && r2.isEmpty(), "[]", String.valueOf(r2));
    }

    private static void testZenbatuHasieraLetra() {
        System.out.println("\n" + BOLD + "--- 5. ariketa: zenbatuHasieraLetra ---" + RESET);
        int r1 = Ariketak.zenbatuHasieraLetra(lista("Amaia", "ander", "Jon", "Aitor"), 'a');
        test("Hasiera letra 'a' (maiuskula/minuskula)", r1 == 3, "3", String.valueOf(r1));

        int r2 = Ariketak.zenbatuHasieraLetra(lista("Jon", "Mikel"), 'a');
        test("Bat ere ez dator bat", r2 == 0, "0", String.valueOf(r2));

        int r3 = Ariketak.zenbatuHasieraLetra(null, 'a');
        test("Null denean", r3 == 0, "0", String.valueOf(r3));
    }

    private static void testOrdezkatuHitza() {
        System.out.println("\n" + BOLD + "--- 6. ariketa: ordezkatuHitza ---" + RESET);
        ArrayList<String> l1 = lista("gorria", "urdina", "gorria");
        int r1 = Ariketak.ordezkatuHitza(l1, "gorria", "horia");
        test("Ordezkatu 'gorria' -> 'horia'", r1 == 2 && l1.equals(lista("horia", "urdina", "horia")),
                "2 -> [horia, urdina, horia]", r1 + " -> " + l1);

        int r2 = Ariketak.ordezkatuHitza(null, "a", "b");
        test("Null denean", r2 == 0, "0", String.valueOf(r2));
    }

    private static void testBateratuErrepikatuGabe() {
        System.out.println("\n" + BOLD + "--- 7. ariketa: bateratuErrepikatuGabe ---" + RESET);
        ArrayList<String> r1 = Ariketak.bateratuErrepikatuGabe(lista("A", "B", "A"), lista("B", "C", "D"));
        test("Bateratu ['A','B','A'] eta ['B','C','D']",
                r1 != null && r1.equals(lista("A", "B", "C", "D")), "[A, B, C, D]", String.valueOf(r1));

        ArrayList<String> r2 = Ariketak.bateratuErrepikatuGabe(null, lista("X", "X"));
        test("Lehenengoa null denean", r2 != null && r2.equals(lista("X")), "[X]", String.valueOf(r2));

        ArrayList<String> r3 = Ariketak.bateratuErrepikatuGabe(null, null);
        test("Biak null direnean", r3 != null && r3.isEmpty(), "[]", String.valueOf(r3));
    }

    // =============================================================
    // B BLOKEA TESTAK (Integer eta Double)
    // =============================================================

    private static void testBatuBikoitiak() {
        System.out.println("\n" + BOLD + "--- 8. ariketa: batuBikoitiak ---" + RESET);
        int r1 = Ariketak.batuBikoitiak(lista(1, 2, 3, 4, 6));
        test("Batura [1, 2, 3, 4, 6]", r1 == 12, "12", String.valueOf(r1));

        int r2 = Ariketak.batuBikoitiak(lista(1, 3, 5));
        test("Bikoitirik ez [1, 3, 5]", r2 == 0, "0", String.valueOf(r2));

        int r3 = Ariketak.batuBikoitiak(null);
        test("Null denean", r3 == 0, "0", String.valueOf(r3));
    }

    private static void testEzabatuBalioGuztiak() {
        System.out.println("\n" + BOLD + "--- 9. ariketa: ezabatuBalioGuztiak ---" + RESET);
        ArrayList<Integer> l1 = lista(2, 5, 2, 8, 2);
        boolean r1 = Ariketak.ezabatuBalioGuztiak(l1, 2);
        test("Ezabatu 2 guztiak [2, 5, 2, 8, 2]", r1 && l1.equals(lista(5, 8)),
                "true -> [5, 8]", r1 + " -> " + l1);

        ArrayList<Integer> l2 = lista(1, 3, 5);
        boolean r2 = Ariketak.ezabatuBalioGuztiak(l2, 2);
        test("Balioa ez dagoenean", !r2 && l2.equals(lista(1, 3, 5)),
                "false -> [1, 3, 5]", r2 + " -> " + l2);

        boolean r3 = Ariketak.ezabatuBalioGuztiak(null, 2);
        test("Null denean", !r3, "false", String.valueOf(r3));
    }

    private static void testBatezBestekoaGainditzenDutenak() {
        System.out.println("\n" + BOLD + "--- 10. ariketa: batezBestekoaGainditzenDutenak ---" + RESET);
        ArrayList<Double> r1 = Ariketak.batezBestekoaGainditzenDutenak(lista(4.0, 6.0, 8.0));
        test("Batez bestekoa (6.0) gainditzen dutenak [4.0, 6.0, 8.0]",
                r1 != null && r1.equals(lista(8.0)), "[8.0]", String.valueOf(r1));

        ArrayList<Double> r2 = Ariketak.batezBestekoaGainditzenDutenak(lista(5.0, 5.0));
        test("Denak berdinak direnean [5.0, 5.0]", r2 != null && r2.isEmpty(), "[]", String.valueOf(r2));

        ArrayList<Double> r3 = Ariketak.batezBestekoaGainditzenDutenak(null);
        test("Null denean", r3 != null && r3.isEmpty(), "[]", String.valueOf(r3));
    }

    private static void testTxertatuOrdenatuta() {
        System.out.println("\n" + BOLD + "--- 11. ariketa: txertatuOrdenatuta ---" + RESET);
        ArrayList<Integer> l1 = lista(10, 20, 40, 50);
        Ariketak.txertatuOrdenatuta(l1, 30);
        test("Txertatu erdian (30)", l1.equals(lista(10, 20, 30, 40, 50)), "[10, 20, 30, 40, 50]", String.valueOf(l1));

        ArrayList<Integer> l2 = lista(10, 20);
        Ariketak.txertatuOrdenatuta(l2, 5);
        test("Txertatu hasieran (5)", l2.equals(lista(5, 10, 20)), "[5, 10, 20]", String.valueOf(l2));

        ArrayList<Integer> l3 = lista(10, 20);
        Ariketak.txertatuOrdenatuta(l3, 99);
        test("Txertatu amaieran (99)", l3.equals(lista(10, 20, 99)), "[10, 20, 99]", String.valueOf(l3));
    }

    private static void testBigarrenHandiena() {
        System.out.println("\n" + BOLD + "--- 12. ariketa: bigarrenHandiena ---" + RESET);
        int r1 = Ariketak.bigarrenHandiena(lista(10, 5, 20, 8));
        test("Bigarren handiena [10, 5, 20, 8]", r1 == 10, "10", String.valueOf(r1));

        int r2 = Ariketak.bigarrenHandiena(lista(20, 20, 15, 10));
        test("Handiena errepikatuta [20, 20, 15, 10]", r2 == 15, "15", String.valueOf(r2));

        int r3 = Ariketak.bigarrenHandiena(lista(5, 5, 5));
        test("Balio bakar desberdina [5, 5, 5]", r3 == Integer.MIN_VALUE,
                String.valueOf(Integer.MIN_VALUE), String.valueOf(r3));

        int r4 = Ariketak.bigarrenHandiena(null);
        test("Null denean", r4 == Integer.MIN_VALUE, String.valueOf(Integer.MIN_VALUE), String.valueOf(r4));
    }

    private static void testAplikatuDeskontua() {
        System.out.println("\n" + BOLD + "--- 13. ariketa: aplikatuDeskontua ---" + RESET);
        ArrayList<Double> l1 = lista(100.0, 50.0);
        Ariketak.aplikatuDeskontua(l1, 20.0);
        boolean ok1 = l1.size() == 2 && Math.abs(l1.get(0) - 80.0) < 0.001 && Math.abs(l1.get(1) - 40.0) < 0.001;
        test("%20ko deskontua [100.0, 50.0]", ok1, "[80.0, 40.0]", String.valueOf(l1));

        ArrayList<Double> l2 = lista(100.0);
        Ariketak.aplikatuDeskontua(l2, -5.0);
        test("Ehuneko baliogabea (-5.0)", Math.abs(l2.get(0) - 100.0) < 0.001, "[100.0]", String.valueOf(l2));
    }

    private static void testIragaziTartea() {
        System.out.println("\n" + BOLD + "--- 14. ariketa: iragaziTartea ---" + RESET);
        ArrayList<Integer> r1 = Ariketak.iragaziTartea(lista(5, 10, 15, 20, 25), 10, 20);
        test("Iragazi [10, 20] tartea", r1 != null && r1.equals(lista(10, 15, 20)),
                "[10, 15, 20]", String.valueOf(r1));

        ArrayList<Integer> r2 = Ariketak.iragaziTartea(null, 10, 20);
        test("Null denean", r2 != null && r2.isEmpty(), "[]", String.valueOf(r2));
    }

    // =============================================================
    // C BLOKEA TESTAK (Klase propioak: Ikaslea eta Produktua)
    // =============================================================

    private static void testLortuGaindituenIzenak() {
        System.out.println("\n" + BOLD + "--- 15. ariketa: lortuGaindituenIzenak (Ikaslea) ---" + RESET);
        ArrayList<Ikaslea> ikasleak = lista(
                new Ikaslea("Ane", 19, 8.5),
                new Ikaslea("Mikel", 20, 4.2),
                new Ikaslea("Sara", 19, 5.0)
        );
        ArrayList<String> r1 = Ariketak.lortuGaindituenIzenak(ikasleak);
        test("Gaindituen izenak (Ane 8.5, Mikel 4.2, Sara 5.0)",
                r1 != null && r1.equals(lista("Ane", "Sara")), "[Ane, Sara]", String.valueOf(r1));

        ArrayList<String> r2 = Ariketak.lortuGaindituenIzenak(null);
        test("Null denean", r2 != null && r2.isEmpty(), "[]", String.valueOf(r2));
    }

    private static void testIkasleOnena() {
        System.out.println("\n" + BOLD + "--- 16. ariketa: ikasleOnena (Ikaslea) ---" + RESET);
        Ikaslea i1 = new Ikaslea("Ane", 19, 7.5);
        Ikaslea i2 = new Ikaslea("Mikel", 20, 9.2);
        Ikaslea i3 = new Ikaslea("Sara", 19, 9.2);
        Ikaslea r1 = Ariketak.ikasleOnena(lista(i1, i2, i3));
        test("Ikasle onena (berdinketan lehenengoa: Mikel)", r1 == i2,
                "Mikel (9.2)", r1 != null ? r1.getIzena() + " (" + r1.getNota() + ")" : "null");

        Ikaslea r2 = Ariketak.ikasleOnena(null);
        test("Null denean", r2 == null, "null", String.valueOf(r2));
    }

    private static void testIgoNotaGuztiei() {
        System.out.println("\n" + BOLD + "--- 17. ariketa: igoNotaGuztiei (Ikaslea) ---" + RESET);
        Ikaslea i1 = new Ikaslea("Ane", 19, 8.0);
        Ikaslea i2 = new Ikaslea("Mikel", 20, 9.5);
        Ariketak.igoNotaGuztiei(lista(i1, i2), 1.0);
        boolean ok = Math.abs(i1.getNota() - 9.0) < 0.001 && Math.abs(i2.getNota() - 10.0) < 0.001;
        test("Igo +1.0 (10.0 mugarekin)", ok, "Ane: 9.0, Mikel: 10.0",
                "Ane: " + i1.getNota() + ", Mikel: " + i2.getNota());
    }

    private static void testInbentarioarenBalioTotala() {
        System.out.println("\n" + BOLD + "--- 18. ariketa: inbentarioarenBalioTotala (Produktua) ---" + RESET);
        ArrayList<Produktua> produktuak = lista(
                new Produktua("Teklatua", 25.0, 4),
                new Produktua("Sagua", 15.0, 2)
        );
        double r1 = Ariketak.inbentarioarenBalioTotala(produktuak);
        test("Balio totala (25*4 + 15*2)", Math.abs(r1 - 130.0) < 0.001, "130.0", String.valueOf(r1));

        double r2 = Ariketak.inbentarioarenBalioTotala(null);
        test("Null denean", Math.abs(r2 - 0.0) < 0.001, "0.0", String.valueOf(r2));
    }

    private static void testErosiProduktua() {
        System.out.println("\n" + BOLD + "--- 19. ariketa: erosiProduktua (Produktua) ---" + RESET);
        Produktua p1 = new Produktua("Teklatua", 25.0, 5);
        ArrayList<Produktua> denda = lista(p1);

        boolean r1 = Ariketak.erosiProduktua(denda, "teklatua", 3);
        test("Erosketa zuzena ('teklatua', 3 unitate)", r1 && p1.getStock() == 2,
                "true (stock: 2)", r1 + " (stock: " + p1.getStock() + ")");

        boolean r2 = Ariketak.erosiProduktua(denda, "teklatua", 4);
        test("Stock nahikorik ez (4 eskatu, 2 daude)", !r2 && p1.getStock() == 2,
                "false (stock: 2)", r2 + " (stock: " + p1.getStock() + ")");

        boolean r3 = Ariketak.erosiProduktua(denda, "Monitorea", 1);
        test("Existitzen ez den produktua", !r3, "false", String.valueOf(r3));
    }

    private static void testStockGutxikoProduktuak() {
        System.out.println("\n" + BOLD + "--- 20. ariketa: stockGutxikoProduktuak (Produktua) ---" + RESET);
        Produktua p1 = new Produktua("A", 10.0, 2);
        Produktua p2 = new Produktua("B", 10.0, 5);
        Produktua p3 = new Produktua("C", 10.0, 1);

        ArrayList<Produktua> r1 = Ariketak.stockGutxikoProduktuak(lista(p1, p2, p3), 5);
        test("Stock < 5 duten produktuak", r1 != null && r1.equals(lista(p1, p3)),
                "[A, C]", r1 != null ? r1.size() + " produktu" : "null");

        ArrayList<Produktua> r2 = Ariketak.stockGutxikoProduktuak(null, 5);
        test("Null denean", r2 != null && r2.isEmpty(), "[]", String.valueOf(r2));
    }
}