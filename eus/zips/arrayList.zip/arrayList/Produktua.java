package arrayList;

/**
 * Denda bateko produktu baten datuak gordetzen dituen klasea.
 * Produktuak izena, prezioa eta stock kopurua ditu.
 */
public class Produktua {

    // TODO: Definitu atributu pribatuak (izena, prezioa, stock)

    /**
     * Produktua objektu berri bat sortzen du.
     *
     * @param izena   produktuaren izena.
     * @param prezioa unitate bakoitzaren prezioa.
     * @param stock   biltegian dagoen unitate kopurua.
     */
    public Produktua(String izena, double prezioa, int stock) {
        // TODO: Hasieratu atributuak
    }

    /**
     * Produktuaren izena bueltatzen du.
     *
     * @return produktuaren izena.
     */
    public String getIzena() {
        // TODO: Bueltatu izena
        return null;
    }

    /**
     * Produktuaren prezioa bueltatzen du.
     *
     * @return produktuaren prezioa.
     */
    public double getPrezioa() {
        // TODO: Bueltatu prezioa
        return 0.0;
    }

    /**
     * Produktuaren prezioa eguneratzen du.
     *
     * @param prezioa prezio berria.
     */
    public void setPrezioa(double prezioa) {
        // TODO: Eguneratu prezioa
    }

    /**
     * Produktuaren uneko stocka bueltatzen du.
     *
     * @return stock kopurua.
     */
    public int getStock() {
        // TODO: Bueltatu stocka
        return 0;
    }

    /**
     * Produktuaren stocka eguneratzen du.
     *
     * @param stock stock kopuru berria.
     */
    public void setStock(int stock) {
        // TODO: Eguneratu stocka
    }

    /**
     * Produktu horren stock osoaren balio ekonomikoa kalkulatzen du (prezioa * stock).
     *
     * @return guztizko balioa.
     */
    public double guztizkoBalioa() {
        // TODO: Kalkulatu prezioa * stock
        return 0.0;
    }
}