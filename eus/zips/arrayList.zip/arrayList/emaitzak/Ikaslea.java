package arrayList.emaitzak;

public class Ikaslea {

    private String izena;
    private int adina;
    private double nota;

    public Ikaslea(String izena, int adina, double nota) {
        this.izena = izena;
        this.adina = adina;
        this.nota = nota;
    }

    public String getIzena() {
        return izena;
    }

    public int getAdina() {
        return adina;
    }

    public double getNota() {
        return nota;
    }

    public void setNota(double nota) {
        this.nota = nota;
    }

    public boolean gainditutaDago() {
        return nota >= 5.0;
    }
}