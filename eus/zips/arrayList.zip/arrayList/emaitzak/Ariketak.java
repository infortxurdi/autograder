package arrayList.emaitzak;

import java.util.ArrayList;

public class Ariketak {

    // =============================================================
    // A BLOKEA: STRING ZERRENDAK (ArrayList<String>)
    // =============================================================

    /**
     * 1. ariketa: gehituErrepikatuGabe
     *
     * Elementu bat zerrendaren amaieran gehitzen du, baldin eta aurretik zerrendan ez badago.
     *
     * @param zerrenda  testuen ArrayLista.
     * @param elementua gehitu nahi den testua.
     * @return true elementua gehitu bada; false lehendik bazegoen edo parametroren bat null bada.
     */
    public static boolean gehituErrepikatuGabe(ArrayList<String> zerrenda, String elementua) {
        if (zerrenda == null || elementua == null) {
            return false;
        }
        if (!zerrenda.contains(elementua)) {
            zerrenda.add(elementua);
            return true;
        }
        return false;
    }

    /**
     * 2. ariketa: ezabatuLuzeraTxikikoak
     *
     * Gutxieneko luzera baino karaktere gutxiago (< gutxienekoLuzera) dituzten hitz guztiak
     * zerrendatik ezabatzen ditu.
     *
     * @param hitzak          aztertu eta aldatu beharreko String ArrayLista.
     * @param gutxienekoLuzera hitzak mantentzeko behar duen gutxieneko luzera.
     * @return Ezabatutako hitzen kopurua. 0 zerrenda nulua bada.
     */
    public static int ezabatuLuzeraTxikikoak(ArrayList<String> hitzak, int gutxienekoLuzera) {
        if (hitzak == null) {
            return 0;
        }
        int ezabatuak = 0;
        for (int i = hitzak.size() - 1; i >= 0; i--) {
            if (hitzak.get(i) != null && hitzak.get(i).length() < gutxienekoLuzera) {
                hitzak.remove(i);
                ezabatuak++;
            }
        }
        return ezabatuak;
    }

    /**
     * 3. ariketa: bilatuHitzLuzeena
     *
     * Zerrendako hitzik luzeena aurkitzen du. Berdinketa badago, lehenengo agertzen dena bueltatzen du.
     *
     * @param hitzak String ArrayLista.
     * @return Hitzik luzeena. null zerrenda nulua edo hutsik badago.
     */
    public static String bilatuHitzLuzeena(ArrayList<String> hitzak) {
        if (hitzak == null || hitzak.isEmpty()) {
            return null;
        }
        String luzeena = hitzak.get(0);
        for (int i = 1; i < hitzak.size(); i++) {
            String unekoa = hitzak.get(i);
            if (unekoa != null && (luzeena == null || unekoa.length() > luzeena.length())) {
                luzeena = unekoa;
            }
        }
        return luzeena;
    }

    /**
     * 4. ariketa: bihurtuMaiuskulara
     *
     * Jatorrizko zerrendako hitz guztiak maiuskulara bihurtuta dituen ArrayList BERRI bat bueltatzen du.
     * Jatorrizko zerrenda ez da aldatu behar.
     *
     * @param hitzak jatorrizko String ArrayLista.
     * @return Maiuskulaz dauden hitzen ArrayList berria. Zerrenda hutsa jatorrizkoa nulua bada.
     */
    public static ArrayList<String> bihurtuMaiuskulara(ArrayList<String> hitzak) {
        ArrayList<String> emaitza = new ArrayList<>();
        if (hitzak == null) {
            return emaitza;
        }
        for (String hitza : hitzak) {
            if (hitza != null) {
                emaitza.add(hitza.toUpperCase());
            }
        }
        return emaitza;
    }

    /**
     * 5. ariketa: zenbatuHasieraLetra
     *
     * Adierazitako letraz hasten diren zenbat hitz dauden zenbatzen du (maiuskulak eta minuskulak bereizi gabe).
     *
     * @param hitzak String ArrayLista.
     * @param letra  bilatu nahi den hasierako karakterea.
     * @return Letra horrekin hasten diren hitzen kopurua. 0 zerrenda nulua edo hutsik badago.
     */
    public static int zenbatuHasieraLetra(ArrayList<String> hitzak, char letra) {
        if (hitzak == null || hitzak.isEmpty()) {
            return 0;
        }
        int kont = 0;
        char bilatua = Character.toLowerCase(letra);
        for (String hitza : hitzak) {
            if (hitza != null && !hitza.isEmpty() && Character.toLowerCase(hitza.charAt(0)) == bilatua) {
                kont++;
            }
        }
        return kont;
    }

    /**
     * 6. ariketa: ordezkatuHitza
     *
     * Zerrendan agertzen diren 'zaharra' hitz guztiak 'berria' hitzarekin ordezkatzen ditu zerrendan bertan.
     *
     * @param hitzak  aldatu nahi den String ArrayLista.
     * @param zaharra ordezkatu nahi den hitza.
     * @param berria  jarri nahi den hitz berria.
     * @return Egindako ordezkapen kopurua. 0 parametroren bat nulua bada.
     */
    public static int ordezkatuHitza(ArrayList<String> hitzak, String zaharra, String berria) {
        if (hitzak == null || zaharra == null || berria == null) {
            return 0;
        }
        int aldaketak = 0;
        for (int i = 0; i < hitzak.size(); i++) {
            if (zaharra.equals(hitzak.get(i))) {
                hitzak.set(i, berria);
                aldaketak++;
            }
        }
        return aldaketak;
    }

    /**
     * 7. ariketa: bateratuErrepikatuGabe
     *
     * Bi zerrendetako elementu guztiak elkartzen ditu ArrayList BERRI batean, errepikapenik gabe
     * eta agerpen-ordena mantenduz.
     *
     * @param z1 lehenengo String ArrayLista.
     * @param z2 bigarren String ArrayLista.
     * @return Bi zerrenden batasuna duen ArrayList berria (errepikaturik gabe).
     */
    public static ArrayList<String> bateratuErrepikatuGabe(ArrayList<String> z1, ArrayList<String> z2) {
        ArrayList<String> emaitza = new ArrayList<>();
        if (z1 != null) {
            for (String s : z1) {
                if (s != null && !emaitza.contains(s)) {
                    emaitza.add(s);
                }
            }
        }
        if (z2 != null) {
            for (String s : z2) {
                if (s != null && !emaitza.contains(s)) {
                    emaitza.add(s);
                }
            }
        }
        return emaitza;
    }

    // =============================================================
    // B BLOKEA: ZENBAKI ZERRENDAK (Integer eta Double)
    // =============================================================

    /**
     * 8. ariketa: batuBikoitiak
     *
     * Zerrendako zenbaki bikoiti guztien batura kalkulatzen du.
     *
     * @param zenbakiak Integer ArrayLista.
     * @return Zenbaki bikoitien batura. 0 zerrenda nulua edo hutsik badago.
     */
    public static int batuBikoitiak(ArrayList<Integer> zenbakiak) {
        if (zenbakiak == null) {
            return 0;
        }
        int batura = 0;
        for (Integer z : zenbakiak) {
            if (z != null && z % 2 == 0) {
                batura += z;
            }
        }
        return batura;
    }

    /**
     * 9. ariketa: ezabatuBalioGuztiak
     *
     * Zerrendatik adierazitako zenbakiaren agerpen guztiak ezabatzen ditu.
     *
     * @param zenbakiak Integer ArrayLista.
     * @param balioa    ezabatu nahi den zenbaki osoa.
     * @return true gutxienez elementu bat ezabatu bada; false bestela edo zerrenda nulua bada.
     */
    public static boolean ezabatuBalioGuztiak(ArrayList<Integer> zenbakiak, int balioa) {
        if (zenbakiak == null) {
            return false;
        }
        boolean ezabatua = false;
        while (zenbakiak.remove(Integer.valueOf(balioa))) {
            ezabatua = true;
        }
        return ezabatua;
    }

    /**
     * 10. ariketa: batezBestekoaGainditzenDutenak
     *
     * Zerrendako noten batez besteko aritmetikoa kalkulatzen du, eta batez besteko hori baino
     * hertsiki handiagoak (> batezBestekoa) diren notekin ArrayList BERRI bat bueltatzen du.
     *
     * @param notak Double motako noten ArrayLista.
     * @return Batez bestekoa gainditzen duten noten ArrayList berria. Zerrenda hutsa nulua edo hutsik badago.
     */
    public static ArrayList<Double> batezBestekoaGainditzenDutenak(ArrayList<Double> notak) {
        ArrayList<Double> emaitza = new ArrayList<>();
        if (notak == null || notak.isEmpty()) {
            return emaitza;
        }
        double batura = 0.0;
        for (Double nota : notak) {
            batura += nota;
        }
        double batezBestekoa = batura / notak.size();
        for (Double nota : notak) {
            if (nota > batezBestekoa) {
                emaitza.add(nota);
            }
        }
        return emaitza;
    }

    /**
     * 11. ariketa: txertatuOrdenatuta
     *
     * Goranzko ordenan ordenatuta dagoen zerrenda batean zenbaki berri bat txertatzen du
     * dagokion posizioan, zerrendak ordenatuta jarrai dezan.
     *
     * @param zerrendaOrdenatua goranzko ordenan dagoen Integer ArrayLista.
     * @param berria            txertatu nahi den zenbakia.
     */
    public static void txertatuOrdenatuta(ArrayList<Integer> zerrendaOrdenatua, int berria) {
        if (zerrendaOrdenatua == null) {
            return;
        }
        int i = 0;
        while (i < zerrendaOrdenatua.size() && zerrendaOrdenatua.get(i) < berria) {
            i++;
        }
        zerrendaOrdenatua.add(i, berria);
    }

    /**
     * 12. ariketa: bigarrenHandiena
     *
     * Zerrendako bigarren balio handiena (desberdina) aurkitzen du.
     *
     * @param zenbakiak Integer ArrayLista.
     * @return Bigarren zenbaki handiena. Integer.MIN_VALUE nulua bada edo 2 balio desberdin baino gutxiago baditu.
     */
    public static int bigarrenHandiena(ArrayList<Integer> zenbakiak) {
        if (zenbakiak == null || zenbakiak.size() < 2) {
            return Integer.MIN_VALUE;
        }
        int handiena = Integer.MIN_VALUE;
        int bigarrena = Integer.MIN_VALUE;
        boolean badagoHandiena = false;
        boolean badagoBigarrena = false;

        for (Integer z : zenbakiak) {
            if (z == null) {
                continue;
            }
            if (!badagoHandiena || z > handiena) {
                if (badagoHandiena) {
                    bigarrena = handiena;
                    badagoBigarrena = true;
                }
                handiena = z;
                badagoHandiena = true;
            } else if (z < handiena && (!badagoBigarrena || z > bigarrena)) {
                bigarrena = z;
                badagoBigarrena = true;
            }
        }
        return badagoBigarrena ? bigarrena : Integer.MIN_VALUE;
    }

    /**
     * 13. ariketa: aplikatuDeskontua
     *
     * Zerrendako prezio guztiei ehuneko deskontu bat aplikatzen die zerrendan bertan.
     * Ehunekoa 0 baino txikiagoa edo 100 baino handiagoa bada, ez du aldaketarik egiten.
     *
     * @param prezioak  Double motako prezioen ArrayLista.
     * @param ehunekoa deskontuaren ehunekoa (0.0 eta 100.0 artekoa).
     */
    public static void aplikatuDeskontua(ArrayList<Double> prezioak, double ehunekoa) {
        if (prezioak == null || ehunekoa < 0.0 || ehunekoa > 100.0) {
            return;
        }
        for (int i = 0; i < prezioak.size(); i++) {
            double prezioBerria = prezioak.get(i) * (1.0 - ehunekoa / 100.0);
            prezioak.set(i, prezioBerria);
        }
    }

    /**
     * 14. ariketa: iragaziTartea
     *
     * [min, max] tartean dauden zenbakiekin (biak barne) ArrayList BERRI bat bueltatzen du.
     *
     * @param zenbakiak jatorrizko Integer ArrayLista.
     * @param min       gutxieneko balioa (barne).
     * @param max       gehienezko balioa (barne).
     * @return Tartean dauden zenbakien ArrayList berria. Zerrenda hutsa nulua bada.
     */
    public static ArrayList<Integer> iragaziTartea(ArrayList<Integer> zenbakiak, int min, int max) {
        ArrayList<Integer> emaitza = new ArrayList<>();
        if (zenbakiak == null) {
            return emaitza;
        }
        for (Integer z : zenbakiak) {
            if (z != null && z >= min && z <= max) {
                emaitza.add(z);
            }
        }
        return emaitza;
    }

    // =============================================================
    // C BLOKEA: KLASE PROPIOEN ZERRENDAK (Ikaslea eta Produktua)
    // =============================================================

    /**
     * 15. ariketa: lortuGaindituenIzenak
     *
     * Irakasgaia gainditu duten ikasleen (nota >= 5.0) izenekin ArrayList<String> BERRI bat bueltatzen du.
     *
     * @param ikasleak Ikaslea objektuen ArrayLista.
     * @return Gainditutako ikasleen izenen ArrayLista. Zerrenda hutsa nulua bada.
     */
    public static ArrayList<String> lortuGaindituenIzenak(ArrayList<Ikaslea> ikasleak) {
        ArrayList<String> emaitza = new ArrayList<>();
        if (ikasleak == null) {
            return emaitza;
        }
        for (Ikaslea ikaslea : ikasleak) {
            if (ikaslea != null && ikaslea.gainditutaDago()) {
                emaitza.add(ikaslea.getIzena());
            }
        }
        return emaitza;
    }

    /**
     * 16. ariketa: ikasleOnena
     *
     * Notarik altuena duen Ikaslea bueltatzen du. Berdinketa badago, lehenengo agertzen dena.
     *
     * @param ikasleak Ikaslea objektuen ArrayLista.
     * @return Notarik altuena duen Ikaslea objektua. null zerrenda nulua edo hutsik badago.
     */
    public static Ikaslea ikasleOnena(ArrayList<Ikaslea> ikasleak) {
        if (ikasleak == null || ikasleak.isEmpty()) {
            return null;
        }
        Ikaslea onena = ikasleak.get(0);
        for (int i = 1; i < ikasleak.size(); i++) {
            Ikaslea unekoa = ikasleak.get(i);
            if (unekoa != null && (onena == null || unekoa.getNota() > onena.getNota())) {
                onena = unekoa;
            }
        }
        return onena;
    }

    /**
     * 17. ariketa: igoNotaGuztiei
     *
     * Zerrendako ikasle guztiei adierazitako puntuak gehitzen dizkie notan, baina 10.0 muga gainditu gabe.
     * Puntuak <= 0 badira edo zerrenda nulua bada, ez du ezer egiten.
     *
     * @param ikasleak Ikaslea objektuen ArrayLista.
     * @param puntuak  gehitu nahi den puntu kopurua (> 0).
     */
    public static void igoNotaGuztiei(ArrayList<Ikaslea> ikasleak, double puntuak) {
        if (ikasleak == null || puntuak <= 0) {
            return;
        }
        for (Ikaslea ikaslea : ikasleak) {
            if (ikaslea != null) {
                double notaBerria = Math.min(10.0, ikaslea.getNota() + puntuak);
                ikaslea.setNota(notaBerria);
            }
        }
    }

    /**
     * 18. ariketa: inbentarioarenBalioTotala
     *
     * Biltegiko produktu guztien balio ekonomiko totala kalkulatzen du (produktu bakoitzaren prezioa * stock batura).
     *
     * @param produktuak Produktua objektuen ArrayLista.
     * @return Inbentario osoaren balioa. 0.0 zerrenda nulua edo hutsik badago.
     */
    public static double inbentarioarenBalioTotala(ArrayList<Produktua> produktuak) {
        if (produktuak == null) {
            return 0.0;
        }
        double totala = 0.0;
        for (Produktua p : produktuak) {
            if (p != null) {
                totala += p.guztizkoBalioa();
            }
        }
        return totala;
    }

    /**
     * 19. ariketa: erosiProduktua
     *
     * Izenaren arabera produktua bilatzen du (maiuskulak/minuskulak bereizi gabe). Produktua existitzen bada
     * eta stock nahikoa badu (stock >= kantitatea eta kantitatea > 0), stocka murrizten du eta true bueltatzen du.
     *
     * @param produktuak Produktua objektuen ArrayLista.
     * @param izena      erosi nahi den produktuaren izena.
     * @param kantitatea erosi nahi den unitate kopurua.
     * @return true erosketa burutu bada; false produktua ez badago, stock nahikorik ez badago edo datuak okerrak badira.
     */
    public static boolean erosiProduktua(ArrayList<Produktua> produktuak, String izena, int kantitatea) {
        if (produktuak == null || izena == null || kantitatea <= 0) {
            return false;
        }
        for (Produktua p : produktuak) {
            if (p != null && p.getIzena() != null && p.getIzena().equalsIgnoreCase(izena)) {
                if (p.getStock() >= kantitatea) {
                    p.setStock(p.getStock() - kantitatea);
                    return true;
                }
                return false;
            }
        }
        return false;
    }

    /**
     * 20. ariketa: stockGutxikoProduktuak
     *
     * Adierazitako muga baino stock gutxiago (< muga) duten produktuekin ArrayList<Produktua> BERRI bat bueltatzen du.
     *
     * @param produktuak Produktua objektuen ArrayLista.
     * @param muga       gutxieneko stock atalasea.
     * @return Stock gutxiko produktuen ArrayList berria. Zerrenda hutsa zerrenda nulua bada.
     */
    public static ArrayList<Produktua> stockGutxikoProduktuak(ArrayList<Produktua> produktuak, int muga) {
        ArrayList<Produktua> emaitza = new ArrayList<>();
        if (produktuak == null) {
            return emaitza;
        }
        for (Produktua p : produktuak) {
            if (p != null && p.getStock() < muga) {
                emaitza.add(p);
            }
        }
        return emaitza;
    }
}