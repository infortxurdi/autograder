package arrayList.emaitzak;

public class Produktua {

    private String izena;
    private double prezioa;
    private int stock;

    public Produktua(String izena, double prezioa, int stock) {
        this.izena = izena;
        this.prezioa = prezioa;
        this.stock = stock;
    }

    public String getIzena() {
        return izena;
    }

    public double getPrezioa() {
        return prezioa;
    }

    public void setPrezioa(double prezioa) {
        this.prezioa = prezioa;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public double guztizkoBalioa() {
        return prezioa * stock;
    }
}