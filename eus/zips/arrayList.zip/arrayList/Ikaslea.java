package arrayList;

/**
 * Ikasle baten datuak gordetzen dituen klasea.
 * Ikasleak izena, adina eta batez besteko nota ditu.
 */
public class Ikaslea {

    // TODO: Definitu atributu pribatuak (izena, adina, nota)

    /**
     * Ikaslea objektu berri bat sortzen du.
     *
     * @param izena ikaslearen izena.
     * @param adina ikaslearen adina.
     * @param nota  ikaslearen nota (0.0 eta 10.0 artekoa).
     */
    public Ikaslea(String izena, int adina, double nota) {
        // TODO: Hasieratu atributuak
    }

    /**
     * Ikaslearen izena bueltatzen du.
     *
     * @return ikaslearen izena.
     */
    public String getIzena() {
        // TODO: Bueltatu izena
        return null;
    }

    /**
     * Ikaslearen adina bueltatzen du.
     *
     * @return ikaslearen adina.
     */
    public int getAdina() {
        // TODO: Bueltatu adina
        return 0;
    }

    /**
     * Ikaslearen nota bueltatzen du.
     *
     * @return ikaslearen nota.
     */
    public double getNota() {
        // TODO: Bueltatu nota
        return 0.0;
    }

    /**
     * Ikaslearen nota eguneratzen du.
     *
     * @param nota nota berria.
     */
    public void setNota(double nota) {
        // TODO: Eguneratu nota
    }

    /**
     * Ikasleak irakasgaia gainditu duen ala ez adierazten du (nota >= 5.0).
     *
     * @return true nota 5.0 edo handiagoa bada; false bestela.
     */
    public boolean gainditutaDago() {
        // TODO: Egiaztatu nota >= 5.0 den
        return false;
    }
}