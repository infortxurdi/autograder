package array;

public class Ariketak {

    // =============================================================
    // A BLOKEA: FOR INDIZIATUA (for (int i = 0; i < array.length; i++))
    // =============================================================

    /**
     * 1. ariketa: batuElementuak
     *
     * Zenbaki osoen array bateko elementu guztien batura kalkulatzen du.
     *
     * @param zenbakiak aztertu nahi den int arraya.
     * @return Elementu guztien batura osoa. 0 arraya nulua edo hutsik badago.
     *
     * Adibideak:
     * - batuElementuak(new int[]{1, 2, 3, 4, 5}) -> 15
     * - batuElementuak(new int[]{-2, 5, -3}) -> 0
     * - batuElementuak(new int[]{}) -> 0
     * - batuElementuak(null) -> 0
     */
    public static int batuElementuak(int[] zenbakiak) {
        // TODO: Inplementatu indiziatutako 'for' buklea erabiliz
        return 0;
    }

    /**
     * 2. ariketa: batezBestekoaKalkulatu
     *
     * Zuzeneko kalifikazioen (double) batez bestekoa kalkulatzen du.
     *
     * @param notak kalifikazioak dituen double arraya.
     * @return Noten batez besteko aritmetikoa. -1.0 arraya nulua edo hutsik badago.
     *
     * Adibideak:
     * - batezBestekoaKalkulatu(new double[]{5.0, 7.0, 9.0}) -> 7.0
     * - batezBestekoaKalkulatu(new double[]{10.0}) -> 10.0
     * - batezBestekoaKalkulatu(new double me[]{}) -> -1.0
     * - batezBestekoaKalkulatu(null) -> -1.0
     */
    public static double batezBestekoaKalkulatu(double[] notak) {
        // TODO: Inplementatu indiziatutako 'for' buklea erabiliz
        return -1.0;
    }

    /**
     * 3. ariketa: handienaAurkitu
     *
     * Array bateko baliorik handiena aurkitzen du.
     *
     * @param zenbakiak zenbaki osoen arraya.
     * @return Arrayko baliorik handiena. Integer.MIN_VALUE arraya nulua edo hutsik badago.
     *
     * Adibideak:
     * - handienaAurkitu(new int[]{3, 8, 2, 11, 4}) -> 11
     * - handienaAurkitu(new int[]{-10, -5, -20}) -> -5
     * - handienaAurkitu(new int[]{}) -> Integer.MIN_VALUE (-2147483648)
     * - handienaAurkitu(null) -> Integer.MIN_VALUE (-2147483648)
     */
    public static int handienaAurkitu(int[] zenbakiak) {
        // TODO: Inplementatu indiziatutako 'for' buklea erabiliz
        return Integer.MIN_VALUE;
    }

    /**
     * 4. ariketa: gutxienekoaAurkitu
     *
     * Array bateko baliorik txikiena aurkitzen du.
     *
     * @param zenbakiak zenbaki osoen arraya.
     * @return Arrayko baliorik txikiena. Integer.MAX_VALUE arraya nulua edo hutsik badago.
     *
     * Adibideak:
     * - gutxienekoaAurkitu(new int[]{3, 8, 2, 11, 4}) -> 2
     * - gutxienekoaAurkitu(new int[]{-10, -5, -20}) -> -20
     * - gutxienekoaAurkitu(new int[]{}) -> Integer.MAX_VALUE (2147483647)
     * - gutxienekoaAurkitu(null) -> Integer.MAX_VALUE (2147483647)
     */
    public static int gutxienekoaAurkitu(int[] zenbakiak) {
        // TODO: Inplementatu indiziatutako 'for' buklea erabiliz
        return Integer.MAX_VALUE;
    }

    /**
     * 5. ariketa: zenbatuNegatiboak
     *
     * Arrayan zenbat zenbaki negatibo (< 0) dauden zenbatzen du.
     *
     * @param zenbakiak zenbaki osoen arraya.
     * @return Zenbaki negatiboen kopurua. 0 arraya nulua/hutsik badago edo negatiborik ez badago.
     *
     * Adibideak:
     * - zenbatuNegatiboak(new int[]{1, -2, 3, -4, -5}) -> 3
     * - zenbatuNegatiboak(new int[]{1, 2, 3}) -> 0
     * - zenbatuNegatiboak(null) -> 0
     */
    public static int zenbatuNegatiboak(int[] zenbakiak) {
        // TODO: Inplementatu indiziatutako 'for' buklea erabiliz
        return 0;
    }

    /**
     * 6. ariketa: zenbatuPositiboak
     *
     * Arrayan zenbat zenbaki positibo (> 0) dauden zenbatzen du (0 ez da positiboa).
     *
     * @param zenbakiak zenbaki osoen arraya.
     * @return Zenbaki positiboen kopurua. 0 arraya nulua/hutsik badago edo positiborik ez badago.
     *
     * Adibideak:
     * - zenbatuPositiboak(new int[]{1, -2, 3, 0, 5}) -> 3
     * - zenbatuPositiboak(new int[]{-1, -2, 0}) -> 0
     * - zenbatuPositiboak(null) -> 0
     */
    public static int zenbatuPositiboak(int[] zenbakiak) {
        // TODO: Inplementatu indiziatutako 'for' buklea erabiliz
        return 0;
    }

    /**
     * 7. ariketa: kenduElementuak
     *
     * Lehenengo elementuari gainerako elementu guztiak sekuentzialki kentzen dizkio.
     *
     * @param zenbakiak zenbaki osoen arraya.
     * @return Kenketaren emaitza. 0 arraya nulua edo hutsik badago.
     *
     * Adibideak:
     * - kenduElementuak(new int[]{10, 2, 3}) -> 5  (10 - 2 - 3)
     * - kenduElementuak(new int[]{7}) -> 7
     * - kenduElementuak(new int[]{}) -> 0
     * - kenduElementuak(null) -> 0
     */
    public static int kenduElementuak(int[] zenbakiak) {
        // TODO: Inplementatu indiziatutako 'for' buklea erabiliz
        return 0;
    }

    /**
     * 8. ariketa: batuIndizeBikoitiak
     *
     * Indize bikoitietan (0, 2, 4...) dauden zenbakiak bakarrik batzen ditu.
     *
     * @param zenbakiak zenbaki osoen arraya.
     * @return Indize bikoitietako balioen batura. 0 arraya nulua edo hutsik badago.
     *
     * Adibideak:
     * - batuIndizeBikoitiak(new int[]{10, 20, 30, 40, 50}) -> 90  (indizeak 0, 2, 4 -> 10 + 30 + 50)
     * - batuIndizeBikoitiak(new int[]{5}) -> 5                    (indizea 0 -> 5)
     * - batuIndizeBikoitiak(null) -> 0
     */
    public static int batuIndizeBikoitiak(int[] zenbakiak) {
        // TODO: Inplementatu indiziatutako 'for' buklea erabiliz
        return 0;
    }

    /**
     * 9. ariketa: bihurtuNegatiboIndizeBakoitiak
     *
     * Array berri bat bueltatzen du, indize bakoitietako (1, 3, 5...) balio guztiak zenbaki negatibo bihurtuta.
     *
     * @param zenbakiak jatorrizko int arraya.
     * @return Array berria aldatutako balioekin. new int[0] arraya nulua bada.
     *
     * Adibideak:
     * - bihurtuNegatiboIndizeBakoitiak(new int[]{5, 4, 3, 2}) -> {5, -4, 3, -2}
     * - bihurtuNegatiboIndizeBakoitiak(new int[]{5, -4, 3, -2}) -> {5, -4, 3, -2}
     * - bihurtuNegatiboIndizeBakoitiak(null) -> {}
     */
    public static int[] bihurtuNegatiboIndizeBakoitiak(int[] zenbakiak) {
        // TODO: Inplementatu indiziatutako 'for' buklea erabiliz
        return new int[0];
    }

    /**
     * 10. ariketa: lortuTamaina
     *
     * Arrayaren tamaina (elementu kopurua) bueltatzen du.
     *
     * @param zenbakiak int arraya.
     * @return Arrayaren luzera. 0 arraya nulua bada.
     *
     * Adibideak:
     * - lortuTamaina(new int[]{1, 2, 3, 4}) -> 4
     * - lortuTamaina(new int[]{}) -> 0
     * - lortuTamaina(null) -> 0
     */
    public static int lortuTamaina(int[] zenbakiak) {
        // TODO: Inplementatu tamaina lortuz
        return 0;
    }

    /**
     * 11. ariketa: elementuaDago
     *
     * Testu jakin bat array barruan dagoen ala ez bilatzen du.
     *
     * @param hitzak kateen (String) arraya.
     * @param bilatutakoa bilatu nahi den testua.
     * @return true testua arrayan badago; false bestela edo balioak null badira.
     *
     * Adibideak:
     * - elementuaDago(new String[]{"Java", "Python", "C++"}, "Python") -> true
     * - elementuaDago(new String[]{"Java", "Python", "C++"}, "PHP") -> false
     * - elementuaDago(null, "Java") -> false
     */
    public static boolean elementuaDago(String[] hitzak, String bilatutakoa) {
        // TODO: Inplementatu indiziatutako 'for' buklea erabiliz
        return false;
    }

    /**
     * 12. ariketa: zenbatuBikoitiak
     *
     * Array batean zenbat zenbaki bikoiti dauden zenbatzen du.
     *
     * @param zenbakiak zenbaki osoen arraya.
     * @return Zenbaki bikoitien kopurua. 0 arraya nulua badago edo bikoitirik ez badago.
     *
     * Adibideak:
     * - zenbatuBikoitiak(new int[]{1, 2, 3, 4, 6, 7}) -> 3
     * - zenbatuBikoitiak(new int[]{1, 3, 5}) -> 0
     * - zenbatuBikoitiak(null) -> 0
     */
    public static int zenbatuBikoitiak(int[] zenbakiak) {
        // TODO: Inplementatu indiziatutako 'for' buklea erabiliz
        return 0;
    }

    /**
     * 13. ariketa: alderantzizkoArraya
     *
     * Array berri bat sortzen du jatorrizkoaren elementuak alderantzizko ordenan jarriz.
     *
     * @param zenbakiak jatorrizko int arraya.
     * @return Array berria alderantzikatutako elementuekin. new int[0] arraya nulua bada.
     *
     * Adibideak:
     * - alderantzizkoArraya(new int[]{1, 2, 3, 4}) -> {4, 3, 2, 1}
     * - alderantzizkoArraya(new int[]{7}) -> {7}
     * - alderantzizkoArraya(null) -> {}
     */
    public static int[] alderantzizkoArraya(int[] zenbakiak) {
        // TODO: Inplementatu indiziatutako 'for' buklea erabiliz
        return new int[0];
    }

    /**
     * 14. ariketa: gehituElementua
     *
     * Array berri bat sortzen du jatorrizkoari amaieran balio berri bat gehituz.
     *
     * @param zenbakiak jatorrizko arraya.
     * @param berria gehitu nahi den balio oso berria.
     * @return Array berria elementu bat gehiagorekin. {berria} jatorrizkoa nulua bada.
     *
     * Adibideak:
     * - gehituElementua(new int[]{1, 2}, 3) -> {1, 2, 3}
     * - gehituElementua(new int[]{}, 5) -> {5}
     * - gehituElementua(null, 5) -> {5}
     */
    public static int[] gehituElementua(int[] zenbakiak, int berria) {
        // TODO: Inplementatu array berri bat sortuz eta kopiak eginez
        return new int[0];
    }

    /**
     * 15. ariketa: kenduIndizekoElementua
     *
     * Array berri bat sortzen du adierazitako indizean dagoen elementua kenduta.
     *
     * @param zenbakiak jatorrizko arraya.
     * @param indizea kendu nahi den posizioa (0-tik hasita).
     * @return Array berria elementu bat gutxiagorekin. Jatorrizkoaren kopia indizea okerra bada.
     *
     * Adibideak:
     * - kenduIndizekoElementua(new int[]{10, 20, 30, 40}, 1) -> {10, 30, 40}
     * - kenduIndizekoElementua(new int[]{10, 20}, 5) -> {10, 20}
     * - kenduIndizekoElementua(null, 0) -> {}
     */
    public static int[] kenduIndizekoElementua(int[] zenbakiak, int indizea) {
        // TODO: Inplementatu array berri bat sortuz hautatutako indizea kanpoan utziz
        return new int[0];
    }

    // =============================================================
    // B BLOKEA: WHILE BUKLEA
    // =============================================================

    /**
     * 16. ariketa: lehenNegatiboarenIndizea
     *
     * Arrayan lehenengo zenbaki negatiboaren indizea aurkitzen du while erabiliz.
     *
     * @param zenbakiak zenbaki osoen arraya.
     * @return Lehenengo zenbaki negatiboaren indizea. -1 negatiborik ez badago edo arraya nulua badago.
     *
     * Adibideak:
     * - lehenNegatiboarenIndizea(new int[]{5, 8, -3, 10, -2}) -> 2
     * - lehenNegatiboarenIndizea(new int[]{1, 2, 3}) -> -1
     * - lehenNegatiboarenIndizea(null) -> -1
     */
    public static int lehenNegatiboarenIndizea(int[] zenbakiak) {
        // TODO: Inplementatu 'while' buklea erabiliz
        return -1;
    }

    /**
     * 17. ariketa: batuMugaraArte
     *
     * Zenbakiak batzen ditu lehen elementutik muga batera iritsi arte (muga gainditu gabe) while erabiliz.
     *
     * @param zenbakiak zenbaki osoen arraya.
     * @param muga baturak gainditu ezin duen gehienezko balioa.
     * @return Lortutako gehienezko batura. 0 lehen elementua > muga bada edo arraya nulua badago.
     *
     * Adibideak:
     * - batuMugaraArte(new int[]{10, 20, 15, 30}, 40) -> 35  (10 + 20 <= 40; 10 + 20 + 15 > 40 denez geratu egiten da)
     * - batuMugaraArte(new int[]{50, 10}, 40) -> 0          (50 > 40 denez ezin du bat ere batu)
     * - batuMugaraArte(null, 40) -> 0
     */
    public static int batuMugaraArte(int[] zenbakiak, int muga) {
        // TODO: Inplementatu 'while' buklea erabiliz
        return 0;
    }

    /**
     * 18. ariketa: ordenatutaDago
     *
     * Array bat goranzko ordenan ordenatuta dagoen ala ez egiaztatzen du while erabiliz.
     *
     * @param zenbakiak aztertu nahi den int arraya.
     * @return true goranzko ordenan badago edo 0-1 elementu baditu; false desordenatuta edo nulua bada.
     *
     * Adibideak:
     * - ordenatutaDago(new int[]{1, 3, 5, 7, 9}) -> true
     * - ordenatutaDago(new int[]{1, 5, 3, 7}) -> false
     * - ordenatutaDago(new int[]{4}) -> true
     * - ordenatutaDago(null) -> false
     */
    public static boolean ordenatutaDago(int[] zenbakiak) {
        // TODO: Inplementatu 'while' buklea erabiliz
        return false;
    }

    /**
     * 19. ariketa: palindromoaDa
     *
     * Array bat palindromoa den ala ez aztertzen du while erabiliz.
     *
     * @param zenbakiak int arraya.
     * @return true palindromoa bada; false ez bada edo nulua bada.
     *
     * Adibideak:
     * - palindromoaDa(new int[]{1, 2, 3, 2, 1}) -> true
     * - palindromoaDa(new int[]{1, 2, 2, 1}) -> true
     * - palindromoaDa(new int[]{1, 2, 3, 4}) -> false
     * - palindromoaDa(null) -> false
     */
    public static boolean palindromoaDa(int[] zenbakiak) {
        // TODO: Inplementatu 'while' buklea erabiliz bi erakusle konbinatuz
        return false;
    }

    /**
     * 20. ariketa: biAgerraldienArtekoDistantzia
     *
     * Target balioaren lehenengo bi agerraldien arteko distantzia (indize kendura) kalkulatzen du while erabiliz.
     *
     * @param zenbakiak aztertu nahi den arraya.
     * @param target bilatu nahi den balioa.
     * @return Bi agerraldien arteko distantzia (indize2 - indize1). -1 gutxienez bi aldiz agertzen ez bada.
     *
     * Adibideak:
     * - biAgerraldienArtekoDistantzia(new int[]{4, 7, 2, 7, 9, 7}, 7) -> 2  (1 eta 3 indizeetan agertzen da -> 3 - 1 = 2)
     * - biAgerraldienArtekoDistantzia(new int[]{1, 5, 3}, 5) -> -1           (behin bakarrik agertzen da)
     * - biAgerraldienArtekoDistantzia(new int[]{3, 3}, 3) -> 1              (0 eta 1 indizeetan agertzen da -> 1 - 0 = 1)
     * - biAgerraldienArtekoDistantzia(null, 7) -> -1
     */
    public static int biAgerraldienArtekoDistantzia(int[] zenbakiak, int target) {
        // TODO: Inplementatu 'while' buklea erabiliz
        return -1;
    }
}