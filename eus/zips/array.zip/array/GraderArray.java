package array;

import java.util.Arrays;

public class GraderArray {

    // ANSI kolore-kodeak kontsolan bistaratzeko
    private static final String RESET = "\u001B[0m";
    private static final String RED = "\u001B[31m";
    private static final String GREEN = "\u001B[32m";
    private static final String YELLOW = "\u001B[33m";
    private static final String CYAN = "\u001B[36m";
    private static final String BOLD = "\u001B[1m";

    private static int totalTests = 0;
    private static int passedTests = 0;

    public static void main(String[] args) {
        System.out.println(CYAN + "==================================================");
        System.out.println("   ARRAY ARIKETEN EBALUATZAILE AUTOMATIKOA        ");
        System.out.println("==================================================" + RESET + "\n");

        // A BLOKEA: FOR INDIZIATUA ETA ERAGIKETA SINPLEAK
        if (shouldRun(1)) testBatuElementuak();
        if (shouldRun(2)) testBatezBestekoaKalkulatu();
        if (shouldRun(3)) testHandienaAurkitu();
        if (shouldRun(4)) testGutxienekoaAurkitu();
        if (shouldRun(5)) testZenbatuNegatiboak();
        if (shouldRun(6)) testZenbatuPositiboak();
        if (shouldRun(7)) testKenduElementuak();
        if (shouldRun(8)) testBatuIndizeBikoitiak();
        if (shouldRun(9)) testBihurtuNegatiboIndizeBakoitiak();
        if (shouldRun(10)) testLortuTamaina();
        if (shouldRun(11)) testElementuaDago();
        if (shouldRun(12)) testZenbatuBikoitiak();
        if (shouldRun(13)) testAlderantzizkoArraya();
        if (shouldRun(14)) testGehituElementua();
        if (shouldRun(15)) testKenduIndizekoElementua();

        // B BLOKEA: WHILE BUKLEA
        if (shouldRun(16)) testLehenNegatiboarenIndizea();
        if (shouldRun(17)) testBatuMugaraArte();
        if (shouldRun(18)) testOrdenatutaDago();
        if (shouldRun(19)) testPalindromoaDa();
        if (shouldRun(20)) testBiAgerraldienArtekoDistantzia();

        // Azken laburpena
        double porcentaje = totalTests > 0 ? ((double) passedTests / totalTests) * 100 : 0.0;

        System.out.println("\n" + CYAN + "==================================================" + RESET);
        System.out.printf(BOLD + " AZKEN EMAITZA: %d / %d proba gaindituta (%%%.1f)\n" + RESET,
                passedTests, totalTests, porcentaje);

        System.out.println(CYAN + "==================================================" + RESET);

        if (totalTests > 0 && passedTests == totalTests) {
            System.out.println(GREEN + "🎉 Lan bikaina! Arrayen metodo guztiek egoki funtzionatzen dute." + RESET);
        } else if (totalTests > 0) {
            System.out.println(YELLOW + "⚠️ Berrikusi [ERROREA] gisa markatutako ariketak eta saiatu berriro." + RESET);
        } else {
            System.out.println(YELLOW + "⚠️ Ez da probarik exekutatu. Konfigurazioa berrikusi." + RESET);
        }
    }

    private static boolean shouldRun(int exerciseNumber) {
        return ConfigGrader.RUN_ALL || ConfigGrader.EXERCISE_NUMBER == exerciseNumber;
    }

    private static void test(String probarenIzena, boolean resultado, String esperado, String obtenido) {
        totalTests++;
        if (resultado) {
            passedTests++;
            System.out.printf("  " + GREEN + "[OK]" + RESET + " %s\n", probarenIzena);
        } else {
            System.out.printf("  " + RED + "[ERROREA]" + RESET + " %s | Esperotakoa: '%s' -> Lortutakoa: '%s'\n", probarenIzena, esperado, obtenido);
        }
    }

    // --- 1. TESTA: batuElementuak ---
    private static void testBatuElementuak() {
        System.out.println(BOLD + "--- 1. ariketa: batuElementuak ---" + RESET);
        int r1 = Ariketak.batuElementuak(new int[]{1, 2, 3, 4, 5});
        test("Batura {1, 2, 3, 4, 5}", r1 == 15, "15", String.valueOf(r1));

        int r2 = Ariketak.batuElementuak(new int[]{-2, 5, -3});
        test("Batura {-2, 5, -3}", r2 == 0, "0", String.valueOf(r2));

        int r3 = Ariketak.batuElementuak(new int[]{});
        test("Batura array hutsik", r3 == 0, "0", String.valueOf(r3));

        int r4 = Ariketak.batuElementuak(null);
        test("Batura null denean", r4 == 0, "0", String.valueOf(r4));
    }

    // --- 2. TESTA: batezBestekoaKalkulatu ---
    private static void testBatezBestekoaKalkulatu() {
        System.out.println("\n" + BOLD + "--- 2. ariketa: batezBestekoaKalkulatu ---" + RESET);
        double r1 = Ariketak.batezBestekoaKalkulatu(new double[]{5.0, 7.0, 9.0});
        test("Batez bestekoa {5.0, 7.0, 9.0}", Math.abs(r1 - 7.0) < 0.001, "7.0", String.valueOf(r1));

        double r2 = Ariketak.batezBestekoaKalkulatu(new double[]{10.0});
        test("Batez bestekoa {10.0}", Math.abs(r2 - 10.0) < 0.001, "10.0", String.valueOf(r2));

        double r3 = Ariketak.batezBestekoaKalkulatu(new double[]{});
        test("Batez bestekoa array hutsik", Math.abs(r3 - (-1.0)) < 0.001, "-1.0", String.valueOf(r3));

        double r4 = Ariketak.batezBestekoaKalkulatu(null);
        test("Batez bestekoa null denean", Math.abs(r4 - (-1.0)) < 0.001, "-1.0", String.valueOf(r4));
    }

    // --- 3. TESTA: handienaAurkitu ---
    private static void testHandienaAurkitu() {
        System.out.println("\n" + BOLD + "--- 3. ariketa: handienaAurkitu ---" + RESET);
        int r1 = Ariketak.handienaAurkitu(new int[]{3, 8, 2, 11, 4});
        test("Handiena {3, 8, 2, 11, 4}", r1 == 11, "11", String.valueOf(r1));

        int r2 = Ariketak.handienaAurkitu(new int[]{-10, -5, -20});
        test("Handiena {-10, -5, -20}", r2 == -5, "-5", String.valueOf(r2));

        int r3 = Ariketak.handienaAurkitu(new int[]{});
        test("Handiena array hutsik", r3 == Integer.MIN_VALUE, String.valueOf(Integer.MIN_VALUE), String.valueOf(r3));

        int r4 = Ariketak.handienaAurkitu(null);
        test("Handiena null denean", r4 == Integer.MIN_VALUE, String.valueOf(Integer.MIN_VALUE), String.valueOf(r4));
    }

    // --- 4. TESTA: gutxienekoaAurkitu ---
    private static void testGutxienekoaAurkitu() {
        System.out.println("\n" + BOLD + "--- 4. ariketa: gutxienekoaAurkitu ---" + RESET);
        int r1 = Ariketak.gutxienekoaAurkitu(new int[]{3, 8, 2, 11, 4});
        test("Gutxienekoa {3, 8, 2, 11, 4}", r1 == 2, "2", String.valueOf(r1));

        int r2 = Ariketak.gutxienekoaAurkitu(new int[]{-10, -5, -20});
        test("Gutxienekoa {-10, -5, -20}", r2 == -20, "-20", String.valueOf(r2));

        int r3 = Ariketak.gutxienekoaAurkitu(new int[]{});
        test("Gutxienekoa array hutsik", r3 == Integer.MAX_VALUE, String.valueOf(Integer.MAX_VALUE), String.valueOf(r3));

        int r4 = Ariketak.gutxienekoaAurkitu(null);
        test("Gutxienekoa null denean", r4 == Integer.MAX_VALUE, String.valueOf(Integer.MAX_VALUE), String.valueOf(r4));
    }

    // --- 5. TESTA: zenbatuNegatiboak ---
    private static void testZenbatuNegatiboak() {
        System.out.println("\n" + BOLD + "--- 5. ariketa: zenbatuNegatiboak ---" + RESET);
        int r1 = Ariketak.zenbatuNegatiboak(new int[]{1, -2, 3, -4, -5});
        test("Negatiboak {1, -2, 3, -4, -5}", r1 == 3, "3", String.valueOf(r1));

        int r2 = Ariketak.zenbatuNegatiboak(new int[]{1, 2, 3});
        test("Negatiboak ez daudenean {1, 2, 3}", r2 == 0, "0", String.valueOf(r2));

        int r3 = Ariketak.zenbatuNegatiboak(null);
        test("Negatiboak null denean", r3 == 0, "0", String.valueOf(r3));
    }

    // --- 6. TESTA: zenbatuPositiboak ---
    private static void testZenbatuPositiboak() {
        System.out.println("\n" + BOLD + "--- 6. ariketa: zenbatuPositiboak ---" + RESET);
        int r1 = Ariketak.zenbatuPositiboak(new int[]{1, -2, 3, 0, 5});
        test("Positiboak (>0) {1, -2, 3, 0, 5}", r1 == 3, "3", String.valueOf(r1));

        int r2 = Ariketak.zenbatuPositiboak(new int[]{-1, -2, 0});
        test("Positiboak ez daudenean {-1, -2, 0}", r2 == 0, "0", String.valueOf(r2));

        int r3 = Ariketak.zenbatuPositiboak(null);
        test("Positiboak null denean", r3 == 0, "0", String.valueOf(r3));
    }

    // --- 7. TESTA: kenduElementuak ---
    private static void testKenduElementuak() {
        System.out.println("\n" + BOLD + "--- 7. ariketa: kenduElementuak ---" + RESET);
        int r1 = Ariketak.kenduElementuak(new int[]{10, 2, 3});
        test("Kenketa (10 - 2 - 3)", r1 == 5, "5", String.valueOf(r1));

        int r2 = Ariketak.kenduElementuak(new int[]{7});
        test("Elementu bakarra {7}", r2 == 7, "7", String.valueOf(r2));

        int r3 = Ariketak.kenduElementuak(new int[]{});
        test("Array hutsik", r3 == 0, "0", String.valueOf(r3));

        int r4 = Ariketak.kenduElementuak(null);
        test("Array null denean", r4 == 0, "0", String.valueOf(r4));
    }

    // --- 8. TESTA: batuIndizeBikoitiak ---
    private static void testBatuIndizeBikoitiak() {
        System.out.println("\n" + BOLD + "--- 8. ariketa: batuIndizeBikoitiak ---" + RESET);
        int r1 = Ariketak.batuIndizeBikoitiak(new int[]{10, 20, 30, 40, 50});
        test("Batura (indizeak 0,2,4 -> 10+30+50)", r1 == 90, "90", String.valueOf(r1));

        int r2 = Ariketak.batuIndizeBikoitiak(new int[]{5});
        test("Elementu bakarra {5}", r2 == 5, "5", String.valueOf(r2));

        int r3 = Ariketak.batuIndizeBikoitiak(null);
        test("Null denean", r3 == 0, "0", String.valueOf(r3));
    }

    // --- 9. TESTA: bihurtuNegatiboIndizeBakoitiak ---
    private static void testBihurtuNegatiboIndizeBakoitiak() {
        System.out.println("\n" + BOLD + "--- 9. ariketa: bihurtuNegatiboIndizeBakoitiak ---" + RESET);
        int[] r1 = Ariketak.bihurtuNegatiboIndizeBakoitiak(new int[]{5, 4, 3, 2});
        test("Indize bakoitiak negatibo {5, 4, 3, 2}", Arrays.equals(r1, new int[]{5, -4, 3, -2}), "[5, -4, 3, -2]", Arrays.toString(r1));

        int[] r2 = Ariketak.bihurtuNegatiboIndizeBakoitiak(new int[]{5, -4, 3, -2});
        test("Dagoeneko negatiboak {5, -4, 3, -2}", Arrays.equals(r2, new int[]{5, -4, 3, -2}), "[5, -4, 3, -2]", Arrays.toString(r2));

        int[] r3 = Ariketak.bihurtuNegatiboIndizeBakoitiak(null);
        test("Null denean", r3 != null && r3.length == 0, "[]", Arrays.toString(r3));
    }

    // --- 10. TESTA: lortuTamaina ---
    private static void testLortuTamaina() {
        System.out.println("\n" + BOLD + "--- 10. ariketa: lortuTamaina ---" + RESET);
        int r1 = Ariketak.lortuTamaina(new int[]{1, 2, 3, 4});
        test("Tamaina {1, 2, 3, 4}", r1 == 4, "4", String.valueOf(r1));

        int r2 = Ariketak.lortuTamaina(new int[]{});
        test("Tamaina array hutsik", r2 == 0, "0", String.valueOf(r2));

        int r3 = Ariketak.lortuTamaina(null);
        test("Tamaina null denean", r3 == 0, "0", String.valueOf(r3));
    }

    // --- 11. TESTA: elementuaDago ---
    private static void testElementuaDago() {
        System.out.println("\n" + BOLD + "--- 11. ariketa: elementuaDago ---" + RESET);
        String[] datuak = {"Java", "Python", "C++"};
        boolean r1 = Ariketak.elementuaDago(datuak, "Python");
        test("Dago 'Python'", r1 == true, "true", String.valueOf(r1));

        boolean r2 = Ariketak.elementuaDago(datuak, "PHP");
        test("Ez dago 'PHP'", r2 == false, "false", String.valueOf(r2));

        boolean r3 = Ariketak.elementuaDago(null, "Java");
        test("Array null denean", r3 == false, "false", String.valueOf(r3));
    }

    // --- 12. TESTA: zenbatuBikoitiak ---
    private static void testZenbatuBikoitiak() {
        System.out.println("\n" + BOLD + "--- 12. ariketa: zenbatuBikoitiak ---" + RESET);
        int r1 = Ariketak.zenbatuBikoitiak(new int[]{1, 2, 3, 4, 6, 7});
        test("Bikoitiak {1, 2, 3, 4, 6, 7}", r1 == 3, "3", String.valueOf(r1));

        int r2 = Ariketak.zenbatuBikoitiak(new int[]{1, 3, 5});
        test("Bikoitiak ez daudenean", r2 == 0, "0", String.valueOf(r2));

        int r3 = Ariketak.zenbatuBikoitiak(null);
        test("Null denean", r3 == 0, "0", String.valueOf(r3));
    }

    // --- 13. TESTA: alderantzizkoArraya ---
    private static void testAlderantzizkoArraya() {
        System.out.println("\n" + BOLD + "--- 13. ariketa: alderantzizkoArraya ---" + RESET);
        int[] r1 = Ariketak.alderantzizkoArraya(new int[]{1, 2, 3, 4});
        test("Alderantziz {1, 2, 3, 4}", Arrays.equals(r1, new int[]{4, 3, 2, 1}), "[4, 3, 2, 1]", Arrays.toString(r1));

        int[] r2 = Ariketak.alderantzizkoArraya(new int[]{7});
        test("Elementu bakarra {7}", Arrays.equals(r2, new int[]{7}), "[7]", Arrays.toString(r2));

        int[] r3 = Ariketak.alderantzizkoArraya(null);
        test("Null denean", r3 != null && r3.length == 0, "[]", Arrays.toString(r3));
    }

    // --- 14. TESTA: gehituElementua ---
    private static void testGehituElementua() {
        System.out.println("\n" + BOLD + "--- 14. ariketa: gehituElementua ---" + RESET);
        int[] r1 = Ariketak.gehituElementua(new int[]{1, 2}, 3);
        test("Gehitu 3 arrayari {1, 2}", Arrays.equals(r1, new int[]{1, 2, 3}), "[1, 2, 3]", Arrays.toString(r1));

        int[] r2 = Ariketak.gehituElementua(new int[]{}, 5);
        test("Gehitu 5 array hutsari", Arrays.equals(r2, new int[]{5}), "[5]", Arrays.toString(r2));

        int[] r3 = Ariketak.gehituElementua(null, 5);
        test("Gehitu 5 null arrayari", Arrays.equals(r3, new int[]{5}), "[5]", Arrays.toString(r3));
    }

    // --- 15. TESTA: kenduIndizekoElementua ---
    private static void testKenduIndizekoElementua() {
        System.out.println("\n" + BOLD + "--- 15. ariketa: kenduIndizekoElementua ---" + RESET);
        int[] r1 = Ariketak.kenduIndizekoElementua(new int[]{10, 20, 30, 40}, 1);
        test("Kendu 1. indizea (20)", Arrays.equals(r1, new int[]{10, 30, 40}), "[10, 30, 40]", Arrays.toString(r1));

        int[] r2 = Ariketak.kenduIndizekoElementua(new int[]{10, 20}, 5);
        test("Eremuz kanpoko indize handia (5)", Arrays.equals(r2, new int[]{10, 20}), "[10, 20]", Arrays.toString(r2));

        int[] r3 = Ariketak.kenduIndizekoElementua(null, 0);
        test("Null denean", r3 != null && r3.length == 0, "[]", Arrays.toString(r3));
    }

    // --- 16. TESTA: lehenNegatiboarenIndizea ---
    private static void testLehenNegatiboarenIndizea() {
        System.out.println("\n" + BOLD + "--- 16. ariketa: lehenNegatiboarenIndizea (while) ---" + RESET);
        int r1 = Ariketak.lehenNegatiboarenIndizea(new int[]{5, 8, -3, 10, -2});
        test("Lehen negatiboa {5, 8, -3, 10, -2}", r1 == 2, "2", String.valueOf(r1));

        int r2 = Ariketak.lehenNegatiboarenIndizea(new int[]{1, 2, 3});
        test("Negatiborik ez {1, 2, 3}", r2 == -1, "-1", String.valueOf(r2));

        int r3 = Ariketak.lehenNegatiboarenIndizea(null);
        test("Null denean", r3 == -1, "-1", String.valueOf(r3));
    }

    // --- 17. TESTA: batuMugaraArte ---
    private static void testBatuMugaraArte() {
        System.out.println("\n" + BOLD + "--- 17. ariketa: batuMugaraArte (while) ---" + RESET);
        int r1 = Ariketak.batuMugaraArte(new int[]{10, 20, 15, 30}, 40);
        test("Batu {10, 20, 15, 30} muga 40", r1 == 35, "35", String.valueOf(r1));

        int r2 = Ariketak.batuMugaraArte(new int[]{50, 10}, 40);
        test("Lehenengoak muga gainditzen denean", r2 == 0, "0", String.valueOf(r2));

        int r3 = Ariketak.batuMugaraArte(null, 40);
        test("Null denean", r3 == 0, "0", String.valueOf(r3));
    }

    // --- 18. TESTA: ordenatutaDago ---
    private static void testOrdenatutaDago() {
        System.out.println("\n" + BOLD + "--- 18. ariketa: ordenatutaDago (while) ---" + RESET);
        boolean r1 = Ariketak.ordenatutaDago(new int[]{1, 3, 5, 7, 9});
        test("Ordenatuta {1, 3, 5, 7, 9}", r1 == true, "true", String.valueOf(r1));

        boolean r2 = Ariketak.ordenatutaDago(new int[]{1, 5, 3, 7});
        test("Desordenatuta {1, 5, 3, 7}", r2 == false, "false", String.valueOf(r2));

        boolean r3 = Ariketak.ordenatutaDago(new int[]{4});
        test("Elementu bakarra {4}", r3 == true, "true", String.valueOf(r3));

        boolean r4 = Ariketak.ordenatutaDago(null);
        test("Null denean", r4 == false, "false", String.valueOf(r4));
    }

    // --- 19. TESTA: palindromoaDa ---
    private static void testPalindromoaDa() {
        System.out.println("\n" + BOLD + "--- 19. ariketa: palindromoaDa (while) ---" + RESET);
        boolean r1 = Ariketak.palindromoaDa(new int[]{1, 2, 3, 2, 1});
        test("Palindromoa {1, 2, 3, 2, 1}", r1 == true, "true", String.valueOf(r1));

        boolean r2 = Ariketak.palindromoaDa(new int[]{1, 2, 2, 1});
        test("Palindromoa {1, 2, 2, 1}", r2 == true, "true", String.valueOf(r2));

        boolean r3 = Ariketak.palindromoaDa(new int[]{1, 2, 3, 4});
        test("Ez da palindromoa {1, 2, 3, 4}", r3 == false, "false", String.valueOf(r3));

        boolean r4 = Ariketak.palindromoaDa(null);
        test("Null denean", r4 == false, "false", String.valueOf(r4));
    }

    // --- 20. TESTA: biAgerraldienArtekoDistantzia ---
    private static void testBiAgerraldienArtekoDistantzia() {
        System.out.println("\n" + BOLD + "--- 20. ariketa: biAgerraldienArtekoDistantzia (while) ---" + RESET);
        int r1 = Ariketak.biAgerraldienArtekoDistantzia(new int[]{4, 7, 2, 7, 9, 7}, 7);
        test("Distantzia {4, 7, 2, 7, 9, 7} (target 7)", r1 == 2, "2", String.valueOf(r1));

        int r2 = Ariketak.biAgerraldienArtekoDistantzia(new int[]{1, 5, 3}, 5);
        test("Agerraldi bakarra {1, 5, 3} (target 5)", r2 == -1, "-1", String.valueOf(r2));

        int r3 = Ariketak.biAgerraldienArtekoDistantzia(new int[]{3, 3}, 3);
        test("Jarraian daudenak {3, 3} (target 3)", r3 == 1, "1", String.valueOf(r3));

        int r4 = Ariketak.biAgerraldienArtekoDistantzia(null, 7);
        test("Null denean", r4 == -1, "-1", String.valueOf(r4));
    }
}