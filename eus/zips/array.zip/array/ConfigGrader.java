package array;

public class ConfigGrader {

    // true  -> Ejecuta todas las pruebas (1 a 20)
    // false -> Ejecuta solo el ejercicio indicado en EXERCISE_NUMBER
    public static final boolean RUN_ALL = true;

    // Número del ejercicio a probar cuando RUN_ALL = false (del 1 al 20)
    //  1: batuElementuak                  11: elementuaDago
    //  2: batezBestekoaKalkulatu          12: zenbatuBikoitiak
    //  3: handienaAurkitu                 13: alderantzizkoArraya
    //  4: gutxienekoaAurkitu              14: gehituElementua
    //  5: zenbatuNegatiboak               15: kenduIndizekoElementua
    //  6: zenbatuPositiboak               16: lehenNegatiboarenIndizea
    //  7: kenduElementuak                 17: batuMugaraArte
    //  8: batuIndizeBikoitiak             18: ordenatutaDago
    //  9: bihurtuNegatiboIndizeBakoitiak  19: palindromoaDa
    // 10: lortuTamaina                    20: biAgerraldienArtekoDistantzia
    public static final int EXERCISE_NUMBER = 1;
}