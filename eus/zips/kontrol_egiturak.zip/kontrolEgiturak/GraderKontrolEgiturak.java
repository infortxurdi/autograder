package kontrolEgiturak;

public class GraderKontrolEgiturak {

    // ANSI kolore-kodeak kontsolan bistaratzeko
    private static final String RESET = "\u001B[0m";
    private static final String RED = "\u001B[31m";
    private static final String GREEN = "\u001B[32m";
    private static final String YELLOW = "\u001B[33m";
    private static final String CYAN = "\u001B[36m";
    private static final String BOLD = "\u001B[1m";

    private static int totalTests = 0;
    private static int passedTests = 0;

    public static void main(String[] args) {
        System.out.println(CYAN + "==================================================");
        System.out.println("   GRADER KONTROL EGITURAK EBALUATZAILE AUTOMATIKOA         ");
        System.out.println("==================================================" + RESET + "\n");

        // A Blokeko ebaluazioak (IF / ELSE)
        if (shouldRun(1)) testBikoitiaDaString();
        if (shouldRun(2)) testBikoitiaDaBoolean();
        if (shouldRun(3)) testZeinuZehaztu();
        if (shouldRun(4)) testNotaSailkatu();
        if (shouldRun(5)) testHandienaZehaztu();
        if (shouldRun(6)) testAdinKategoriaSailkatu();
        if (shouldRun(7)) testDeskontuaKalkulatu();
        if (shouldRun(8)) testUrteaBisestuaDa();

        // B Blokeko ebaluazioak (SWITCH / CASE)
        if (shouldRun(9)) testEgunIzenaLortu();
        if (shouldRun(10)) testAsteburuaDa();
        if (shouldRun(11)) testEragiketaEgin();
        if (shouldRun(12)) testUrtaroaLortu();
        if (shouldRun(13)) testHilabetekoEgunak();

        // Azken laburpena
        double porcentaje = totalTests > 0 ? ((double) passedTests / totalTests) * 100 : 0.0;

        System.out.println("\n" + CYAN + "==================================================" + RESET);
        System.out.printf(BOLD + " AZKEN EMAITZA: %d / %d proba gaindituta (%%%.1f)\n" + RESET,
                passedTests, totalTests, porcentaje);

        System.out.println(CYAN + "==================================================" + RESET);

        if (totalTests > 0 && passedTests == totalTests) {
            System.out.println(GREEN + "🎉 Lan bikaina! Metodo guztiek egoki funtzionatzen dute." + RESET);
        } else if (totalTests > 0) {
            System.out.println(YELLOW + "⚠️ Berrikusi [ERROREA] gisa markatutako ariketak eta saiatu berriro." + RESET);
        } else {
            System.out.println(YELLOW + "⚠️ Ez da probarik exekutatu. Konfigurazioa berrikusi." + RESET);
        }
    }

    private static boolean shouldRun(int exerciseNumber) {
        return ConfigGrader.RUN_ALL || ConfigGrader.EXERCISE_NUMBER == exerciseNumber;
    }

    private static void test(String probarenIzena, boolean resultado, String esperado, String obtenido) {
        totalTests++;
        if (resultado) {
            passedTests++;
            System.out.printf("  " + GREEN + "[OK]" + RESET + " %s\n", probarenIzena);
        } else {
            System.out.printf("  " + RED + "[ERROREA]" + RESET + " %s | Esperotakoa: '%s' -> Lortutakoa: '%s'\n", probarenIzena, esperado, obtenido);
        }
    }

    // --- 1. TESTA: bikoitiaDaString ---
    private static void testBikoitiaDaString() {
        System.out.println(BOLD + "--- 1. ariketa: bikoitiaDaString ---" + RESET);
        String r1 = Ariketak.bikoitiaDaString(4);
        test("Paritatea (4)", "Bikoitia".equalsIgnoreCase(r1), "Bikoitia", r1);

        String r2 = Ariketak.bikoitiaDaString(7);
        test("Paritatea (7)", "Bakoitia".equalsIgnoreCase(r2), "Bakoitia", r2);

        String r3 = Ariketak.bikoitiaDaString(0);
        test("Paritatea (0)", "Bikoitia".equalsIgnoreCase(r3), "Bikoitia", r3);
    }

    // --- 2. TESTA: bikoitiaDa ---
    private static void testBikoitiaDaBoolean() {
        System.out.println("\n" + BOLD + "--- 2. ariketa: bikoitiaDa ---" + RESET);
        boolean r1 = Ariketak.bikoitiaDaBoolean(4);
        test("Bikoitia (4)", r1 == true, "true", String.valueOf(r1));

        boolean r2 = Ariketak.bikoitiaDaBoolean(7);
        test("Bikoitia (7)", r2 == false, "false", String.valueOf(r2));

        boolean r3 = Ariketak.bikoitiaDaBoolean(0);
        test("Bikoitia (0)", r3 == true, "true", String.valueOf(r3));
    }

    // --- 3. TESTA: zeinuZehaztu ---
    private static void testZeinuZehaztu() {
        System.out.println("\n" + BOLD + "--- 3. ariketa: zeinuZehaztu ---" + RESET);
        String r1 = Ariketak.zeinuZehaztu(15);
        test("Zeinua (15)", "Positiboa".equalsIgnoreCase(r1), "Positiboa", r1);

        String r2 = Ariketak.zeinuZehaztu(-8);
        test("Zeinua (-8)", "Negatiboa".equalsIgnoreCase(r2), "Negatiboa", r2);

        String r3 = Ariketak.zeinuZehaztu(0);
        test("Zeinua (0)", "Zero".equalsIgnoreCase(r3), "Zero", r3);
    }

    // --- 4. TESTA: notaSailkatu ---
    private static void testNotaSailkatu() {
        System.out.println("\n" + BOLD + "--- 4. ariketa: notaSailkatu ---" + RESET);
        String r1 = Ariketak.notaSailkatu(9.5);
        test("Nota 9.5", "Bikaina".equalsIgnoreCase(r1), "Bikaina", r1);

        String r2 = Ariketak.notaSailkatu(7.5);
        test("Nota 7.5", "Oso ongi".equalsIgnoreCase(r2), "Oso ongi", r2);

        String r3 = Ariketak.notaSailkatu(5.0);
        test("Nota 5.0", "Nahikoa".equalsIgnoreCase(r3), "Nahikoa", r3);

        String r4 = Ariketak.notaSailkatu(3.2);
        test("Nota 3.2", "Gutxi".equalsIgnoreCase(r4), "Gutxi", r4);

        String r5 = Ariketak.notaSailkatu(-1.0);
        test("Nota ez-baliozkoa (-1.0)", "Nota ez-baliozkoa".equalsIgnoreCase(r5), "Nota ez-baliozkoa", r5);
    }

    // --- 5. TESTA: handienaZehaztu ---
    private static void testHandienaZehaztu() {
        System.out.println("\n" + BOLD + "--- 5. ariketa: handienaZehaztu ---" + RESET);
        int r1 = Ariketak.handienaZehaztu(10, 5);
        test("Handiena (10, 5)", r1 == 10, "10", String.valueOf(r1));

        int r2 = Ariketak.handienaZehaztu(-3, 7);
        test("Handiena (-3, 7)", r2 == 7, "7", String.valueOf(r2));

        int r3 = Ariketak.handienaZehaztu(4, 4);
        test("Handiena (4, 4)", r3 == 4, "4", String.valueOf(r3));
    }

    // --- 6. TESTA: adinKategoriaSailkatu ---
    private static void testAdinKategoriaSailkatu() {
        System.out.println("\n" + BOLD + "--- 6. ariketa: adinKategoriaSailkatu ---" + RESET);
        String r1 = Ariketak.adinKategoriaSailkatu(12);
        test("Adina 12", "Adingabea".equalsIgnoreCase(r1), "Adingabea", r1);

        String r2 = Ariketak.adinKategoriaSailkatu(25);
        test("Adina 25", "Heldua".equalsIgnoreCase(r2), "Heldua", r2);

        String r3 = Ariketak.adinKategoriaSailkatu(70);
        test("Adina 70", "Adinekoa".equalsIgnoreCase(r3), "Adinekoa", r3);

        String r4 = Ariketak.adinKategoriaSailkatu(-5);
        test("Adin ez-baliozkoa (-5)", "Adin ez-baliozkoa".equalsIgnoreCase(r4), "Adin ez-baliozkoa", r4);
    }

    // --- 7. TESTA: deskontuaKalkulatu ---
    private static void testDeskontuaKalkulatu() {
        System.out.println("\n" + BOLD + "--- 7. ariketa: deskontuaKalkulatu ---" + RESET);
        double r1 = Ariketak.deskontuaKalkulatu(100.0, false, 15);
        test("Deskontua adingabea", Math.abs(r1 - 80.0) < 0.001, "80.0", String.valueOf(r1));

        double r2 = Ariketak.deskontuaKalkulatu(100.0, true, 30);
        test("Deskontua heldu bazkidea", Math.abs(r2 - 90.0) < 0.001, "90.0", String.valueOf(r2));

        double r3 = Ariketak.deskontuaKalkulatu(100.0, false, 30);
        test("Deskonturik gabe (heldu ez-bazkidea)", Math.abs(r3 - 100.0) < 0.001, "100.0", String.valueOf(r3));
    }

    // --- 8. TESTA: urteaBisestuaDa ---
    private static void testUrteaBisestuaDa() {
        System.out.println("\n" + BOLD + "--- 8. ariketa: urteaBisestuaDa ---" + RESET);
        boolean r1 = Ariketak.urteaBisestuaDa(2024);
        test("Urtea 2024 (Bisestua)", r1 == true, "true", String.valueOf(r1));

        boolean r2 = Ariketak.urteaBisestuaDa(1900);
        test("Urtea 1900 (Ez bisestua)", r2 == false, "false", String.valueOf(r2));

        boolean r3 = Ariketak.urteaBisestuaDa(2000);
        test("Urtea 2000 (Bisestua)", r3 == true, "true", String.valueOf(r3));

        boolean r4 = Ariketak.urteaBisestuaDa(2023);
        test("Urtea 2023 (Ez bisestua)", r4 == false, "false", String.valueOf(r4));
    }

    // --- 9. TESTA: egunIzenaLortu ---
    private static void testEgunIzenaLortu() {
        System.out.println("\n" + BOLD + "--- 9. ariketa: egunIzenaLortu ---" + RESET);
        String r1 = Ariketak.egunIzenaLortu(1);
        test("1. eguna", "Astelehena".equalsIgnoreCase(r1), "Astelehena", r1);

        String r2 = Ariketak.egunIzenaLortu(5);
        test("5. eguna", "Ostirala".equalsIgnoreCase(r2), "Ostirala", r2);

        String r3 = Ariketak.egunIzenaLortu(9);
        test("Eremuz kanpoko eguna (9)", "Egun ez-baliozkoa".equalsIgnoreCase(r3), "Egun ez-baliozkoa", r3);
    }

    // --- 10. TESTA: asteburuaDa ---
    private static void testAsteburuaDa() {
        System.out.println("\n" + BOLD + "--- 10. ariketa: asteburuaDa ---" + RESET);
        String r1 = Ariketak.asteburuaDa(3);
        test("3. eguna (Asteazkena)", "Laneguna".equalsIgnoreCase(r1), "Laneguna", r1);

        String r2 = Ariketak.asteburuaDa(6);
        test("6. eguna (Larunbata)", "Asteburua".equalsIgnoreCase(r2), "Asteburua", r2);

        String r3 = Ariketak.asteburuaDa(0);
        test("Egun ez-baliozkoa (0)", "Egun ez-baliozkoa".equalsIgnoreCase(r3), "Egun ez-baliozkoa", r3);
    }

    // --- 11. TESTA: eragiketaEgin ---
    private static void testEragiketaEgin() {
        System.out.println("\n" + BOLD + "--- 11. ariketa: eragiketaEgin ---" + RESET);
        int r1 = Ariketak.eragiketaEgin(10, 5, '+');
        test("Batura (10 + 5)", r1 == 15, "15", String.valueOf(r1));

        int r2 = Ariketak.eragiketaEgin(10, 5, '-');
        test("Kenketa (10 - 5)", r2 == 5, "5", String.valueOf(r2));

        int r3 = Ariketak.eragiketaEgin(10, 5, '*');
        test("Biderketa (10 * 5)", r3 == 50, "50", String.valueOf(r3));

        int r4 = Ariketak.eragiketaEgin(10, 2, '/');
        test("Zatiketa (10 / 2)", r4 == 5, "5", String.valueOf(r4));

        int r5 = Ariketak.eragiketaEgin(10, 0, '/');
        test("Zero bidezko zatiketa (10 / 0)", r5 == 0, "0", String.valueOf(r5));
    }

    // --- 12. TESTA: urtaroaLortu ---
    private static void testUrtaroaLortu() {
        System.out.println("\n" + BOLD + "--- 12. ariketa: urtaroaLortu ---" + RESET);
        String r1 = Ariketak.urtaroaLortu(1);
        test("1. hilabetea (Urtarrila)", "Negua".equalsIgnoreCase(r1), "Negua", r1);

        String r2 = Ariketak.urtaroaLortu(4);
        test("4. hilabetea (Apirila)", "Udaberria".equalsIgnoreCase(r2), "Udaberria", r2);

        String r3 = Ariketak.urtaroaLortu(7);
        test("7. hilabetea (Uztaila)", "Uda".equalsIgnoreCase(r3), "Uda", r3);

        String r4 = Ariketak.urtaroaLortu(10);
        test("10. hilabetea (Urria)", "Udazkena".equalsIgnoreCase(r4), "Udazkena", r4);

        String r5 = Ariketak.urtaroaLortu(13);
        test("Hilabete ez-baliozkoa (13)", "Hilabete ez-baliozkoa".equalsIgnoreCase(r5), "Hilabete ez-baliozkoa", r5);
    }

    // --- 13. TESTA: hilabetekoEgunak ---
    private static void testHilabetekoEgunak() {
        System.out.println("\n" + BOLD + "--- 13. ariketa: hilabetekoEgunak ---" + RESET);
        int r1 = Ariketak.hilabetekoEgunak(1);
        test("1. hilabetea (31 egun)", r1 == 31, "31", String.valueOf(r1));

        int r2 = Ariketak.hilabetekoEgunak(2);
        test("2. hilabetea (28 egun)", r2 == 28, "28", String.valueOf(r2));

        int r3 = Ariketak.hilabetekoEgunak(4);
        test("4. hilabetea (30 egun)", r3 == 30, "30", String.valueOf(r3));

        int r4 = Ariketak.hilabetekoEgunak(15);
        test("Hilabete ez-baliozkoa (15)", r4 == -1, "-1", String.valueOf(r4));
    }
}