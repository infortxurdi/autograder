package kontrolEgiturak;

public class ConfigGrader {

    // true  -> Ejecuta todas las pruebas
    // false -> Ejecuta solo el ejercicio indicado en EXERCISE_NUMBER
    public static final boolean RUN_ALL = false;

    // Número del ejercicio a probar cuando RUN_ALL = false (del 1 al 13)
    // 1: paritateaZehaztu         8: urteaBisestuaDa
    // 2: bikoitiaDa               9: egunIzenaLortu
    // 3: zeinuZehaztu            10: asteburuaDa
    // 4: notaSailkatu            11: eragiketaEgin
    // 5: handienaZehaztu         12: urtaroaLortu
    // 6: adinKategoriaSailkatu   13: hilabetekoEgunak
    // 7: deskontuaKalkulatu
    public static final int EXERCISE_NUMBER = 1;
}