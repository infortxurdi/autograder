package kontrolEgiturak;

public class Ariketak {

    // =============================================================
    // A BLOKEA: IF / ELSE
    // =============================================================

    /**
     * 1. ariketa: bikoitiaDaString
     *
     * Zenbaki bat bikoitia ala bakoitia den zehazten du testu bidez.
     *
     * @param zenbakia aztertu nahi den zenbaki osoa.
     * @return Emaitza posibleak:
     *         - "Bikoitia" (zenbakia bikoitia denean)
     *         - "Bakoitia" (zenbakia bakoitia denean)
     */
    public static String bikoitiaDaString(int zenbakia) {
        // TODO: Logika inplementatu if / else erabiliz
        return "";
    }

    /**
     * 2. ariketa: bikoitiaDaBoolean
     *
     * Zenbaki bat bikoitia den ala ez egiaztatzen du balio boolear bidez.
     *
     * @param zenbakia aztertu nahi den zenbaki osoa.
     * @return Emaitza posibleak:
     *         - true (zenbakia bikoitia bada)
     *         - false (zenbakia bakoitia bada)
     */
    public static boolean bikoitiaDaBoolean(int zenbakia) {
        // TODO: Logika inplementatu if / else erabiliz
        return false;
    }

    /**
     * 3. ariketa: zeinuZehaztu
     *
     * Zenbaki bat positiboa, negatiboa edo zero den zehazten du.
     *
     * @param zenbakia aztertu nahi den zenbaki osoa.
     * @return Emaitza posibleak:
     *         - "Positiboa" (zenbakia > 0 denean)
     *         - "Negatiboa" (zenbakia < 0 denean)
     *         - "Zero" (zenbakia == 0 denean)
     */
    public static String zeinuZehaztu(int zenbakia) {
        // TODO: Logika inplementatu if / else / else if erabiliz
        return "";
    }

    /**
     * 4. ariketa: notaSailkatu
     *
     * Zenbakizko nota baten araberako kalifikazio-testua bueltatzen du.
     *
     * @param nota ikaslearen nota (double motakoa).
     * @return Emaitza posibleak:
     *         - "Bikaina" (nota >= 9.0 denean)
     *         - "Oso ongi" (nota >= 7.0 eta < 9.0 denean)
     *         - "Nahikoa" (nota >= 5.0 eta < 7.0 denean)
     *         - "Gutxi" (nota >= 0.0 eta < 5.0 denean)
     *         - "Nota ez-baliozkoa" (nota < 0.0 edo nota > 10.0 denean)
     */
    public static String notaSailkatu(double nota) {
        // TODO: Logika inplementatu if / else / else if erabiliz
        return "";
    }

    /**
     * 5. ariketa: handienaZehaztu
     *
     * Bi zenbakiren artean handiena zein den bueltatzen du.
     *
     * @param a lehenengo zenbaki osoa.
     * @param b bigarren zenbaki osoa.
     * @return Bi zenbakietatik handiena dena (berdinak badira, edozein).
     */
    public static int handienaZehaztu(int a, int b) {
        // TODO: Logika inplementatu if / else erabiliz
        return 0;
    }

    /**
     * 6. ariketa: adinKategoriaSailkatu
     *
     * Adinaren arabera pertsona baten kategoria zehazten du.
     *
     * @param adina pertsonaren adina urteetan.
     * @return Emaitza posibleak:
     *         - "Adingabea" (adina < 18 denean)
     *         - "Heldua" (adina >= 18 eta < 65 denean)
     *         - "Adinekoa" (adina >= 65 denean)
     *         - "Adin ez-baliozkoa" (adina < 0 denean)
     */
    public static String adinKategoriaSailkatu(int adina) {
        // TODO: Logika inplementatu if / else / else if erabiliz
        return "";
    }

    /**
     * 7. ariketa: deskontuaKalkulatu
     *
     * Deskontua aplikatuz azken prezioa kalkulatzen du.
     * Adingabekoek (%20) eta bazkide helduek (%10) deskontua dute.
     *
     * @param prezioa jatorrizko prezioa.
     * @param bazkideaDa pertsona bazkidea den edo ez.
     * @param adina pertsonaren adina urteetan.
     * @return Emaitza posibleak:
     *         - Prezio berria deskontua aplikatu ondoren (double motakoa).
     */
    public static double deskontuaKalkulatu(double prezioa, boolean bazkideaDa, int adina) {
        // TODO: Deskontuen logika inplementatu if / else konbinatuz
        return 0.0;
    }

    /**
     * 8. ariketa: urteaBisestuaDa
     *
     * Urte bat bisestua den ala ez egiaztatzen du.
     * (Urte bat bisestua da 4rekin zatigarria bada eta ez 100ekin, edo 400ekin zatigarria bada).
     *
     * @param urtea aztertu nahi den urtea.
     * @return Emaitza posibleak:
     *         - true (urtea bisestua bada)
     *         - false (urtea ez bada bisestua)
     */
    public static boolean urteaBisestuaDa(int urtea) {
        // TODO: Logika inplementatu if / else erabiliz
        return false;
    }

    // =============================================================
    // B BLOKEA: SWITCH / CASE
    // =============================================================

    /**
     * 9. ariketa: egunIzenaLortu
     *
     * Astearen egunaren zenbakia jasota (1etik 7ra), testuzko izena bueltatzen du.
     *
     * @param eguna egunaren zenbakia (1-7).
     * @return Emaitza posibleak:
     *         - "Astelehena" (1 denean)
     *         - "Asteartea" (2 denean)
     *         - "Asteazkena" (3 denean)
     *         - "Osteguna" (4 denean)
     *         - "Ostirala" (5 denean)
     *         - "Larunbata" (6 denean)
     *         - "Igandea" (7 denean)
     *         - "Egun ez-baliozkoa" (gainerako zenbakietarako)
     */
    public static String egunIzenaLortu(int eguna) {
        // TODO: Inplementatu switch / case erabiliz
        return "";
    }

    /**
     * 10. ariketa: asteburuaDa
     *
     * Egun zenbaki baten arabera laneguna ala asteburua den zehazten du.
     *
     * @param eguna egunaren zenbakia (1-7).
     * @return Emaitza posibleak:
     *         - "Laneguna" (1etik 5era denean)
     *         - "Asteburua" (6 edo 7 denean)
     *         - "Egun ez-baliozkoa" (gainerako zenbakietarako)
     */
    public static String asteburuaDa(int eguna) {
        // TODO: Inplementatu switch / case erabiliz
        return "";
    }

    /**
     * 11. ariketa: eragiketaEgin
     *
     * Bi zenbakiren arteko eragiketa matematikoa egiten du eragilearen arabera.
     *
     * @param a lehen zenbakia.
     * @param b bigarren zenbakia.
     * @param eragilea eragiketa ikurra ('+', '-', '*', '/').
     * @return Eragiketaren emaitza osoa (edo 0 zero bidez zatitzean edo eragilea okerra denean).
     */
    public static int eragiketaEgin(int a, int b, char eragilea) {
        // TODO: Inplementatu switch / case erabiliz
        return 0;
    }

    /**
     * 12. ariketa: urtaroaLortu
     *
     * Hilabetearen zenbakiaren arabera (1-12) dagokion urtaroa bueltatzen du.
     *
     * @param hilabetea hilabetearen zenbakia (1-12).
     * @return Emaitza posibleak:
     *         - "Negua" (12, 1, 2 denean)
     *         - "Udaberria" (3, 4, 5 denean)
     *         - "Uda" (6, 7, 8 denean)
     *         - "Udazkena" (9, 10, 11 denean)
     *         - "Hilabete ez-baliozkoa" (gainerako zenbakietarako)
     */
    public static String urtaroaLortu(int hilabetea) {
        // TODO: Inplementatu switch / case erabiliz taldekatutako kasuekin
        return "";
    }

    /**
     * 13. ariketa: hilabetekoEgunak
     *
     * Hilabete baten egun kopurua bueltatzen du (urtea bisestua ez dela suposatuz).
     *
     * @param hilabetea hilabetearen zenbakia (1-12).
     * @return Emaitza posibleak:
     *         - 31 (1, 3, 5, 7, 8, 10, 12 hilabeteetan)
     *         - 30 (4, 6, 9, 11 hilabeteetan)
     *         - 28 (2 hilabetean)
     *         - -1 (hilabetea 1-12 tartean ez badago)
     */
    public static int hilabetekoEgunak(int hilabetea) {
        // TODO: Inplementatu switch / case erabiliz taldekatutako kasuekin
        return -1;
    }
}