package poo;

import java.util.ArrayList;
import java.util.List;

public class Ariketak {

    // =============================================================
    // KLASE LAGUNTZAILEAK (AUXILIARY DOMAIN CLASSES)
    // =============================================================

    public static class Taxi {
        private String probintzia = "Bizkaia";
        private String matrikula;
        private String udalerria;
        private int motoreMota; // 0 = ezezaguna, 1 = diesela, 2 = gasolina

        public Taxi() {}

        public Taxi(String matrikula, String udalerria, int motoreMota) {
            this.matrikula = matrikula;
            this.udalerria = udalerria;
            this.motoreMota = motoreMota;
        }

        public String getProbintzia() { return probintzia; }
        public String getMatrikula() { return matrikula; }
        public void setMatrikula(String matrikula) { this.matrikula = matrikula; }
        public String getUdalerria() { return udalerria; }
        public void setUdalerria(String udalerria) { this.udalerria = udalerria; }
        public int getMotoreMota() { return motoreMota; }
        public void setMotoreMota(int motoreMota) { this.motoreMota = motoreMota; }
    }

    public static class Kotxea {
        private int abiadura;

        public Kotxea() { this.abiadura = 0; }
        public Kotxea(int abiadura) { this.abiadura = Math.max(0, abiadura); }

        public int getAbiadura() { return abiadura; }
        public void bizkortu(int gehiago) { if (gehiago > 0) this.abiadura += gehiago; }
        public void geldotu(int gutxiago) { if (gutxiago > 0) this.abiadura = Math.max(0, this.abiadura - gutxiago); }
    }

    public static class Pertsona {
        private String izena;
        private String abizenak;
        private int adina;

        public Pertsona(String izena, String abizenak, int adina) {
            this.izena = izena;
            this.abizenak = abizenak;
            this.adina = adina;
        }

        public String getIzena() { return izena; }
        public String getAbizenak() { return abizenak; }
        public int getAdina() { return adina; }
        public String getIzenOsoa() { return izena + " " + abizenak; }
    }

    public static class Email {
        private String norentzat;
        private String asuntua;
        private String gorputza;

        public Email(String norentzat, String asuntua, String gorputza) {
            this.norentzat = norentzat;
            this.asuntua = asuntua;
            this.gorputza = gorputza;
        }

        public String getNorentzat() { return norentzat; }
        public String getAsuntua() { return asuntua; }
        public String getGorputza() { return gorputza; }
    }

    public static class Postontzia {
        private List<Email> emaillak = new ArrayList<>();

        public void gehitu(Email e) { if (e != null) emaillak.add(e); }
        public int emailKopurua() { return emaillak.size(); }
    }

    public static class Ikasgela {
        private List<Pertsona> ikasleak = new ArrayList<>();

        public void gehituIkaslea(Pertsona p) { if (p != null) ikasleak.add(p); }
        public int ikasleKopurua() { return ikasleak.size(); }
    }

    // =============================================================
    // 0. ARIKETA: ADIBIDEA (RESUELTO)
    // =============================================================

    /**
     * 0. ariketa: taxiAdibidea
     *
     * ADIBIDE RESUELTO: Taxi objektu bat sortzen du, parametroak ezartzen dizkio getter/setter bidez
     * eta deskribapen testua bueltatzen du.
     *
     * @param matrikula autoaren matrikula.
     * @param udalerria taxiak lan egiten duen udalerria.
     * @return Testua formatu honekin: "Taxi [Matrikula: {matrikula}, Udalerria: {udalerria}]"
     */
    public static String taxiAdibidea(String matrikula, String udalerria) {
        // 1. Objektua instanziatu
        Taxi t = new Taxi();

        // 2. Parametro bidez jasotako datuak ezarri setter-ak erabiliz
        t.setMatrikula(matrikula);
        t.setUdalerria(udalerria);

        // 3. Emaitza eraiki eta bueltatu getter-ak erabiliz
        return "Taxi [Matrikula: " + t.getMatrikula() + ", Udalerria: " + t.getUdalerria() + "]";
    }

    // =============================================================
    // A BLOKEA: KLASE OINARRIZKOAK ETA ATRIBUTUAK
    // =============================================================

    /**
     * 1. ariketa: taxiSortuEtaKonfiguratu
     *
     * Taxi objektu bat sortu eta emandako datuekin konfiguratzen du.
     * Bueltatutako kateak formatu hau izan behar du:
     * "Taxi [Matrikula: {matrikula}, Udalerria: {udalerria}, Motorra: {motoreMota}, Probintzia: Bizkaia]"
     *
     * @param matrikula autoaren matrikula.
     * @param udalerria taxiak lan egiten duen udalerria.
     * @param motoreMota motor mota (0 = ezezaguna, 1 = diesela, 2 = gasolina).
     * @return Formateatutako testua taxi aldagai guztiekin.
     */
    public static String taxiSortuEtaKonfiguratu(String matrikula, String udalerria, int motoreMota) {
        // TODO: Logika inplementatu Taxi objektua sortuz eta atributuak ezarriz
        return "";
    }

    /**
     * 2. ariketa: kotxeaBizkortuEtaGeldotu
     *
     * Hasierako abiadura duen Kotxea sortu eta aldaketa aplikatzen dio.
     * aldaketa > 0 bada, bizkortu(aldaketa) egiten du.
     * aldaketa < 0 bada, geldotu(-aldaketa) egiten du.
     * Abiadura ezin da inoiz 0 baino txikiagoa izan.
     *
     * @param hasierakoAbiadura kotxearen abiadura hasieran.
     * @param aldaketa gehituko edo gutxituko den abiadura kopurua.
     * @return Eguneratutako abiadura osoa.
     */
    public static int kotxeaBizkortuEtaGeldotu(int hasierakoAbiadura, int aldaketa) {
        // TODO: Logika inplementatu Kotxea objektua erabiliz
        return 0;
    }

    /**
     * 3. ariketa: celsiusToFahrenheit
     *
     * Celsius gradutan dagoen tenperatura Fahrenheit gradutara bihurtzen du.
     * Formula: (celsius * 9.0 / 5.0) + 32.0
     *
     * @param celsius tenperatura Celsius gradutan.
     * @return Tenperatura Fahrenheit gradutan.
     */
    public static double celsiusToFahrenheit(double celsius) {
        // TODO: Inplementatu bihurketa formula
        return 0.0;
    }

    /**
     * 4. ariketa: fahrenheitToCelsius
     *
     * Fahrenheit gradutan dagoen tenperatura Celsius gradutara bihurtzen du.
     * Formula: (fahrenheit - 32.0) * 5.0 / 9.0
     *
     * @param fahrenheit tenperatura Fahrenheit gradutan.
     * @return Tenperatura Celsius gradutan.
     */
    public static double fahrenheitToCelsius(double fahrenheit) {
        // TODO: Inplementatu bihurketa formula
        return 0.0;
    }

    // =============================================================
    // B BLOKEA: PERTSONA KLASEA (IMC ETA ADINA)
    // =============================================================

    /**
     * 5. ariketa: pertsonaZaharrena
     *
     * Bi pertsona jasotzen ditu eta zaharrena denaren izen-abizen osoa bueltatzen du.
     * Bi pertsonek adin bera badute, lehenengoaren izen-abizenak bueltatu.
     *
     * @param p1 lehenengo Pertsona objektua.
     * @param p2 bigarren Pertsona objektua.
     * @return Pertsona zaharrenaren izen osoa ("Izena Abizenak").
     */
    public static String pertsonaZaharrena(Pertsona p1, Pertsona p2) {
        // TODO: Konparatu bi pertsonen adinak eta bueltatu zaharrenaren izen osoa
        return "";
    }

    /**
     * 6. ariketa: kalkulatuIMC
     *
     * Gorputz Masaren Indizea (GMI/IMC) kalkulatzen du: pisua (kg) / altuera^2 (m).
     *
     * @param pisua pertsonaren pisua kg-tan.
     * @param altuera pertsonaren altuera metrotan.
     * @return Emaitza posibleak:
     *         - -1 (IMC < 20.0 denean -> pisu idealaren azpitik)
     *         -  0 (20.0 <= IMC <= 25.0 denean -> pisu idealean)
     *         -  1 (IMC > 25.0 denean -> gehiegizko pisua)
     */
    public static int kalkulatuIMC(double pisua, double altuera) {
        // TODO: Inplementatu IMC kalkulua eta balioztatzea
        return 0;
    }

    /**
     * 7. ariketa: adinezNagusikoaDa
     *
     * Pertsona baten adina jasota, adin nagusikoa den ala ez zehazten du.
     *
     * @param adina pertsonaren adina urteetan.
     * @return true adina >= 18 bada; false bestela.
     */
    public static boolean adinezNagusikoaDa(int adina) {
        // TODO: Inplementatu adin nagusitasunaren kontrola
        return false;
    }

    // =============================================================
    // C BLOKEA: KLASEEN ARTEKO INTERAKZIOAK
    // =============================================================

    /**
     * 8. ariketa: emailSortuEtaBistaratu
     *
     * Email baten atributuak jasota, deskribapen testu bat bueltatzen du:
     * "Norentzat: {norentzat} | Asuntua: {asuntua} | Gorputza: {gorputza}"
     *
     * @param norentzat emailaren jasotzailea.
     * @param asuntua emailaren gai nagusia.
     * @param gorputza emailaren testu edukia.
     * @return Emailaren datu guztiak testu formatuan.
     */
    public static String emailSortuEtaBistaratu(String norentzat, String asuntua, String gorputza) {
        // TODO: Sortu email objektua eta bueltatu testu formatua
        return "";
    }

    /**
     * 9. ariketa: postontziaKudeatu
     *
     * Email bat Postontzi batera gehitzen du eta postontziak dituen email kopurua bueltatzen du.
     *
     * @param postontzia helburuko Postontzia objektua.
     * @param email gehitu nahi den Email objektua.
     * @return Postontzian dauden email guztiak gehitu ondoren.
     */
    public static int postontziaKudeatu(Postontzia postontzia, Email email) {
        // TODO: Gehitu emaila postontzira eta bueltatu kopurua
        return 0;
    }

    /**
     * 10. ariketa: ikasgelakoIkasleakZenbatu
     *
     * Pertsona (ikasle) bat Ikasgela batera gehitzen du eta ikasgelako ikasle kopurua bueltatzen du.
     *
     * @param ikasgela Ikasgela objektua.
     * @param ikaslea gehitu nahi den Pertsona ikaslea.
     * @return Ikasgelan dauden ikasle guztiak gehitu ondoren.
     */
    public static int ikasgelakoIkasleakZenbatu(Ikasgela ikasgela, Pertsona ikaslea) {
        // TODO: Gehitu ikaslea ikasgelara eta bueltatu ikasle kopurua
        return 0;
    }
}