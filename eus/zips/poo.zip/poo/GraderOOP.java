package poo;

public class GraderOOP {

    // ANSI kolore-kodeak kontsolan bistaratzeko
    private static final String RESET = "\u001B[0m";
    private static final String RED = "\u001B[31m";
    private static final String GREEN = "\u001B[32m";
    private static final String YELLOW = "\u001B[33m";
    private static final String CYAN = "\u001B[36m";
    private static final String BOLD = "\u001B[1m";

    private static int totalTests = 0;
    private static int passedTests = 0;

    public static void main(String[] args) {
        System.out.println(CYAN + "==================================================");
        System.out.println("   GRADER POO KLASEAK EBALUATZAILE AUTOMATIKOA     ");
        System.out.println("==================================================" + RESET + "\n");

        // 0. Ariketa (Adibidea)
        if (shouldRun(0)) testTaxiAdibidea();

        // A Blokeko ebaluazioak (Klase Oinarrizkoak eta Atributuak)
        if (shouldRun(1)) testTaxiSortuEtaKonfiguratu();
        if (shouldRun(2)) testKotxeaBizkortuEtaGeldotu();
        if (shouldRun(3)) testCelsiusToFahrenheit();
        if (shouldRun(4)) testFahrenheitToCelsius();

        // B Blokeko ebaluazioak (Pertsona, IMC eta Adina)
        if (shouldRun(5)) testPertsonaZaharrena();
        if (shouldRun(6)) testKalkulatuIMC();
        if (shouldRun(7)) testAdinezNagusikoaDa();

        // C Blokeko ebaluazioak (Interakzioak)
        if (shouldRun(8)) testEmailSortuEtaBistaratu();
        if (shouldRun(9)) testPostontziaKudeatu();
        if (shouldRun(10)) testIkasgelakoIkasleakZenbatu();

        // Azken laburpena
        double porcentaje = totalTests > 0 ? ((double) passedTests / totalTests) * 100 : 0.0;

        System.out.println("\n" + CYAN + "==================================================" + RESET);
        System.out.printf(BOLD + " AZKEN EMAITZA: %d / %d proba gaindituta (%%%.1f)\n" + RESET,
                passedTests, totalTests, porcentaje);

        System.out.println(CYAN + "==================================================" + RESET);

        if (totalTests > 0 && passedTests == totalTests) {
            System.out.println(GREEN + "🎉 Lan bikaina! Metodo guztiek egoki funtzionatzen dute." + RESET);
        } else if (totalTests > 0) {
            System.out.println(YELLOW + "⚠️ Berrikusi [ERROREA] gisa markatutako ariketak eta saiatu berriro." + RESET);
        } else {
            System.out.println(YELLOW + "⚠️ Ez da probarik exekutatu. Konfigurazioa berrikusi." + RESET);
        }
    }

    private static boolean shouldRun(int exerciseNumber) {
        return ConfigGrader.RUN_ALL || ConfigGrader.EXERCISE_NUMBER == exerciseNumber;
    }

    private static void test(String probarenIzena, boolean resultado, String esperado, String obtenido) {
        totalTests++;
        if (resultado) {
            passedTests++;
            System.out.printf("  " + GREEN + "[OK]" + RESET + " %s\n", probarenIzena);
        } else {
            System.out.printf("  " + RED + "[ERROREA]" + RESET + " %s | Esperotakoa: '%s' -> Lortutakoa: '%s'\n", probarenIzena, esperado, obtenido);
        }
    }

    // --- 0. TESTA: taxiAdibidea ---
    private static void testTaxiAdibidea() {
        System.out.println(BOLD + "--- 0. ariketa: taxiAdibidea (Adibidea) ---" + RESET);
        String r1 = Ariketak.taxiAdibidea("0000AAA", "Bilbo");
        String e1 = "Taxi [Matrikula: 0000AAA, Udalerria: Bilbo]";
        test("Adibidea 0000AAA Bilbo", e1.equalsIgnoreCase(r1), e1, r1);
    }

    // --- 1. TESTA: taxiSortuEtaKonfiguratu ---
    private static void testTaxiSortuEtaKonfiguratu() {
        System.out.println("\n" + BOLD + "--- 1. ariketa: taxiSortuEtaKonfiguratu ---" + RESET);
        String r1 = Ariketak.taxiSortuEtaKonfiguratu("1234ABC", "Bilbo", 1);
        String e1 = "Taxi [Matrikula: 1234ABC, Udalerria: Bilbo, Motorra: 1, Probintzia: Bizkaia]";
        test("Taxi 1234ABC Bilbo", e1.equalsIgnoreCase(r1), e1, r1);

        String r2 = Ariketak.taxiSortuEtaKonfiguratu("5678DEF", "Donostia", 2);
        String e2 = "Taxi [Matrikula: 5678DEF, Udalerria: Donostia, Motorra: 2, Probintzia: Bizkaia]";
        test("Taxi 5678DEF Donostia", e2.equalsIgnoreCase(r2), e2, r2);
    }

    // --- 2. TESTA: kotxeaBizkortuEtaGeldotu ---
    private static void testKotxeaBizkortuEtaGeldotu() {
        System.out.println("\n" + BOLD + "--- 2. ariketa: kotxeaBizkortuEtaGeldotu ---" + RESET);
        int r1 = Ariketak.kotxeaBizkortuEtaGeldotu(0, 50);
        test("Bizkortu (0 -> 50)", r1 == 50, "50", String.valueOf(r1));

        int r2 = Ariketak.kotxeaBizkortuEtaGeldotu(50, -20);
        test("Geldotu (50 -> 30)", r2 == 30, "30", String.valueOf(r2));

        int r3 = Ariketak.kotxeaBizkortuEtaGeldotu(20, -50);
        test("Geldotu 0 azpitik (20 -> 0)", r3 == 0, "0", String.valueOf(r3));
    }

    // --- 3. TESTA: celsiusToFahrenheit ---
    private static void testCelsiusToFahrenheit() {
        System.out.println("\n" + BOLD + "--- 3. ariketa: celsiusToFahrenheit ---" + RESET);
        double r1 = Ariketak.celsiusToFahrenheit(0.0);
        test("0.0 ºC -> 32.0 ºF", Math.abs(r1 - 32.0) < 0.001, "32.0", String.valueOf(r1));

        double r2 = Ariketak.celsiusToFahrenheit(100.0);
        test("100.0 ºC -> 212.0 ºF", Math.abs(r2 - 212.0) < 0.001, "212.0", String.valueOf(r2));
    }

    // --- 4. TESTA: fahrenheitToCelsius ---
    private static void testFahrenheitToCelsius() {
        System.out.println("\n" + BOLD + "--- 4. ariketa: fahrenheitToCelsius ---" + RESET);
        double r1 = Ariketak.fahrenheitToCelsius(32.0);
        test("32.0 ºF -> 0.0 ºC", Math.abs(r1 - 0.0) < 0.001, "0.0", String.valueOf(r1));

        double r2 = Ariketak.fahrenheitToCelsius(212.0);
        test("212.0 ºF -> 100.0 ºC", Math.abs(r2 - 100.0) < 0.001, "100.0", String.valueOf(r2));
    }

    // --- 5. TESTA: pertsonaZaharrena ---
    private static void testPertsonaZaharrena() {
        System.out.println("\n" + BOLD + "--- 5. ariketa: pertsonaZaharrena ---" + RESET);
        Ariketak.Pertsona p1 = new Ariketak.Pertsona("Jon", "Perez", 25);
        Ariketak.Pertsona p2 = new Ariketak.Pertsona("Miren", "Goikoetxea", 30);
        String r1 = Ariketak.pertsonaZaharrena(p1, p2);
        test("Zaharrena Miren Goikoetxea", "Miren Goikoetxea".equalsIgnoreCase(r1), "Miren Goikoetxea", r1);

        String r2 = Ariketak.pertsonaZaharrena(p2, p1);
        test("Zaharrena Miren Goikoetxea (alderantziz)", "Miren Goikoetxea".equalsIgnoreCase(r2), "Miren Goikoetxea", r2);
    }

    // --- 6. TESTA: kalkulatuIMC ---
    private static void testKalkulatuIMC() {
        System.out.println("\n" + BOLD + "--- 6. ariketa: kalkulatuIMC ---" + RESET);
        int r1 = Ariketak.kalkulatuIMC(50.0, 1.75);
        test("IMC azpitik (-1)", r1 == -1, "-1", String.valueOf(r1));

        int r2 = Ariketak.kalkulatuIMC(70.0, 1.75);
        test("IMC ideala (0)", r2 == 0, "0", String.valueOf(r2));

        int r3 = Ariketak.kalkulatuIMC(90.0, 1.75);
        test("Gehiegizko pisua (1)", r3 == 1, "1", String.valueOf(r3));
    }

    // --- 7. TESTA: adinezNagusikoaDa ---
    private static void testAdinezNagusikoaDa() {
        System.out.println("\n" + BOLD + "--- 7. ariketa: adinezNagusikoaDa ---" + RESET);
        boolean r1 = Ariketak.adinezNagusikoaDa(18);
        test("Adina 18 (Heldua)", r1 == true, "true", String.valueOf(r1));

        boolean r2 = Ariketak.adinezNagusikoaDa(17);
        test("Adina 17 (Adingabea)", r2 == false, "false", String.valueOf(r2));
    }

    // --- 8. TESTA: emailSortuEtaBistaratu ---
    private static void testEmailSortuEtaBistaratu() {
        System.out.println("\n" + BOLD + "--- 8. ariketa: emailSortuEtaBistaratu ---" + RESET);
        String r1 = Ariketak.emailSortuEtaBistaratu("jon@gmail.com", "Kaixo", "Aupa Jon");
        String e1 = "Norentzat: jon@gmail.com | Asuntua: Kaixo | Gorputza: Aupa Jon";
        test("Email formatua", e1.equalsIgnoreCase(r1), e1, r1);
    }

    // --- 9. TESTA: postontziaKudeatu ---
    private static void testPostontziaKudeatu() {
        System.out.println("\n" + BOLD + "--- 9. ariketa: postontziaKudeatu ---" + RESET);
        Ariketak.Postontzia postontzia = new Ariketak.Postontzia();
        Ariketak.Email email1 = new Ariketak.Email("a@a.com", "T1", "G1");
        int r1 = Ariketak.postontziaKudeatu(postontzia, email1);
        test("1. emaila gehitu", r1 == 1, "1", String.valueOf(r1));

        Ariketak.Email email2 = new Ariketak.Email("b@b.com", "T2", "G2");
        int r2 = Ariketak.postontziaKudeatu(postontzia, email2);
        test("2. emaila gehitu", r2 == 2, "2", String.valueOf(r2));
    }

    // --- 10. TESTA: ikasgelakoIkasleakZenbatu ---
    private static void testIkasgelakoIkasleakZenbatu() {
        System.out.println("\n" + BOLD + "--- 10. ariketa: ikasgelakoIkasleakZenbatu ---" + RESET);
        Ariketak.Ikasgela ikasgela = new Ariketak.Ikasgela();
        Ariketak.Pertsona p1 = new Ariketak.Pertsona("Unai", "Garmendia", 20);
        int r1 = Ariketak.ikasgelakoIkasleakZenbatu(ikasgela, p1);
        test("Ikasle 1 gehitu", r1 == 1, "1", String.valueOf(r1));
    }
}