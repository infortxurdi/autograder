package poo;

public class ConfigGrader {

    // true  -> Ejecuta todas las pruebas
    // false -> Ejecuta solo el ejercicio indicado en EXERCISE_NUMBER
    public static final boolean RUN_ALL = false;

    // Número del ejercicio a probar cuando RUN_ALL = false (del 0 al 10)
    // 0: taxiAdibidea (Resuelto)    6: kalkulatuIMC
    // 1: taxiSortuEtaKonfiguratu    7: adinezNagusikoaDa
    // 2: kotxeaBizkortuEtaGeldotu   8: emailSortuEtaBistaratu
    // 3: celsiusToFahrenheit        9: postontziaKudeatu
    // 4: fahrenheitToCelsius        10: ikasgelakoIkasleakZenbatu
    // 5: pertsonaZaharrena
    public static final int EXERCISE_NUMBER = 0;
}